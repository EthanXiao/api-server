package com.oppo.dc.idmapping.configuration;

import com.oppo.dc.idmapping.graph.query.GraphQueryTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JanusGraphConfiguration {

  @Value("${graph.datasource.filePath}")
  private String graphConfigurationPath;

  @Bean
  public GraphQueryTemplate graphQueryTemplate() {
    return new GraphQueryTemplate(graphConfigurationPath);
  }
}
