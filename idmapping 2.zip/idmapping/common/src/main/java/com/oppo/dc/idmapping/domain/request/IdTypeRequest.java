package com.oppo.dc.idmapping.domain.request;

import java.io.Serializable;

public class IdTypeRequest implements Serializable {

    private String type;

    private String value;

    public String getType() {
        return type;
    }

    public IdTypeRequest setType(String type) {
        this.type = type;
        return this;
    }

    public String getValue() {
        return value;
    }

    public IdTypeRequest setValue(String value) {
        this.value = value;
        return this;
    }
}
