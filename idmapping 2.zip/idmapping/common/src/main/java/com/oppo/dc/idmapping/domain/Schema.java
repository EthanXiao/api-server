package com.oppo.dc.idmapping.domain;

public final class Schema {

    public static final String GROUP = "group";

    public static final String NODE = "node";

    public static final String PROPERTY_NTYPE = "nType";

    public static final String PROPERTY_VALUE = "value";
}
