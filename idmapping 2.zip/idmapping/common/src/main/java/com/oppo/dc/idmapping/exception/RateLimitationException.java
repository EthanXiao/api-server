package com.oppo.dc.idmapping.exception;

public class RateLimitationException extends RuntimeException {
}
