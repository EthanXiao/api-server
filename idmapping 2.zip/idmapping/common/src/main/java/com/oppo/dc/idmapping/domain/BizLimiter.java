package com.oppo.dc.idmapping.domain;

public class BizLimiter {

    private String bizNo;

    private String bizName;

    private String bizDesc;

    private String signKey;

    private Integer rateLimitPerSec;

    public String getBizNo() {
        return bizNo;
    }

    public BizLimiter setBizNo(String bizNo) {
        this.bizNo = bizNo;
        return this;
    }

    public String getBizName() {
        return bizName;
    }

    public BizLimiter setBizName(String bizName) {
        this.bizName = bizName;
        return this;
    }

    public String getBizDesc() {
        return bizDesc;
    }

    public BizLimiter setBizDesc(String bizDesc) {
        this.bizDesc = bizDesc;
        return this;
    }

    public String getSignKey() {
        return signKey;
    }

    public BizLimiter setSignKey(String signKey) {
        this.signKey = signKey;
        return this;
    }

    public Integer getRateLimitPerSec() {
        return rateLimitPerSec;
    }

    public BizLimiter setRateLimitPerSec(Integer rateLimitPerSec) {
        this.rateLimitPerSec = rateLimitPerSec;
        return this;
    }
}
