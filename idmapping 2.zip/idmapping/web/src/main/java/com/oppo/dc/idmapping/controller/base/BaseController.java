package com.oppo.dc.idmapping.controller.base;

import com.oppo.dc.idmapping.cache.LocalCache;
import com.oppo.dc.idmapping.domain.BizLimiter;
import com.oppo.dc.idmapping.domain.request.IdTypeRequest;
import com.oppo.dc.idmapping.task.FlushCacheTask;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class BaseController {

    private static final Logger logger = LoggerFactory.getLogger(BaseController.class);

    static LocalCache localCache = new LocalCache();

    static FlushCacheTask flushCacheTask = new FlushCacheTask(localCache);

    static {
        flushCacheTask.start();
    }

    protected Object validateParamAndReturn(String bizNo, String signData, IdTypeRequest idTypeRequest) {
        BizLimiter bizLimiter = localCache.getLimiterCache().getUnchecked(bizNo);
        if (bizLimiter == null) throw new SignNotValidException("method params not valid");
        String checkSignStr = bizNo + bizLimiter.getSignKey();
        String checkSignData = null;
        try {
            checkSignData = MD5Util.getMD5Str(checkSignStr);
        } catch (Exception e) {
            logger.info("MD5Util getMD5Str exception!!");
            throw new SignNotValidException("MD5Util getMD5Str exception");
        }
        if (!checkSignData.equals(signData)) {
            throw new SignNotValidException("SignData Error,Please Check!!! signData=MD5(bizNo+signKey)");
        }
        RateLimiter rateLimiter = localCache.getBizRateLimiter(bizLimiter);
        if (rateLimiter.tryAcquire()) {
            try {
                RequestMonitor requestMonitor = new RequestMonitor();
                requestMonitor.start();
                R r = option.operate();
                requestMonitor.stop();
                logger.info(requestMonitor.getThreadId() + ": request cost time {}", requestMonitor.getCurrentRequestTotalTime());
                return Result.<R>builder().data(r).code(ResponseCode.SUCCESS.getStatus()).message("success").build();
            } catch (Throwable e) {
                logger.info("sql handle failed!!! exception is " + e.getMessage());
                e.printStackTrace();
                try {
                    return failedBack();
                } catch (Exception e1) {
                    throw new DataAccessServerException("upgrade invoke failed");
                }
            }
        } else {
            throw new RateLimitationException("Request Rate For bizName:" + bizLimiter.getBizName() + " Over Limitation！");
        }
    }
}
