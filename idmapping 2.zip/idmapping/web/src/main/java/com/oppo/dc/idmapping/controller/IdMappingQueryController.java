package com.oppo.dc.idmapping.controller;

import com.oppo.dc.idmapping.controller.base.BaseController;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class IdMappingQueryController extends BaseController {


}
