package com.oppo.dc.idmapping.data;

import com.oppo.dc.idmapping.domain.BizLimiter;

import java.util.List;

@Mapper
public interface BizLimiterDao {

    BizLimiter getBizLimiterByBizNo(String bizNo);

    List<BizLimiter> getAllBizLimiter();
}
