package com.oppo.dc.idmapping.service;

import com.oppo.dc.idmapping.model.TypeMapping;
import com.oppo.dc.idmapping.domain.request.IdTypeRequest;
import java.util.List;

public interface IDQueryService {

  List<TypeMapping> queryFromSourceType(IdTypeRequest idTypeRequest);
}
