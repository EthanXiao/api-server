package com.oppo.dc.idmapping.service.impl;

import com.oppo.dc.idmapping.domain.request.IdTypeRequest;
import com.oppo.dc.idmapping.model.TypeMapping;
import com.oppo.dc.idmapping.service.IDQueryService;
import java.util.List;
import org.springframework.stereotype.Component;

@Component
public class IDQueryServiceImpl implements IDQueryService{


  @Override
  public List<TypeMapping> queryFromSourceType(IdTypeRequest idTypeRequest) {
    return null;
  }
}
