package com.oppo.dc.idmapping.cache;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.util.concurrent.RateLimiter;
import com.oppo.dc.idmapping.context.SpringContext;
import com.oppo.dc.idmapping.domain.BizLimiter;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

public class LocalCache {

    public static final Integer DEFAULT_CACHE_EXPIRE_MINUTES = 10;

    private LoadingCache<String, BizLimiter> limiterCache = CacheBuilder.newBuilder()
            .concurrencyLevel(8)
            .expireAfterWrite(10, TimeUnit.MINUTES)
            .initialCapacity(10)
            .maximumSize(1000)
            .build(
                    new CacheLoader<String, BizLimiter>() {
                        @Override
                        public BizLimiter load(String key) throws Exception {
                            BizLimiterDao bizLimiterDao = SpringContext.getContext().getBean(BizLimiterDao.class);
                            return bizLimiterDao.getBizLimiterByBizNo(key);
                        }
                    }
            );
    private Cache<String, RateLimiter> rateLimiterCache = CacheBuilder.newBuilder()
            .concurrencyLevel(8) //设置并发级别为8，并发级别是指可以同时写缓存的线程数
            .expireAfterWrite(DEFAULT_CACHE_EXPIRE_MINUTES, TimeUnit.MINUTES) //设置写缓存过期时间
            .initialCapacity(10) //缓存容器的初始容量
            .maximumSize(1000) //缓存最大容量
            .build();

    public RateLimiter getBizRateLimiter(final BizLimiter bizLimiter) {
        RateLimiter result = null;
        try {
            result = rateLimiterCache.get(bizLimiter.getBizNo(), new Callable<RateLimiter>() {
                public RateLimiter call() throws Exception {
                    RateLimiter rateLimiter;
                    rateLimiter =  RateLimiter.create(bizLimiter.getRateLimitPerSec());
                    return rateLimiter;
                }
            });
        } catch (ExecutionException e) {
            throw new RuntimeException("rateLimiterCache get failed!!!");
        }
        return result;
    }

    public LoadingCache<String, BizLimiter> getLimiterCache() {
        return limiterCache;
    }

    public Cache<String, RateLimiter> getRateLimiterCache() {
        return rateLimiterCache;
    }
}
