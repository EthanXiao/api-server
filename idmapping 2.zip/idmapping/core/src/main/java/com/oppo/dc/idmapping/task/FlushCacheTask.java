package com.oppo.dc.idmapping.task;

public class FlushCacheTask {
}
