package com.oppo.dc.idmapping.graph.query;

import com.oppo.dc.idmapping.domain.Schema;
import java.util.List;
import java.util.Map;
import org.apache.tinkerpop.gremlin.process.traversal.dsl.graph.GraphTraversalSource;
import org.apache.tinkerpop.gremlin.process.traversal.dsl.graph.__;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class QueryRunner {

    private static final Logger logger = LoggerFactory.getLogger(QueryRunner.class);

    private GraphTraversalSource graphTraversalSource;

    public QueryRunner(GraphTraversalSource graphTraversalSource) {
        this.graphTraversalSource = graphTraversalSource;
    }

    public String findGroupNodeValue(String sourceType, String value) {
        return (String) graphTraversalSource
            .V()
            .and(__.hasLabel(Schema.NODE), __.has(Schema.PROPERTY_NTYPE, sourceType), __.has(Schema.PROPERTY_VALUE, value))
            .in(Schema.GROUP)
            .limit(1)
            .values(Schema.PROPERTY_VALUE)
            .toList().get(0);
    }

    public List<Map<Object, Object>> findOneStepNode(String groupValue) {
        return graphTraversalSource
            .V()
            .and(__.hasLabel(Schema.GROUP), __.has(Schema.PROPERTY_VALUE, groupValue))
            .out(Schema.NODE)
            .valueMap(Schema.PROPERTY_NTYPE, Schema.PROPERTY_VALUE)
            .toList();
    }

    public void commit(){
        graphTraversalSource.tx().commit();
    }

    public void close() {
        try {
            graphTraversalSource.close();
        } catch (Exception e) {
            logger.warn("fail to close graph!", e);
        }
    }

}
