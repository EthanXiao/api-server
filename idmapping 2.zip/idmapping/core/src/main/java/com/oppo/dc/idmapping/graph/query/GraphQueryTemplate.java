package com.oppo.dc.idmapping.graph.query;

import com.oppo.dc.idmapping.model.TypeMapping;
import java.util.List;
import org.janusgraph.core.JanusGraphFactory;

public class GraphQueryTemplate implements AutoCloseable {

  private QueryRunner queryRunner;

  public GraphQueryTemplate(String configurationPath) {
    queryRunner = new QueryRunner(JanusGraphFactory.open(configurationPath).traversal());
  }

  public List<TypeMapping> queryAllIdsByTypeValue(String type, String value) {
    String groupValue = queryRunner.findGroupNodeValue(type, value);
  }

  @Override
  public void close() throws Exception {
    queryRunner.close();
  }
}
