package com.oppo.dc.idmapping.model;

import com.google.common.base.MoreObjects;
import java.util.List;

public class TypeMapping {

    private String type;

    private List<String> values;

    public String getType() {
        return type;
    }

    public TypeMapping setType(String type) {
        this.type = type;
        return this;
    }

    public List<String> getValues() {
        return values;
    }

    public TypeMapping setValues(List<String> values) {
        this.values = values;
        return this;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
            .add("type", type)
            .add("values", values)
            .toString();
    }
}
