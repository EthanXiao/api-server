from django.db import models


class User(models.Model):
    user_id = models.AutoField(primary_key=True)
    email = models.CharField(max_length=255)
    name = models.CharField(max_length=64, null=True)
    salt = models.CharField(max_length=64)
    password = models.CharField(max_length=64)
    role_id = models.IntegerField(null=True)


class Role(models.Model):
    role_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255)
    note = models.CharField(max_length=255)
    authority_id_list = models.CharField(max_length=255)


class Authority(models.Model):
    authority_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255)
    note = models.CharField(max_length=255)
    code = models.CharField(max_length=255)


