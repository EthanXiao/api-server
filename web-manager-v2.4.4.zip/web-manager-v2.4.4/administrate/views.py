from django.contrib.auth.models import User


def add_user_django(username, email, password):
    try:
        User.objects.get(username=username)
        data = {'code': '-1', 'info': u'the user is already existed.'}
        return 'false'
    except User.DoesNotExist:
        user = User.objects.create_user(username, email, password)
        if user is not None:
            user.is_active = False
            user.save()
        return "true"

