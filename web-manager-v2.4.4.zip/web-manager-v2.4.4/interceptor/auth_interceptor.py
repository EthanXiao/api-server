# -*- coding:utf-8 -*-
#
# Copyright (c) 2017, TP-Link Co.,Ltd.
# Author:  yuzhijiang <yuzhijiang@tp-link.com.cn>
# Created: 2017-9-26
#
#
import json
import logging

from django.http import HttpResponse
from django.http import HttpResponseRedirect

from common.digest_utils import get_sha1
from common.error_code import errorCode
from common.mysql_dao import MysqlOp
from user.models import User, Role, Authority
from webmanager.conf import conf
from webmanager.settings import MySQLConfig, Config

logger = logging.getLogger(__name__)
isGlobal = Config['isGlobal']


def find_user(email, password):
    if isGlobal:
        user = User.find(email)
        if user is None:
            return False

        password_sha = get_sha1(password)
        password_sha_sha = get_sha1(password_sha)
        password_salt = user.salt
        password_salt_sha = get_sha1(password_sha_sha + password_salt)

        if password_salt_sha == user.password:
            return True
        else:
            return False
    else:
        mysql_op = MysqlOp(MySQLConfig['host'],
                           MySQLConfig['port'],
                           MySQLConfig['user'],
                           MySQLConfig['passwd'],
                           MySQLConfig['db'])
        user = mysql_op.get_user_info(email)
        if user is None:
            return False

        password_sha = get_sha1(password)
        password_sha_sha = get_sha1(password_sha)
        password_salt = user['salt']
        password_salt_sha = get_sha1(password_sha_sha + password_salt)

        if password_salt_sha == user['password']:
            return True
        else:
            return False


def check_authority(func):
    def wrapper(request):
        login_url = '/webManager/login'
        str_login = 'login/login.html'
        session = request.COOKIES.get('session_id')

        if session is None:
            logger.error('ERROR, the user has not logined.')
            return HttpResponse(errorCode.ERROR_USER_OFFLINE)

        content_type = request.META['CONTENT_TYPE']
        if 'application/json' in content_type:
            request.POST = request.POST.copy()
            request.POST.update(json.loads(request.body))

        mysql_op = MysqlOp(MySQLConfig['host'],
                           MySQLConfig['port'],
                           MySQLConfig['user'],
                           MySQLConfig['passwd'],
                           MySQLConfig['db'])
        session_info = mysql_op.check_session(session)

        if session_info is None:
            logger.warn('Checking session failed! the unauthorized session is--------> %s', session)
            return HttpResponseRedirect(login_url)

        logger.info('Checking session success! cloud user is--------> %s', session_info.get('email'))

        role_id = session_info['role_id']
        role = Role.find(role_id)
        authority_id_list = role.authorityIdList.split(r',')
        authority = conf.admin_authority
        for authorityId in authority_id_list:
            code = Authority.find(authorityId).code
            if code == authority:
                logger.info('Checking authority passed! the cloud-user is--------> %s',
                            session_info.get('email'))
                return func(request)

        logger.warn('Checking authority failed! cloud user is--------> %s', session_info.get('email'))
        data = {'data': [{'authority': 'no permission'}]}
        return HttpResponse(json.dumps(data))

    return wrapper


def check_super_admin_authority(func):
    def wrapper(request):
        login_url = '/webManager/login'
        str_login = 'login/login.html'
        session = request.COOKIES.get('session_id')

        if session is None:
            logger.error('ERROR, the user has not logined.')
            return HttpResponse(errorCode.ERROR_USER_OFFLINE)

        content_type = request.META['CONTENT_TYPE']
        if 'application/json' in content_type:
            request.POST = request.POST.copy()
            request.POST.update(json.loads(request.body))

        mysql_op = MysqlOp(MySQLConfig['host'],
                           MySQLConfig['port'],
                           MySQLConfig['user'],
                           MySQLConfig['passwd'],
                           MySQLConfig['db'])
        session_info = mysql_op.check_session(session)

        if session_info is None:
            logger.warn('Checking session failed! the unauthorized session is--------> %s', session)
            return HttpResponseRedirect(login_url)

        logger.info('Checking session success! the super-admin cloud-user is--------> %s', session_info.get('email'))

        role_id = session_info['role_id']
        role = Role.find(role_id)
        authority_id_list = role.authorityIdList.split(r',')
        authority = conf.superadmin_authority
        for authorityId in authority_id_list:
            code = Authority.find(authorityId).code
            if code == authority:
                logger.info('Checking super-admin authority passed! the super-admin cloud-user is--------> %s',
                            session_info.get('email'))
                return func(request)

        logger.warn('Checking super-admin authority failed! cloud user is not superadmin. --------> %s', session_info.get('email'))
        data = {'data': [{'authority': 'no permission'}]}
        return HttpResponse(json.dumps(data))

    return wrapper


def check_session(func):
    def wrapper(request):
        login_url = '/webManager/login'
        try:
            session = request.COOKIES['session_id']
        except:
            return HttpResponseRedirect(login_url)

        mysql_op = MysqlOp(MySQLConfig['host'],
                           MySQLConfig['port'],
                           MySQLConfig['user'],
                           MySQLConfig['passwd'],
                           MySQLConfig['db'])
        session_info = mysql_op.check_session(session)

        if session_info is None:
            return HttpResponseRedirect(login_url)

        return func(request)
    return wrapper
