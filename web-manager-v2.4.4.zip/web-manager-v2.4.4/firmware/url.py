# -*- coding:utf-8 -*-
#
# Copyright (c) 2017, TP-Link Co.,Ltd.
# Author:  yuzhijiang <yuzhijiang@tp-link.com.cn>
# Created: 2017-10-10
#
#
from django.conf.urls import url
from . import views

urlpatterns = [

    url(r'^getFirmwareInfo$', views.get_firmware_info, name='get_firmware_info'),
    url(r'^readFirmwareInfo$', views.read_firmware_info, name='read_firmware_info'),
    url(r'^getFirmwareExtraInfo$', views.get_firmware_extra_info, name='get_firmware_extra_info'),
    url(r'^readTargetEditingFirmwareInfo$', views.read_target_editing_firmware_info,
        name='read_target_editing_firmware_info'),
    url(r'^modifyFirmwareInfo$', views.modify_firmware_info, name='modify_firmware_info'),


    url(r'^getFirmwareLocaleInfo$', views.get_firmware_locale_info, name='get_firmware_locale_info'),
    url(r'^readFirmwareLocaleInfo$', views.read_firmware_locale_info, name='read_firmware_locale_info'),


    url(r'^getFirmwareReleaseTaskInfo$', views.get_firmware_release_task_info, name='get_firmware_release_task_info'),
    url(r'^readFirmwareReleaseTaskInfo$', views.read_firmware_release_task_info,
        name='read_firmware_release_task_info'),
    url(r'^getFirmwareReleaseTaskExtraInfo$', views.get_firmware_release_task_extra_info,
        name='get_firmware_release_task_extra_info'),

    url(r'^getFirmwareUpgradeCacheExportInfo$', views.get_firmware_upgrade_cache_export_info,
        name='get_firmware_upgrade_cache_export_info'),
    url(r'^readFirmwareUpgradeCacheExportInfo$', views.read_firmware_upgrade_cache_export_info,
        name='read_firmware_upgrade_cache_export_info'),

    url(r'^getFirmwareUpgradeCacheMainlandInfo$', views.get_firmware_upgrade_cache_mainland_info,
        name='get_firmware_upgrade_cache_mainland_info'),
    url(r'^readFirmwareUpgradeCacheMainlandInfo$', views.read_firmware_upgrade_cache_mainland_info,
        name='read_firmware_upgrade_cache_mainland_info'),

    url(r'^getFirmwareUpgradeRelationshipInfo$', views.get_firmware_upgrade_relationship_info,
        name='get_firmware_upgrade_relationship_info'),
    url(r'^readFirmwareUpgradeRelationshipInfo$', views.read_firmware_upgrade_relationship_info,
        name='read_firmware_upgrade_relationship_info'),

    url(r'^getFirmwareDegradeRelationshipInfo$', views.get_firmware_degrade_relationship_info,
        name='get_firmware_degrade_relationship_info'),
    url(r'^readFirmwareDegradeRelationshipInfo$', views.read_firmware_degrade_relationship_info,
        name='read_firmware_degrade_relationship_info'),

    url(r'^getFirmwareSuitableModelInfo$', views.get_firmware_suitable_model_info,
        name='get_firmware_suitable_model_info'),
    url(r'^readFirmwareSuitableModelInfo$', views.read_firmware_suitable_model_info,
        name='read_firmware_suitable_model_info'),

    url(r'^getFirmwareRollbackTaskInfo$', views.get_firmware_rollback_task_info, name='get_firmware_rollback_task_info'),
    url(r'^readFirmwareRollbackTaskInfo$', views.read_firmware_rollback_task_info,
        name='read_firmware_rollback_task_info'),
    url(r'^getFirmwareRollbackTaskExtraInfo$', views.get_firmware_rollback_task_extra_info,
        name='get_firmware_rollback_task_extra_info'),

]
