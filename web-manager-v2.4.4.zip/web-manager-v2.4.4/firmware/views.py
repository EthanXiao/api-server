# -*- coding:utf-8 -*-
#
# Copyright (c) 2017, TP-Link Co.,Ltd.
# Author:  yuzhijiang <yuzhijiang@tp-link.com.cn>
# Created: 2017-10-10
#
#
import datetime
import json
import logging
import traceback

from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader

from common.mysql_dao import MysqlOp
from firmware.models import FirmwareInfo, FirmwareLocaleInfo, FirmwareReleaseTaskInfo, FirmwareUpgradeCacheInfo, \
    FirmwareUpgradeCacheMainlandInfo, FirmwareUpgradeRelationshipInfo, FirmwareDegradeRelationshipInfo, \
    FirmwareSuitableModelInfo, FirmwareRollbackTaskInfo
from interceptor.auth_interceptor import check_authority
from webmanager.conf import conf
from webmanager.settings import MySQLConfig, Config

logger = logging.getLogger(__name__)
isGlobal = Config['isGlobal']


def get_firmware_info(request):
    str = 'firmware/firmware/firmware-info.html'
    str_login = '/webManager/login'
    try:
        session = request.COOKIES["session_id"]
    except:
        logger.error('ERROR, the user has not logined. %s', traceback.format_exc())
        return HttpResponseRedirect(str_login)

    mysql_op = MysqlOp(MySQLConfig['host'],
                       MySQLConfig['port'],
                       MySQLConfig['user'],
                       MySQLConfig['passwd'],
                       MySQLConfig['db'])
    session_info = mysql_op.check_session(session)

    if session_info is not None:
        if isGlobal:
            response_data = {'priority_fields': conf.all_fields_firmware_filter.get('priority')}
        else:
            response_data = {'priority_fields': conf.all_fields_firmware_filter_mainland.get('priority')}
        email = session_info['email']
        response_data.update({'user': email.split("@")[0], 'web_user_role': session_info.get('role_id'),
                              'isGlobal':isGlobal})

        response = render(request, str, response_data)
        response.set_cookie("session_id", session, conf.session_ttl)
        return response
    else:
        logger.warn("get_firmware_info. checking-session failed. the session is ------>%s" % session)
        return HttpResponseRedirect(str_login)


@check_authority
def read_firmware_info(request):
    request_body = request.POST.copy()

    logger.info("read_firmware_info started. the request is ------>%s" % request_body)

    content_type = request.META['CONTENT_TYPE']
    if 'application/json' in content_type:
        request_body.update(json.loads(request.body))

    try:
        response = FirmwareInfo.get_data_mysql_by_page(request_body)
        response_count = FirmwareInfo.get_data_mysql_count(request_body)
        response_data = response['responseBody']
        records_filtered = response_count['responseBody']

        records_total_count = FirmwareInfo.get_data_mysql_count({"firmwareId": ""})
        records_total = records_total_count["responseBody"]
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        raise

    if type(response_data) is type(list()):
        data = {'data': response_data, 'recordsFiltered': records_filtered, 'recordsTotal': records_total}
    elif type(response_data) is type(dict()):
        response_temp = [response_data]
        data = {'data': response_temp, 'recordsFiltered': 1, 'recordsTotal': records_total}
    else:
        response_temp = []
        data = {'data': response_temp, 'recordsFiltered': 0, 'recordsTotal': records_total}
        logger.info("the type of the data from DAL is -----> %s" % type(response_data))
    for each in data['data']:
        for key in list(each.keys()):
            if each[key] == ' ' or each[key] == '' or each[key] == 'null' or each[key] is None:
                each[key] = '-'
    return HttpResponse(json.dumps(data))


@check_authority
def get_firmware_extra_info(request):
    str_device_detail = 'firmware/firmware/firmware-extra-info.html'
    request_body = request.POST.copy()

    logger.info("get_firmware_extra_info started. the request is ------>%s" % request_body)

    firmware_id = request_body.get('firmwareId', '')
    template = loader.get_template(str_device_detail)

    try:
        if isGlobal:
            request_param = {"fwId": firmware_id}
            response_firmware_info_filter = conf.all_fields_firmware_filter.get('other')
        else:
            request_param = {"firmwareId": firmware_id}
            response_firmware_info_filter = conf.all_fields_firmware_filter_mainland.get('other')

        response = FirmwareInfo.get_data_mysql_exactly(request_param)  # queried by modelId
        response_firmware_info_list = response

        if response_firmware_info_list is None or response_firmware_info_list == '' \
                or response_firmware_info_list == "null":
            response_firmware_info_filter = 'null'
        else:
            response_firmware_info = response_firmware_info_list
            for each in response_firmware_info_filter:
                field_name_en = each['field_name_en']
                each['field_value'] = response_firmware_info.get(field_name_en, '-')  # filter operation
                if each['field_value'] == ' ' or each['field_value'] == '' or each['field_value'] == 'null' or each[
                    'field_value'] is None:
                    each['field_value'] = '-'
                if each.get('value_type', '') == 'date':
                    date_value = each['field_value']
                    if date_value is not None and date_value != '' and date_value != '-':
                        each['field_value'] = datetime.datetime.fromtimestamp(date_value / 1000)
    except:
        logger.error("failed in getting firmware info from models-layer. %s", traceback.format_exc())
        response_firmware_info_filter = 'fail'

    data = {'firmware': response_firmware_info_filter}
    return HttpResponse(json.dumps({'html': template.render(data)}))


@check_authority
def read_target_editing_firmware_info(request):
    request_body = request.POST.copy()

    logger.info("read_target_editing_firmware_info started. the request is ------>%s" % request.POST)

    str_firmware_editing = 'firmware/firmware/modify-modal-content.html'
    template = loader.get_template(str_firmware_editing)

    firmware_id = request_body['firmwareId']
    try:
        response_firmware_info = FirmwareInfo.get_data_mysql_exactly({'firmwareId': firmware_id})
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        response_firmware_info = 'fail'
        data = {'firmware': response_firmware_info}
        return HttpResponse(json.dumps({'html': template.render(data)}))

    target_firmware_info_filter = [
        {
            "field_name_cn": "固件发布日志",
            'field_name_en': 'releaseLog',
            "field_value": ''
        },
        {
            "field_name_cn": "固件ID",
            'field_name_en': 'firmwareId',
            "field_value": ''
        },
    ]

    for each in target_firmware_info_filter:
        field_name_en = each['field_name_en']
        each['field_value'] = response_firmware_info.get(field_name_en, '')  # filter operation
    data = {'firmware': target_firmware_info_filter}
    return HttpResponse(json.dumps({'html': template.render(data)}))


@check_authority
def modify_firmware_info(request):
    request_body = request.POST

    logger.info("modify_firmware_info started. the request is ------>%s" % request_body)

    response_data = ""
    try:
            response = FirmwareInfo.update_data_mysql(request_body)
            response_data = response['responseBody']
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())

    data = {'result': response_data}

    return HttpResponse(json.dumps(data))


def get_firmware_locale_info(request):
    str = 'firmware/firmware-locale/firmware-locale-info.html'
    str_login = '/webManager/login'
    try:
        session = request.COOKIES["session_id"]
    except:
        logger.error('ERROR, the user has not logined. %s', traceback.format_exc())
        return HttpResponseRedirect(str_login)

    mysql_op = MysqlOp(MySQLConfig['host'],
                       MySQLConfig['port'],
                       MySQLConfig['user'],
                       MySQLConfig['passwd'],
                       MySQLConfig['db'])
    session_info = mysql_op.check_session(session)

    if session_info is not None:
        response_data = {'priority_fields': conf.all_fields_fw_locale_filter.get('priority')}
        email = session_info['email']
        response_data.update({'user': email.split("@")[0], 'web_user_role': session_info.get('role_id'),
                              'isGlobal': isGlobal})

        response = render(request, str, response_data)
        response.set_cookie("session_id", session, conf.session_ttl)
        return response
    else:
        logger.warn("get_firmware_locale_info. checking-session failed. the session is ------>%s" % session)
        return HttpResponseRedirect(str_login)


@check_authority
def read_firmware_locale_info(request):
    request_body = request.POST.copy()

    logger.info("read_firmware_locale_info started. the request is ------>%s" % request_body)

    content_type = request.META['CONTENT_TYPE']
    if 'application/json' in content_type:
        request_body.update(json.loads(request.body))

    try:
        response = FirmwareLocaleInfo.get_data_mysql_by_page(request_body)
        response_count = FirmwareLocaleInfo.get_data_mysql_count(request_body)
        response_data = response['responseBody']
        records_filtered = response_count['responseBody']

        records_total_count = FirmwareLocaleInfo.get_data_mysql_count({"firmwareId": ""})
        records_total = records_total_count["responseBody"]
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        raise

    if type(response_data) is type(list()):
        data = {'data': response_data, 'recordsFiltered': records_filtered, 'recordsTotal': records_total}
    elif type(response_data) is type(dict()):
        response_temp = [response_data]
        data = {'data': response_temp, 'recordsFiltered': 1, 'recordsTotal': records_total}
    else:
        response_temp = []
        data = {'data': response_temp, 'recordsFiltered': 0, 'recordsTotal': records_total}
        logger.info("the type of the data from DAL is -----> %s" % type(response_data))
    return HttpResponse(json.dumps(data))


def get_firmware_release_task_info(request):
    str = 'firmware/firmware-release-task/firmware-release-task-info.html'
    str_login = '/webManager/login'
    try:
        session = request.COOKIES["session_id"]
    except:
        logger.error('ERROR, the user has not logined. %s', traceback.format_exc())
        return HttpResponseRedirect(str_login)

    mysql_op = MysqlOp(MySQLConfig['host'],
                       MySQLConfig['port'],
                       MySQLConfig['user'],
                       MySQLConfig['passwd'],
                       MySQLConfig['db'])
    session_info = mysql_op.check_session(session)

    if session_info is not None:
        if isGlobal:
            response_data = {'priority_fields': conf.all_fields_fw_release_task_filter.get('priority')}
        else:
            response_data = {'priority_fields': conf.all_fields_fw_release_task_mainland_filter.get('priority')}
        email = session_info['email']
        response_data.update({'user': email.split("@")[0], 'web_user_role': session_info.get('role_id'),
                              'isGlobal': isGlobal})

        response = render(request, str, response_data)
        response.set_cookie("session_id", session, conf.session_ttl)
        return response
    else:
        logger.warn("get_firmware_release_task_info. checking-session failed. the session is ------>%s" % session)
        return HttpResponseRedirect(str_login)


@check_authority
def read_firmware_release_task_info(request):
    request_body = request.POST

    logger.info("read_firmware_release_task_info started. the request is ------>%s" % request_body)

    try:
        response = FirmwareReleaseTaskInfo.get_data_mysql_by_page(request_body)
        response_count = FirmwareReleaseTaskInfo.get_data_mysql_count(request_body)
        response_data = response['responseBody']
        records_filtered = response_count['responseBody']
        records_total_count = FirmwareReleaseTaskInfo.get_data_mysql_count(
            {"modelId": "", "hardwareType": "", "hardwareVersion": ""})
        records_total = records_total_count["responseBody"]
    except:
        logger.error("reading model info by page failed in getting data in models-layer. %s", traceback.format_exc())
        raise

    if type(response_data) is type(list()):
        data = {'data': response_data, 'recordsFiltered': records_filtered, 'recordsTotal': records_total}
    elif type(response_data) is type(dict()):
        response_temp = [response_data]
        data = {'data': response_temp, 'recordsFiltered': 1, 'recordsTotal': records_total}
    else:
        response_temp = []
        data = {'data': response_temp, 'recordsFiltered': 0, 'recordsTotal': records_total}
        logger.info("the type of the data from DAL is -----> %s" % type(response_data))

    for each in data['data']:
        for key in list(each.keys()):
            if each[key] == ' ' or each[key] == '' or each[key] == 'null' or each[key] is None:
                each[key] = '-'
    return HttpResponse(json.dumps(data))


@check_authority
def get_firmware_release_task_extra_info(request):
    str_device_detail = 'firmware/firmware-release-task/firmware-release-task-extra-info.html'

    request_body = request.POST.copy()

    logger.info("get_firmware_release_task_extra_info started. the request is ------>%s" % request_body)

    task_id = request_body.get('taskId', '')
    template = loader.get_template(str_device_detail)

    try:
        response = FirmwareReleaseTaskInfo.get_data_mysql_list({"taskId": task_id})  # queried by modelId
        response_firmware_release_list = response['responseBody']

        if len(response_firmware_release_list) == 0:
            response_firmware_release_info_filter = 'null'
        else:
            response__firmware_release = response_firmware_release_list[0]
            response_firmware_release_info_filter = conf.all_fields_fw_release_task_filter.get('other')
            for each in response_firmware_release_info_filter:
                field_name_en = each['field_name_en']
                each['field_value'] = response__firmware_release.get(field_name_en, '-')  # filter operation
                if each['field_value'] == ' ' or each['field_value'] == '' or each['field_value'] == 'null' or each[
                    'field_value'] is None:
                    each['field_value'] = '-'
                if each.get('value_type', '') == 'date':
                    date_value = each['field_value']
                    if date_value is not None and date_value != '' and date_value != 'null':
                        each['field_value'] = datetime.datetime.fromtimestamp(date_value / 1000)
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        response_firmware_release_info_filter = 'fail'

    data = {'firmware_release_task': response_firmware_release_info_filter}
    return HttpResponse(json.dumps({'html': template.render(data)}))


def get_firmware_upgrade_cache_export_info(request):
    str = 'firmware/firmware-upgrade-cache/firmware-upgrade-cache-info.html'
    str_login = '/webManager/login'
    try:
        session = request.COOKIES["session_id"]
    except:
        logger.error('ERROR, the user has not logined. %s', traceback.format_exc())
        return HttpResponseRedirect(str_login)

    mysql_op = MysqlOp(MySQLConfig['host'],
                       MySQLConfig['port'],
                       MySQLConfig['user'],
                       MySQLConfig['passwd'],
                       MySQLConfig['db'])
    session_info = mysql_op.check_session(session)

    if session_info is not None:
        response_data = {'priority_fields': conf.all_fields_fw_upgrade_cache_export_filter.get('priority')}
        email = session_info['email']
        response_data.update({'user': email.split("@")[0], 'web_user_role': session_info.get('role_id'),
                              'isGlobal': isGlobal})

        response = render(request, str, response_data)
        response.set_cookie("session_id", session, conf.session_ttl)
        return response
    else:
        logger.warn("get_firmware_upgrade_cache_export_info. checking-session failed. the session is ------>%s" % session)
        return HttpResponseRedirect(str_login)


@check_authority
def read_firmware_upgrade_cache_export_info(request):
    request_body = request.POST.copy()

    logger.info("read_firmware_upgrade_cache_export_info started. the request is ------>%s" % request_body)

    content_type = request.META['CONTENT_TYPE']
    if 'application/json' in content_type:
        request_body.update(json.loads(request.body))

    try:
        response = FirmwareUpgradeCacheInfo.get_data_mysql_by_page(request_body)
        response_count = FirmwareUpgradeCacheInfo.get_data_mysql_count(request_body)
        response_data = response['responseBody']
        records_filtered = response_count['responseBody']

        records_total_count = FirmwareUpgradeCacheInfo.get_data_mysql_count({"firmwareId": ""})
        records_total = records_total_count["responseBody"]
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        raise

    if type(response_data) is type(list()):
        data = {'data': response_data, 'recordsFiltered': records_filtered, 'recordsTotal': records_total}
    elif type(response_data) is type(dict()):
        response_temp = [response_data]
        data = {'data': response_temp, 'recordsFiltered': 1, 'recordsTotal': records_total}
    else:
        response_temp = []
        data = {'data': response_temp, 'recordsFiltered': 0, 'recordsTotal': records_total}
        logger.info("the type of the data from DAL is -----> %s" % type(response_data))
    return HttpResponse(json.dumps(data))


def get_firmware_upgrade_cache_mainland_info(request):
    str = 'firmware/firmware-upgrade-cache-mainland/firmware-upgrade-cache-info-mainland.html'
    str_login = '/webManager/login'
    try:
        session = request.COOKIES["session_id"]
    except:
        logger.error('ERROR, the user has not logined. %s', traceback.format_exc())
        return HttpResponseRedirect(str_login)

    mysql_op = MysqlOp(MySQLConfig['host'],
                       MySQLConfig['port'],
                       MySQLConfig['user'],
                       MySQLConfig['passwd'],
                       MySQLConfig['db'])
    session_info = mysql_op.check_session(session)

    if session_info is not None:
        response_data = {'priority_fields': conf.all_fields_fw_upgrade_cache_mainland_filter.get('priority')}
        email = session_info['email']
        response_data.update({'user': email.split("@")[0], 'web_user_role': session_info.get('role_id'),
                              'isGlobal': isGlobal})

        response = render(request, str, response_data)
        response.set_cookie("session_id", session, conf.session_ttl)
        return response
    else:
        logger.warn("get_firmware_upgrade_cache_export_info. checking-session failed. the session is ------>%s" % session)
        return HttpResponseRedirect(str_login)


@check_authority
def read_firmware_upgrade_cache_mainland_info(request):
    request_body = request.POST.copy()

    logger.info("read_firmware_upgrade_cache_export_info started. the request is ------>%s" % request_body)

    content_type = request.META['CONTENT_TYPE']
    if 'application/json' in content_type:
        request_body.update(json.loads(request.body))

    try:
        response = FirmwareUpgradeCacheMainlandInfo.get_data_mysql_by_page(request_body)
        response_count = FirmwareUpgradeCacheMainlandInfo.get_data_mysql_count(request_body)
        response_data = response['responseBody']
        records_filtered = response_count['responseBody']

        records_total_count = FirmwareUpgradeCacheMainlandInfo.get_data_mysql_count({"firmwareId": ""})
        records_total = records_total_count["responseBody"]
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        raise

    if type(response_data) is type(list()):
        data = {'data': response_data, 'recordsFiltered': records_filtered, 'recordsTotal': records_total}
    elif type(response_data) is type(dict()):
        response_temp = [response_data]
        data = {'data': response_temp, 'recordsFiltered': 1, 'recordsTotal': records_total}
    else:
        response_temp = []
        data = {'data': response_temp, 'recordsFiltered': 0, 'recordsTotal': records_total}
        logger.info("the type of the data from DAL is -----> %s" % type(response_data))
    return HttpResponse(json.dumps(data))


def get_firmware_upgrade_relationship_info(request):
    str = 'firmware/firmware-upgrade-relationship/firmware-upgrade-relationship.html'
    str_login = '/webManager/login'
    try:
        session = request.COOKIES["session_id"]
    except:
        logger.error('ERROR, the user has not logined. %s', traceback.format_exc())
        return HttpResponseRedirect(str_login)

    mysql_op = MysqlOp(MySQLConfig['host'],
                       MySQLConfig['port'],
                       MySQLConfig['user'],
                       MySQLConfig['passwd'],
                       MySQLConfig['db'])
    session_info = mysql_op.check_session(session)

    if session_info is not None:
        response_data = {'priority_fields': conf.all_fields_firmware_upgrade_relationship_mainland_filter.get('priority')}
        email = session_info['email']
        response_data.update({'user': email.split("@")[0], 'web_user_role': session_info.get('role_id'),
                              'isGlobal': isGlobal})

        response = render(request, str, response_data)
        response.set_cookie("session_id", session, conf.session_ttl)
        return response
    else:
        logger.warn("get_firmware_upgrade_cache_export_info. checking-session failed. the session is ------>%s" % session)
        return HttpResponseRedirect(str_login)


@check_authority
def read_firmware_upgrade_relationship_info(request):
    request_body = request.POST.copy()

    logger.info("read_firmware_upgrade_cache_export_info started. the request is ------>%s" % request_body)

    content_type = request.META['CONTENT_TYPE']
    if 'application/json' in content_type:
        request_body.update(json.loads(request.body))

    try:
        response = FirmwareUpgradeRelationshipInfo.get_data_mysql_by_page(request_body)
        response_count = FirmwareUpgradeRelationshipInfo.get_data_mysql_count(request_body)
        response_data = response['responseBody']
        records_filtered = response_count['responseBody']

        records_total_count = FirmwareUpgradeRelationshipInfo.get_data_mysql_count({"firmwareId": ""})
        records_total = records_total_count["responseBody"]
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        raise

    if type(response_data) is type(list()):
        data = {'data': response_data, 'recordsFiltered': records_filtered, 'recordsTotal': records_total}
    elif type(response_data) is type(dict()):
        response_temp = [response_data]
        data = {'data': response_temp, 'recordsFiltered': 1, 'recordsTotal': records_total}
    else:
        response_temp = []
        data = {'data': response_temp, 'recordsFiltered': 0, 'recordsTotal': records_total}
        logger.info("the type of the data from DAL is -----> %s" % type(response_data))
    return HttpResponse(json.dumps(data))


def get_firmware_degrade_relationship_info(request):
    str = 'firmware/firmware-degrade-relationship/firmware-degrade-relationship.html'
    str_login = '/webManager/login'
    try:
        session = request.COOKIES["session_id"]
    except:
        logger.error('ERROR, the user has not logined. %s', traceback.format_exc())
        return HttpResponseRedirect(str_login)

    mysql_op = MysqlOp(MySQLConfig['host'],
                       MySQLConfig['port'],
                       MySQLConfig['user'],
                       MySQLConfig['passwd'],
                       MySQLConfig['db'])
    session_info = mysql_op.check_session(session)

    if session_info is not None:
        response_data = {'priority_fields': conf.all_fields_firmware_degrade_relationship_mainland_filter.get('priority')}
        email = session_info['email']
        response_data.update({'user': email.split("@")[0], 'web_user_role': session_info.get('role_id'),
                              'isGlobal': isGlobal})

        response = render(request, str, response_data)
        response.set_cookie("session_id", session, conf.session_ttl)
        return response
    else:
        logger.warn("get_firmware_upgrade_cache_export_info. checking-session failed. the session is ------>%s" % session)
        return HttpResponseRedirect(str_login)


@check_authority
def read_firmware_degrade_relationship_info(request):
    request_body = request.POST.copy()

    logger.info("read_firmware_upgrade_cache_export_info started. the request is ------>%s" % request_body)

    content_type = request.META['CONTENT_TYPE']
    if 'application/json' in content_type:
        request_body.update(json.loads(request.body))

    try:
        response = FirmwareDegradeRelationshipInfo.get_data_mysql_by_page(request_body)
        response_count = FirmwareDegradeRelationshipInfo.get_data_mysql_count(request_body)
        response_data = response['responseBody']
        records_filtered = response_count['responseBody']

        records_total_count = FirmwareDegradeRelationshipInfo.get_data_mysql_count({"firmwareId": ""})
        records_total = records_total_count["responseBody"]
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        raise

    if type(response_data) is type(list()):
        data = {'data': response_data, 'recordsFiltered': records_filtered, 'recordsTotal': records_total}
    elif type(response_data) is type(dict()):
        response_temp = [response_data]
        data = {'data': response_temp, 'recordsFiltered': 1, 'recordsTotal': records_total}
    else:
        response_temp = []
        data = {'data': response_temp, 'recordsFiltered': 0, 'recordsTotal': records_total}
        logger.info("the type of the data from DAL is -----> %s" % type(response_data))
    return HttpResponse(json.dumps(data))


def get_firmware_suitable_model_info(request):
    str = 'firmware/firmware-suitable-model/firmware-suitable-model.html'
    str_login = '/webManager/login'
    try:
        session = request.COOKIES["session_id"]
    except:
        logger.error('ERROR, the user has not logined. %s', traceback.format_exc())
        return HttpResponseRedirect(str_login)

    mysql_op = MysqlOp(MySQLConfig['host'],
                       MySQLConfig['port'],
                       MySQLConfig['user'],
                       MySQLConfig['passwd'],
                       MySQLConfig['db'])
    session_info = mysql_op.check_session(session)

    if session_info is not None:
        response_data = {'priority_fields': conf.all_fields_firmware_suitable_model_mainland_filter.get('priority')}
        email = session_info['email']
        response_data.update({'user': email.split("@")[0], 'web_user_role': session_info.get('role_id'),
                              'isGlobal': isGlobal})

        response = render(request, str, response_data)
        response.set_cookie("session_id", session, conf.session_ttl)
        return response
    else:
        logger.warn("get_firmware_upgrade_cache_export_info. checking-session failed. the session is ------>%s" % session)
        return HttpResponseRedirect(str_login)



@check_authority
def read_firmware_suitable_model_info(request):
    request_body = request.POST.copy()

    logger.info("read_firmware_upgrade_cache_export_info started. the request is ------>%s" % request_body)

    content_type = request.META['CONTENT_TYPE']
    if 'application/json' in content_type:
        request_body.update(json.loads(request.body))

    try:
        response = FirmwareSuitableModelInfo.get_data_mysql_by_page(request_body)
        response_count = FirmwareSuitableModelInfo.get_data_mysql_count(request_body)
        response_data = response['responseBody']
        records_filtered = response_count['responseBody']

        records_total_count = FirmwareSuitableModelInfo.get_data_mysql_count({"firmwareId": ""})
        records_total = records_total_count["responseBody"]
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        raise

    if type(response_data) is type(list()):
        data = {'data': response_data, 'recordsFiltered': records_filtered, 'recordsTotal': records_total}
    elif type(response_data) is type(dict()):
        response_temp = [response_data]
        data = {'data': response_temp, 'recordsFiltered': 1, 'recordsTotal': records_total}
    else:
        response_temp = []
        data = {'data': response_temp, 'recordsFiltered': 0, 'recordsTotal': records_total}
        logger.info("the type of the data from DAL is -----> %s" % type(response_data))
    return HttpResponse(json.dumps(data))


def get_firmware_rollback_task_info(request):
    str = 'firmware/firmware-rollback-task/firmware-rollback-task-info.html'
    str_login = '/webManager/login'
    try:
        session = request.COOKIES["session_id"]
    except:
        logger.error('ERROR, the user has not logined. %s', traceback.format_exc())
        return HttpResponseRedirect(str_login)

    mysql_op = MysqlOp(MySQLConfig['host'],
                       MySQLConfig['port'],
                       MySQLConfig['user'],
                       MySQLConfig['passwd'],
                       MySQLConfig['db'])
    session_info = mysql_op.check_session(session)

    if session_info is not None:
        response_data = {'priority_fields': conf.all_fields_fw_rollback_task_mainland_filter.get('priority')}
        email = session_info['email']
        response_data.update({'user': email.split("@")[0], 'web_user_role': session_info.get('role_id'),
                              'isGlobal': isGlobal})

        response = render(request, str, response_data)
        response.set_cookie("session_id", session, conf.session_ttl)
        return response
    else:
        logger.warn("get_firmware_rollback_task_info. checking-session failed. the session is ------>%s" % session)
        return HttpResponseRedirect(str_login)


@check_authority
def read_firmware_rollback_task_info(request):
    request_body = request.POST

    logger.info("read_firmware_rollback_task_info started. the request is ------>%s" % request_body)

    try:
        response = FirmwareRollbackTaskInfo.get_data_mysql_by_page(request_body)
        response_count = FirmwareRollbackTaskInfo.get_data_mysql_count(request_body)
        response_data = response['responseBody']
        records_filtered = response_count['responseBody']
        records_total_count = FirmwareRollbackTaskInfo.get_data_mysql_count(
            {"modelId": "", "hardwareType": "", "hardwareVersion": ""})
        records_total = records_total_count["responseBody"]
    except:
        logger.error("reading model info by page failed in getting data in models-layer. %s", traceback.format_exc())
        raise

    if type(response_data) is type(list()):
        data = {'data': response_data, 'recordsFiltered': records_filtered, 'recordsTotal': records_total}
    elif type(response_data) is type(dict()):
        response_temp = [response_data]
        data = {'data': response_temp, 'recordsFiltered': 1, 'recordsTotal': records_total}
    else:
        response_temp = []
        data = {'data': response_temp, 'recordsFiltered': 0, 'recordsTotal': records_total}
        logger.info("the type of the data from DAL is -----> %s" % type(response_data))

    for each in data['data']:
        for key in list(each.keys()):
            if each[key] == ' ' or each[key] == '' or each[key] == 'null' or each[key] is None:
                each[key] = '-'
    return HttpResponse(json.dumps(data))


@check_authority
def get_firmware_rollback_task_extra_info(request):
    str_device_detail = 'firmware/firmware-rollback-task/firmware-rollback-task-extra-info.html'

    request_body = request.POST.copy()

    logger.info("get_firmware_rollback_task_extra_info started. the request is ------>%s" % request_body)

    firmware_id = request_body.get('firmwareId', '')
    template = loader.get_template(str_device_detail)

    try:
        response = FirmwareRollbackTaskInfo.get_data_mysql_exactly({"firmwareId": firmware_id})  # queried by modelId
        response_firmware_rollback_task_info = response['responseBody']

        if response_firmware_rollback_task_info == '' or response_firmware_rollback_task_info == 'null':
            response_firmware_rollback_info_filter = 'null'
        else:
            response_firmware_rollback_info_filter = conf.all_fields_fw_rollback_task_mainland_filter.get('other')
            for each in response_firmware_rollback_info_filter:
                field_name_en = each['field_name_en']
                each['field_value'] = response_firmware_rollback_task_info.get(field_name_en, '-')  # filter operation
                if each['field_value'] == ' ' or each['field_value'] == '' or each['field_value'] == 'null' or each[
                    'field_value'] is None:
                    each['field_value'] = '-'
                if each.get('value_type', '') == 'date':
                    date_value = each['field_value']
                    if date_value is not None and date_value != '' and date_value != 'null':
                        each['field_value'] = datetime.datetime.fromtimestamp(date_value / 1000)
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        response_firmware_rollback_info_filter = 'fail'

    data = {'firmware_rollback_task': response_firmware_rollback_info_filter}
    return HttpResponse(json.dumps({'html': template.render(data)}))