# -*- coding:utf-8 -*-
#
# Copyright (c) 2017, TP-Link Co.,Ltd.
# Author:  yuzhijiang <yuzhijiang@tp-link.com.cn>
# Created: 2017-10-10
#
#
from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^getFactoryDataInfo$', views.get_factory_data_info, name='get_factory_data_info'),
    url(r'^readFactoryDataInfo$', views.read_factory_data_info, name='read_factory_data_info'),
    url(r'^getFactoryDataExtraInfo$', views.get_factory_data_extra_info, name='get_factory_data_extra_info'),
    url(r'^readTargetEditingFactoryDataInfo$', views.read_target_editing_factory_data_info,
        name='read_target_editing_factory_data_info'),
    url(r'^modifyFactoryDataInfo$', views.modify_factory_data_info, name='modify_factory_data_info'),
    url(r'^delFactoryDataInfo$', views.del_factory_data_info, name='del_factory_data_info'),
    url(r'^addFactoryDataInfo$', views.add_factory_data_info, name='add_factory_data_info'),

    url(r'^getFactoryDataInfoBeta$', views.get_factory_data_info_beta, name='get_factory_data_info_beta'),
    url(r'^readFactoryDataInfoBeta$', views.read_factory_data_info_beta, name='read_factory_data_info_beta'),
    url(r'^addFactoryDataInfoBeta$', views.add_factory_data_info_beta, name='add_factory_data_info_beta'),
    url(r'^delFactoryDataInfoBeta$', views.del_factory_data_info_beta, name='del_factory_data_info_beta'),

    url(r'^getModelInfo$', views.get_model_info, name='get_model_info'),
    url(r'^readModelInfo$', views.read_model_info, name='read_model_info')
]
