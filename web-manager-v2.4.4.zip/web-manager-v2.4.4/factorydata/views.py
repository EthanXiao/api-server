# -*- coding:utf-8 -*-
#
# Copyright (c) 2017, TP-Link Co.,Ltd.
# Author:  yuzhijiang <yuzhijiang@tp-link.com.cn>
# Created: 2017-10-10
#
#
import copy
import datetime
import json
import logging
import time
import traceback

from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader

from common.DatabaseClient import getDeviceInfoGlobalKey
from common.mysql_dao import MysqlOp
from factorydata.datasave import FactoryBasic
from factorydata.models import DeviceFactoryInfo, ModelInfo, DeviceFactoryInfoBeta
from interceptor.auth_interceptor import check_authority, check_super_admin_authority
from webmanager.conf import conf
from webmanager.settings import MySQLConfig, Config

logger = logging.getLogger(__name__)
isGlobal = Config['isGlobal']


def get_factory_data_info(request):
    str = 'factorydata/factorydata/factorydata-info.html'
    str_login = '/webManager/login'
    try:
        session = request.COOKIES["session_id"]
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        return HttpResponseRedirect(str_login)

    mysql_op = MysqlOp(MySQLConfig['host'],
                       MySQLConfig['port'],
                       MySQLConfig['user'],
                       MySQLConfig['passwd'],
                       MySQLConfig['db'])
    session_info = mysql_op.check_session(session)

    if session_info is not None:
        response_data = {'priority_fields': conf.all_fields_factorydata_filter.get('priority')}
        email = session_info['email']
        response_data.update({'user': email.split("@")[0], 'web_user_role': session_info.get('role_id'),
                              'isGlobal': isGlobal})

        response = render(request, str, response_data)
        response.set_cookie("session_id", session, conf.session_ttl)
        return response
    else:
        logger.warn("get_factory_data_info. checking-session failed. the session is ------>%s" % session)
        return HttpResponseRedirect(str_login)


@check_authority
def read_factory_data_info(request):
    request_body = request.POST.copy()

    if isGlobal:
        logger.info("read_factory_data_info started. the request is ------>%s" % request_body)

        content_type = request.META['CONTENT_TYPE']
        if 'application/json' in content_type:
            request_body.update(json.loads(request.body))

        # time-format converting
        start_time_request = request_body.get('startTime')
        if start_time_request is None or start_time_request == "null" or start_time_request == '':
            start_time_msecs = 0
        else:
            start_time_temp = start_time_request.split('-')
            start_time = []
            for each in start_time_temp:
                start_time.append(int(each))
            start_time = start_time + [0, 0, 0, 0, 0, 0]
            start_time_msecs = time.mktime(start_time) * 1000

        end_time_request = request_body.get('endTime')
        if end_time_request is None or end_time_request == "null" or end_time_request == '':
            end_time_msecs = time.time() * 1000
        else:
            end_time_temp = end_time_request.split('-')
            end_time = []
            for each in end_time_temp:
                end_time.append(int(each))
            end_time = end_time + [23, 59, 59, 0, 0, 0]
            end_time_msecs = time.mktime(end_time) * 1000

        request_body['beginDate'] = int(start_time_msecs)
        request_body['endDate'] = int(end_time_msecs)
        try:
            response = DeviceFactoryInfo.get_data_mysql_by_page(request_body)
            response_count = DeviceFactoryInfo.get_data_mysql_count(request_body)
            response_data = response['responseBody']
            records_filtered = response_count['responseBody']

            records_total_count = DeviceFactoryInfo.get_data_mysql_count({"mac": "", "beginDate": "", "endDate": ""})
            records_total = records_total_count["responseBody"]
        except:
            logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
            raise

        if type(response_data) is type(list()):
            data = {'data': response_data, 'recordsFiltered': records_filtered, 'recordsTotal': records_total}
        elif type(response_data) is type(dict()):
            response_temp = [response_data]
            data = {'data': response_temp, 'recordsFiltered': 1, 'recordsTotal': records_total}
        else:
            response_temp = []
            data = {'data': response_temp, 'recordsFiltered': 0, 'recordsTotal': records_total}
            logger.info("the type of the data from DAL is -----> %s" % type(response_data))
    else:
        try:
            response = DeviceFactoryInfo.get_data_mysql_by_page(request_body)
            response_data = response['responseBody']
        except:
            logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
            raise

        if type(response_data) is type(list()):
            data = {'data': response_data}
        elif type(response_data) is type(dict()):
            response_temp = [response_data]
            data = {'data': response_temp}
        else:
            response_temp = []
            data = {'data': response_temp}
            logger.info("the type of the data from DAL is -----> %s" % type(response_data))
    return HttpResponse(json.dumps(data))


@check_authority
def get_factory_data_extra_info(request):
    str_device_detail = 'factorydata/factorydata/factorydata-extra-info.html'

    request_body = request.POST.copy()
    model_id = request_body.get('modelId', '')
    template = loader.get_template(str_device_detail)

    logger.info("get_factory_data_extra_info started. the request is ------>%s" % request_body)

    try:
        response = ModelInfo.get_data_mysql_list({"modelId": model_id})  # queried by modelId
        response_device_model_list = response['responseBody']

        if len(response_device_model_list) == 0:
            response_model_info_filter = 'null'
        else:
            response_device_model = response_device_model_list[0]
            response_model_info_filter = conf.all_fields_device_filter.get('device_model_info')
            for each in response_model_info_filter:
                field_name_en = each['field_name_en']
                each['field_value'] = response_device_model.get(field_name_en, 'null')  # filter operation
                if each.get('value_type', '') == 'date':
                    date_value = each['field_value']
                    if date_value is not None and date_value != '' and date_value != 'null':
                        each['field_value'] = datetime.datetime.fromtimestamp(date_value / 1000)
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        response_model_info_filter = 'fail'

    data = {'device_model': response_model_info_filter}
    return HttpResponse(json.dumps({'html': template.render(data)}))


@check_authority
def read_target_editing_factory_data_info(request):
    request_body = request.POST.copy()

    logger.info("read_target_editing_factory_data_info started. the request is ------>%s" % request_body)

    str_account_editing = 'factorydata/factorydata/modify-modal-content.html'
    template = loader.get_template(str_account_editing)

    device_id = request_body['deviceId']
    try:
        response_factorydata = DeviceFactoryInfo.get_data_mysql_exactly({'deviceId': device_id})

        if response_factorydata == 'null':
            data = {'device': response_factorydata}
            return HttpResponse(json.dumps({'html': template.render(data)}))
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        response_factorydata = 'fail'
        data = {'device': response_factorydata}
        return HttpResponse(json.dumps({'html': template.render(data)}))

    try:
        response_model_list = ModelInfo.get_data_mysql_list({'modelId': response_factorydata.get('modelId')})
        if len(response_model_list['responseBody']) != 0:
            response_model = response_model_list['responseBody'][0]
        else:
            response_model = {}
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        response_factorydata = 'fail'
        data = {'device': response_factorydata}
        return HttpResponse(json.dumps({'html': template.render(data)}))

    response_factorydata.update(response_model)

    target_factorydata_info_filter = copy.deepcopy(conf.all_fields_factorydata_filter.get('priority', []))
    if {
        'field_name_cn': '型号ID',
        'field_name_en': 'modelId',
        'field_value': {
            'data': 'modelId',
            'className': 'modelId',
            'width': '7%'
        },
    } in target_factorydata_info_filter:
        target_factorydata_info_filter.remove({
            'field_name_cn': '型号ID',
            'field_name_en': 'modelId',
            'field_value': {
                'data': 'modelId',
                'className': 'modelId',
                'width': '7%'
            },
        }, )
    target_factorydata_info_filter_model = copy.deepcopy(
        conf.all_fields_factorydata_filter.get('device_model_info', []))
    if {
        'field_name_cn': '型号ID',
        'field_name_en': 'modelId',
        'field_value': {
            'data': 'modelId',
            'className': 'modelId',
            'width': '7%'
        },
    } in target_factorydata_info_filter_model:
        target_factorydata_info_filter_model.remove({
            'field_name_cn': '型号ID',
            'field_name_en': 'modelId',
            'field_value': {
                'data': 'modelId',
                'className': 'modelId',
                'width': '7%'
            },
        }, )
    target_factorydata_info_filter = target_factorydata_info_filter + target_factorydata_info_filter_model

    for each in target_factorydata_info_filter:
        field_name_en = each['field_name_en']
        each['field_value'] = response_factorydata.get(field_name_en, '')  # filter operation
        if each.get('value_type', '') == 'date':
            date_value = each['field_value']
            if date_value is not None and date_value != '' and date_value != 'null':
                each['field_value'] = datetime.datetime.fromtimestamp(date_value / 1000)

    data = {'device': target_factorydata_info_filter}
    return HttpResponse(json.dumps({'html': template.render(data)}))


DEVICE_MAX_SIZE = conf.upload_device_factory_info_max_size


# this function is learned from opDataReceiver-saveFactoryDataInfo
@check_authority
def modify_factory_data_info(request):
    request_body = request.POST.copy()

    logger.info("modify_factory_data_info started. the request is ------>%s" % request_body)

    try:
        device_factory_info_list = [request_body]
        logger.info("modifyDeviceFactoryInfo request. device_factory_info: %s", device_factory_info_list)
        #
        # # Validate the length of deviceList
        if len(device_factory_info_list) > DEVICE_MAX_SIZE:
            logger.error("saveDeviceFactoryInfo:The size of deviceList exceed the limit of deviceList; "
                         "deviceList=%s", device_factory_info_list)

            data = {'result': 'false'}
            return HttpResponse(json.dumps(data))

        # Validate the format of device's info
        for device in device_factory_info_list:
            if not FactoryBasic.validate_factory_data(deviceId=device['deviceId'], mac=device['mac'], sn=device['sn'],
                                                      fwId=device['fwId'], hwId=device['hwId'],
                                                      recordTime=device['recordTime'],
                                                      categoryName=device['categoryName'], hwType=device['hwType'],
                                                      hwVersion=device['hwVersion']):
                logger.error("Abnormal device found: %s", device)
                data = {'result': 'false'}
                return HttpResponse(json.dumps(data))

        # modify device_factory_info in mysql
        if isGlobal:
            for device in device_factory_info_list:
                if DeviceFactoryInfo.get_data_mysql_exactly({'deviceId': device['deviceId']}) is not 'null':
                    # DeviceFactoryInfo.delete_redis_KEY(getDeviceInfoGlobalKey(device['deviceId']))
                    logger.warn("Duplicate device found: %s", device)

                model = FactoryBasic.save_model_with_hw_id(category=device['categoryName'], hwId=device['hwId'],
                                                           hwType=device['hwType'], hwVer=device['hwVersion'])
                new_device = DeviceFactoryInfo()
                new_device.deviceId = device['deviceId']
                new_device.modelId = model['modelId']
                new_device.mac = device['mac']
                new_device.sn = device['sn']
                new_device.firmwareId = device['fwId']
                new_device.productionDate = int(
                    time.mktime(time.strptime(device['recordTime'], '%Y-%m-%d %H:%M:%S'))) * 1000  # recordTime
                new_device.save()
        else:
            for device in device_factory_info_list:
                if DeviceFactoryInfo.get_data_mysql_exactly({'deviceId': device['deviceId']}) is not 'null':
                    DeviceFactoryInfo.delete_redis_KEY(getDeviceInfoGlobalKey(device['deviceId']))
                    logger.warn("Duplicate device found: %s", device)

                # saving model
                model = FactoryBasic.save_model_with_hw_id(category=device['categoryName'], hwId=device['hwId'],
                                                           hwType=device['hwType'], hwVer=device['hwVersion'])

                # saving device_factory_info to cassandra
                nosqlNewDevice = DeviceFactoryInfo()
                nosqlNewDevice.deviceId = device['deviceId']
                nosqlNewDevice.modelId = model['modelId']
                nosqlNewDevice.mac = device['mac']
                nosqlNewDevice.sn = device['sn']
                nosqlNewDevice.firmwareId = device['fwId']
                nosqlNewDevice.productionDate = int(time.mktime(time.strptime(
                    device['recordTime'], '%Y-%m-%d %H:%M:%S'))) * 1000
                nosqlNewDevice.hardwareType = device['hwType']
                nosqlNewDevice.hardwareVersion = device['hwVersion']
                nosqlNewDevice.categoryName = device['categoryName']
                nosqlNewDevice.hardwareId = device['hwId']
                nosqlNewDevice.version = 0
                nosqlNewDevice.save_mainland_nosql()

                # saving device_factory_info to mysql
                newDevice = DeviceFactoryInfo()
                newDevice.deviceId = device['deviceId']
                newDevice.modelId = model['modelId']
                newDevice.mac = device['mac']
                newDevice.sn = device['sn']
                newDevice.firmwareId = device['fwId']
                newDevice.productionDate = int(
                    time.mktime(time.strptime(device['recordTime'], '%Y-%m-%d %H:%M:%S'))) * 1000  # recordTime
                newDevice.save_mainland_mysql()

        data = {'result': 'true', 'modelId': model['modelId']}
        return HttpResponse(json.dumps(data))
    except:
        logger.error('saveDeviceFactoryInfo request failed. %s', traceback.format_exc())
        data = {'result': 'false'}
        return HttpResponse(json.dumps(data))


@check_authority
def add_factory_data_info(request):
    request_body = request.POST.copy()

    logger.info("add_factory_data_info started. the request is ------>%s" % request_body)

    try:
        session = request.COOKIES.get('session_id')
        if session is None:
            logger.error('add factory data ERROR, the user has not logined.')
            raise

        content_type = request.META['CONTENT_TYPE']
        if 'application/json' in content_type:
            request.POST = request.POST.copy()
            request.POST.update(json.loads(request.body))

        mysql_op = MysqlOp(MySQLConfig['host'],
                           MySQLConfig['port'],
                           MySQLConfig['user'],
                           MySQLConfig['passwd'],
                           MySQLConfig['db'])
        cloud_mgn_pass_info = mysql_op.get_cloud_mgn_pass(session)

        if cloud_mgn_pass_info is None:
            logger.warn('add factory data failed! session unauthorized! the unauthorized session is--------> %s',
                        session)
            raise

        logger.info('Checking session success! add device factory data. cloud user is--------> %s',
                    cloud_mgn_pass_info.get('email'))

        request_body['cloudMgnName'] = conf.email
        request_body['cloudMgnPass'] = conf.password

        response = DeviceFactoryInfo.add_data_mysql(request_body)

        if response.get('errMessage') == 'Success':
            data = {'result': 'true'}
            return HttpResponse(json.dumps(data))
        else:
            logger.error('saveDeviceFactoryInfo request failed. --------> %s',
                         traceback.format_exc())
            data = {'result': 'false'}
            return HttpResponse(json.dumps(data))
    except:
        logger.error('add factory data failed!--------> %s', traceback.format_exc())
        data = {'result': 'false'}
        return HttpResponse(json.dumps(data))


@check_super_admin_authority
def del_factory_data_info(request):
    request_body = request.POST.copy()

    logger.info("del_factory_data_info started. the request is ------>%s" % request_body)

    try:
        response = DeviceFactoryInfo.del_data_mysql(request_body)
        response_data = response['success']
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        response_data = "false"

    data = {'result': response_data}
    return HttpResponse(json.dumps(data))


def get_factory_data_info_beta(request):
    str = 'factorydata/factorydata-beta/factorydata-info-beta.html'
    str_login = '/webManager/login'
    try:
        session = request.COOKIES["session_id"]

        mysql_op = MysqlOp(MySQLConfig['host'],
                           MySQLConfig['port'],
                           MySQLConfig['user'],
                           MySQLConfig['passwd'],
                           MySQLConfig['db'])
        session_info = mysql_op.check_session(session)

        if session_info is not None:
            response_data = {'priority_fields': conf.all_fields_factorydata_filter.get('priority')}
            email = session_info['email']
            response_data.update({'user': email.split("@")[0], 'web_user_role': session_info.get('role_id')})

            response = render(request, str, response_data)
            response.set_cookie("session_id", session, conf.session_ttl)
            return response
        else:
            logger.warn("get_factory_data_info_beta. checking-session failed. the session is ------>%s" % session)
            return HttpResponseRedirect(str_login)
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        return HttpResponseRedirect(str_login)


@check_authority
def read_factory_data_info_beta(request):
    request_body = request.POST.copy()

    logger.info("read_factory_data_info_beta started. the request is ------>%s" % request_body)

    content_type = request.META['CONTENT_TYPE']
    if 'application/json' in content_type:
        request_body.update(json.loads(request.body))

    try:
        response = DeviceFactoryInfoBeta.get_data_mysql_by_page(request_body)
        response_count = DeviceFactoryInfoBeta.get_data_mysql_count(request_body)
        response_data_beta = response['responseBody']

        records_filtered = response_count['responseBody']

        records_total_count = DeviceFactoryInfoBeta.get_data_mysql_count({"deviceId": ""})

        records_total = records_total_count["responseBody"]

        if response_data_beta is not None and response_data_beta != 'null':

            response_data = []
            for each in response_data_beta:
                response_data_each = DeviceFactoryInfo.get_data_mysql_exactly({'deviceId': each['deviceId']})

                if response_data_each != 'null' and response_data_each != '':
                    response_data.append(response_data_each)
                else:
                    response_data.append(each)
            for each in response_data:
                for key in list(each.keys()):
                    if each[key] == '' or each[key] == 'null' or each[key] is None:
                        each[key] = '-'
            data = {'data': response_data, 'recordsFiltered': records_filtered, 'recordsTotal': records_total}
            return HttpResponse(json.dumps(data))
        else:
            response_temp = []
            data = {'data': response_temp, 'recordsFiltered': records_filtered, 'recordsTotal': records_total}
            return HttpResponse(json.dumps(data))

    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        raise


@check_authority
def add_factory_data_info_beta(request):
    try:
        session = request.COOKIES.get('session_id')
        if session is None:
            logger.error('add beta device ERROR, the user has not logined.')
            raise

        content_type = request.META['CONTENT_TYPE']
        if 'application/json' in content_type:
            request.POST = request.POST.copy()
            request.POST.update(json.loads(request.body))
        request_body = request.POST.copy()

        logger.info("add_factory_data_info_beta started. the request is ------>%s" % request_body)

        mysql_op = MysqlOp(MySQLConfig['host'],
                           MySQLConfig['port'],
                           MySQLConfig['user'],
                           MySQLConfig['passwd'],
                           MySQLConfig['db'])
        cloud_mgn_pass_info = mysql_op.get_cloud_mgn_pass(session)

        if cloud_mgn_pass_info is None:
            logger.warn('add beta device failed! session unauthorized! the unauthorized session is--------> %s',
                        session)
            raise

        logger.info('Checking session success! add beta device. cloud user is--------> %s',
                    cloud_mgn_pass_info.get('email'))

        request_body['cloudMgnName'] = conf.email
        request_body['cloudMgnPass'] = conf.password
        # device_list = ast.literal_eval(request_body.get('deviceList', []))

        response = DeviceFactoryInfoBeta.add_data_mysql(request_body)
        if response.get('errMessage') == 'Success':
            data = {'result': 'true'}
            return HttpResponse(json.dumps(data))
        else:
            logger.error('save beta device request failed. --------> %s',
                         traceback.format_exc())
            data = {'result': 'false'}
            return HttpResponse(json.dumps(data))
    except:
        logger.error('add factory data failed!--------> %s', traceback.format_exc())
        data = {'result': 'false'}
        return HttpResponse(json.dumps(data))


@check_authority
def del_factory_data_info_beta(request):
    content_type = request.META['CONTENT_TYPE']
    if 'application/json' in content_type:
        request.POST = request.POST.copy()
        request.POST.update(json.loads(request.body))

    request_body = {'deviceList': json.dumps([{'deviceId': request.POST['deviceId']}])}

    logger.info("del_factory_data_info_beta started. the request is ------>%s" % request_body)

    try:
        session = request.COOKIES.get('session_id')
        if session is None:
            logger.error('delete beta device ERROR, the user has not logined. %s', traceback.format_exc())
            raise

        mysql_op = MysqlOp(MySQLConfig['host'],
                           MySQLConfig['port'],
                           MySQLConfig['user'],
                           MySQLConfig['passwd'],
                           MySQLConfig['db'])
        cloud_mgn_pass_info = mysql_op.get_cloud_mgn_pass(session)

        if cloud_mgn_pass_info is None:
            logger.warn('delete beta device failed! session unauthorized! the unauthorized session is--------> %s',
                        session)
            raise

        logger.info('Checking session success! delete beta device operation. The cloud user is--------> %s',
                    cloud_mgn_pass_info.get('email'))

        request_body['cloudMgnName'] = conf.email
        request_body['cloudMgnPass'] = conf.password

        response = DeviceFactoryInfoBeta.del_data_mysql(request_body)

        if response.get('errMessage') == 'Success':
            data = {'result': 'true'}
            return HttpResponse(json.dumps(data))
        else:
            logger.error('delete beta device request failed. --------> %s',
                         traceback.format_exc())
            data = {'result': 'false'}
            return HttpResponse(json.dumps(data))
    except:
        logger.error('delete factory data failed!--------> %s', traceback.format_exc())
        data = {'result': 'false'}
        return HttpResponse(json.dumps(data))


def get_model_info(request):
    str = 'factorydata/model/model-info.html'
    str_login = '/webManager/login'
    try:
        session = request.COOKIES["session_id"]
    except:
        logger.error('ERROR, the user has not logined. %s', traceback.format_exc())
        return HttpResponseRedirect(str_login)

    mysql_op = MysqlOp(MySQLConfig['host'],
                       MySQLConfig['port'],
                       MySQLConfig['user'],
                       MySQLConfig['passwd'],
                       MySQLConfig['db'])
    session_info = mysql_op.check_session(session)

    if session_info is not None:
        response_data = {'priority_fields': conf.all_fields_factorydata_filter.get('device_model_info')}
        email = session_info['email']
        response_data.update({'user': email.split("@")[0], 'web_user_role': session_info.get('role_id')})

        response = render(request, str, response_data)
        response.set_cookie("session_id", session, conf.session_ttl)
        return response
    else:
        logger.warn("get_model_info. checking-session failed. the session is ------>%s" % session)
        return HttpResponseRedirect(str_login)


@check_authority
def read_model_info(request):
    request_body = request.POST.copy()

    logger.info("read_model_info started. the request is ------>%s" % request_body)
    try:
        response = ModelInfo.get_data_mysql_by_page(request_body)
        response_count = ModelInfo.get_data_mysql_count(request_body)
        response_data = response['responseBody']
        records_filtered = response_count['responseBody']
        records_total_count = ModelInfo.get_data_mysql_count({"modelId": "", "hardwareType": "", "hardwareVersion": ""})
        records_total = records_total_count["responseBody"]
    except:
        logger.error("reading model info by page failed in getting data in models-layer. %s", traceback.format_exc())
        raise

    if type(response_data) is type(list()):
        data = {'data': response_data, 'recordsFiltered': records_filtered, 'recordsTotal': records_total}
    elif type(response_data) is type(dict()):
        response_temp = [response_data]
        data = {'data': response_temp, 'recordsFiltered': 1, 'recordsTotal': records_total}
    else:
        response_temp = []
        data = {'data': response_temp, 'recordsFiltered': 0, 'recordsTotal': records_total}
        logger.info("the type of the data from DAL is -----> %s" % type(response_data))
    return HttpResponse(json.dumps(data))
