# -*- coding:utf-8 -*-

import os
import codecs
import traceback
import logging
import time
import thread

from factorydata.models import ModelInfo


logger = logging.getLogger(__name__)


class FactoryBasic:
    LINE_LENGTH = 9
    DEVICE_ID_LENGTH = 40
    FW_HW_LENGTH = 32
    SN_MAC_LENGTH = 12
    SN_MAX_LENGTH = 13
    DATE_LENGTH = 19

    # or len(recordTime) != cls.DATE_LENGTH
    @classmethod
    def validate_factory_data(cls, deviceId, mac, sn, fwId, hwId, recordTime, categoryName, hwType, hwVersion):
        if type(deviceId.encode("utf-8")) != str or len(deviceId) != cls.DEVICE_ID_LENGTH or \
                        type(mac.encode("utf-8")) != str or len(mac) < cls.SN_MAC_LENGTH or \
                        type(sn.encode("utf-8")) != str or len(sn) > cls.SN_MAX_LENGTH or \
                        type(fwId.encode("utf-8")) != str or len(fwId) != cls.FW_HW_LENGTH or \
                        type(hwId.encode("utf-8")) != str or len(hwId) != cls.FW_HW_LENGTH or \
                        type(recordTime.encode("utf-8")) != str or \
                        type(categoryName.encode("utf-8")) != str or len(categoryName) == 0 or \
                        type(hwType.encode("utf-8")) != str or len(hwType) == 0 or \
                        type(hwVersion.encode("utf-8")) != str or len(hwVersion) == 0:
            return False
        try:
            # test whether time format is correct
            int(time.mktime(time.strptime(recordTime, '%Y-%m-%d %H:%M:%S'))) * 1000
        except:
            logger.error('saveDeviceFactoryInfoGlobal time-format validating failed. %s', traceback.format_exc())
            return False
        return True

    @classmethod
    def save_model_with_hw_id(self, hwType, hwVer, hwId, category):
        request_body = {}
        request_body['hardwareVersion'] = hwVer
        request_body['hardwareType'] = hwType
        request_body['hardwareId'] = hwId
        response_model = ModelInfo.get_data_mysql_exactly(request_body)
        model = response_model['responseBody']

        if not model or model == 'null':
            model = ModelInfo()
            model.hardwareType = hwType
            model.hardwareVersion = hwVer
            model.hardwareId = hwId
            model.categoryName = category
            model.save()
            result = ModelInfo.get_data_mysql_exactly(request_body)
            return result['responseBody']

        if category != model.get('categoryName'):
            request_body['modelId'] = model.get('modelId')
            request_body['categoryName'] = category
            result = ModelInfo.update_data_mysql(request_body)
            if result['responseBody'] == 'true':
                return request_body
            else:
                raise
        return model


        # @classmethod
        # def completeUploadLog(cls, sourceFileName, lineNum):
        #     try:
        #         uploadLog = FactoryFileUploadLog.find(fileName=sourceFileName)
        #         uploadLog.itemQuantity = lineNum
        #         uploadLog.status = 'SUCCESS'
        #         uploadLog.statusMsg = 'save success'
        #         uploadLog.save()
        #     except:
        #         return
        #
        # @classmethod
        # def saveFactoryInfo2MysqlGlobal(cls, fileName, deviceId, model, mac, sn, fwId, recordTime, hwType, hwVer, hwId):
        #     olDdevice = DeviceFactoryInfo.findById(deviceId)
        #
        #     device = DeviceFactoryInfo()
        #     device.deviceId = deviceId
        #     device.modelId = model.modelId
        #     device.mac = mac
        #     device.sn = sn
        #     device.firmwareId = fwId
        #     device.productionDate = int(time.mktime(time.strptime(recordTime, '%Y-%m-%d %H:%M:%S'))) * 1000  # recordTime
        #     device.save()
        #
        #     if model.hardwareId != hwId:
        #         logger.warn('hwId of device %s conflict with model. hwId:%s, model.hwId:%s.', deviceId, hwId, model.hardwareId)
        #         FactoryDailyReport.addDuplicateFactoryDataRecord(fileName, deviceId, 'HW_ID CONFLICT', model.hardwareId, hwId)
        #
        #     if olDdevice is not None:
        #         deleteRedisKEY(getDeviceInfoGlobalKey(deviceId))
        #         device.diffCompare(fileName, olDdevice)
        #         if model.hardwareId != hwId or model.hardwareVersion != hwVer or model.hardwareType != hwType:
        #             original = model.hardwareType + r'|' + model.hardwareVersion + r'|' + model.hardwareId
        #             duplicate = hwType + r'|' + hwVer + r'|' + hwId
        #             FactoryDailyReport.addDuplicateFactoryDataRecord(fileName, deviceId, 'HW CONFLICT', original, duplicate)
        #
        # @classmethod
        # def saveFactoryInfo2MysqlMainland(cls, deviceId, model, mac, sn, fwId, recordTime):
        #     device = DeviceFactoryInfo()
        #     device.deviceId = deviceId
        #     device.modelId = model.modelId
        #     device.mac = mac
        #     device.sn = sn
        #     device.firmwareId = fwId
        #     device.productionDate = int(time.mktime(time.strptime(recordTime, '%Y-%m-%d %H:%M:%S'))) * 1000  # recordTime
        #     device.save()
        #
        # @classmethod
        # def saveFactoryInfo2CassMainland(cls, fileName, deviceId, mac, sn, fwId, hwId,
        #                                  recordTime, category, hwType, hwVer, model, version):
        #     olddevice = NosqlDeviceFactoryInfo.findUnique(deviceId)
        #
        #     deviceNew = NosqlDeviceFactoryInfo()
        #     deviceNew.deviceId = deviceId
        #     deviceNew.modelId = model.modelId
        #     deviceNew.mac = mac
        #     deviceNew.sn = sn
        #     deviceNew.firmwareId = fwId
        #     deviceNew.productionDate = int(time.mktime(time.strptime(recordTime, '%Y-%m-%d %H:%M:%S'))) * 1000
        #     deviceNew.hardwareType = hwType
        #     deviceNew.hardwareVersion = hwVer
        #     deviceNew.categoryName = category
        #     deviceNew.hardwareId = hwId
        #     deviceNew.version = version
        #     deviceNew.save()
        #
        #     if model.hardwareId != hwId:
        #         logger.warn('hwId of device %s conflict with model. hwId:%s, model.hwId:%s.', deviceId, hwId, model.hardwareId)
        #         FactoryDailyReport.addDuplicateFactoryDataRecord(fileName, deviceId, 'HW_ID CONFLICT', model.hardwareId, hwId)
        #
        #     if olddevice is not None:
        #         deleteRedisKEY(getDeviceInfoKey(deviceId))
        #         deviceNew.diffCompare(fileName, olddevice)
