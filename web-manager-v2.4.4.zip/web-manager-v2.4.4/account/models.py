# -*- coding:utf-8 -*-
#
# Copyright (c) 2017, TP-Link Co.,Ltd.
# Author:  yuzhijiang <yuzhijiang@tp-link.com.cn>
# Created: 2017-9-20
#
#
import logging
import traceback

from common.common_base_model import CommonBase
from common.common_exception import DalServerError
from common.http_client import DALClient
from webmanager.conf import conf
from webmanager.settings import Config

dalVersionPath = Config['dalVersionPath']
logger = logging.getLogger(__name__)
isGlobal = Config['isGlobal']


class Account(CommonBase):
    getExactlyURL = 'getAccountInfo?'
    getURL = 'getAccountInfoListFuzzilyByPage?'
    getCountURL = 'getAccountInfoCountFuzzily?'
    updateURL = 'updateAccountInfo?'
    addURL = 'setAccountInfo?'
    delURL = 'delAccountInfo?'

    accountId = ''
    email = ''
    mobile = ''
    username = ''
    status = ''
    registerDate = ''
    lockEndDate = ''

    def __init__(self, **kwargs):
        for k, v in kwargs.iteritems():
            setattr(self, k, v)

    # paging query
    # if the query conditions are all null, the function will output all the data in the target table page by page.
    # response data of type-list
    @classmethod
    def get_data_mysql_by_page(cls, request_body):
        try:
            dal_client = DALClient()
            start_page = long(request_body['start'])
            page_length = long(request_body['length'])
            params_url_tempt = {}
            params_url_tempt['start'] = start_page
            params_url_tempt['length'] = page_length

            params_url_tempt['beginDate'] = request_body['beginDate']
            params_url_tempt['endDate'] = request_body['endDate']

            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()

            params_url = dal_client.group_params(params_url_tempt)
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getURL + query_id + '&' + params_url

            response = dal_client.send_post_request(url, params)
        except DalServerError:
            logger.error('paging query failed. %s', traceback.format_exc())
            raise
        finally:
            dal_client.close()
        return response

    # obtain the count of the records that satisfy the query conditions
    # if the query conditions are all null, the output is the total number of records in the queried table
    @classmethod
    def get_data_mysql_count(cls, request_body):
        try:
            dal_client = DALClient()
            params_url_tempt = {}
            params_url_tempt['beginDate'] = request_body['beginDate']
            params_url_tempt['endDate'] = request_body['endDate']

            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()

            params_url = dal_client.group_params(params_url_tempt)
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getCountURL + query_id + '&' + params_url

            response = dal_client.send_post_request(url, params)
        except DalServerError:
            raise
        finally:
            dal_client.close()
        # return self.convertDictToObj(response)
        return response

    # the response data of the function is of type-dict
    @classmethod
    def get_data_mysql_exactly(cls, request_body):
        try:
            dal_client = DALClient()
            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getExactlyURL + query_id

            response = dal_client.send_post_request(url, params)
        except DalServerError:
            raise
        finally:
            dal_client.close()
        # return self.convertDictToObj(response)

        return response

    @classmethod
    def update_data_mysql(cls, request_body):
        try:
            dal_client = DALClient()
            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.updateURL + query_id

            response = dal_client.send_post_request(url, params)

        except DalServerError:
            logger.error('update account info failed.')
            raise
        finally:
            dal_client.close()
        return response

    @classmethod
    def add_data_mysql(cls, request_body):
        try:
            dal_client = DALClient()
            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.addURL + query_id

            response = dal_client.send_post_request(url, params)

        except DalServerError:
            logger.error('add account info failed.')
            raise
        finally:
            dal_client.close()
        return response

    @classmethod
    def del_data_mysql(cls, request_body):
        try:
            dal_client = DALClient()
            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()

            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.delURL + query_id
            response = dal_client.send_post_request(url, params)

        except DalServerError:
            raise
        finally:
            dal_client.close()

        return response


class AccountInfo(CommonBase):
    getURL = 'getAccountInfoInfo?'
    updateURL = 'updateAccountInfoInfo?'
    addURL = 'setAccountInfoInfo?'
    delURL = 'delAccountInfoInfo?'

    accountInfoId = ''

    accountId = ''
    nickName = ''
    birthday = ''
    sex = ''
    avatarFileId = ''
    avatarUrl = ''

    def __init__(self, **kwargs):
        for k, v in kwargs.iteritems():
            setattr(self, k, v)

    @classmethod
    def get_data_mysql(cls, request_body):
        try:
            dal_client = DALClient()
            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getURL + query_id

            response = dal_client.send_post_request(url, params)
        except DalServerError:
            raise
        finally:
            dal_client.close()
        return response


    @classmethod
    def update_data_mysql(cls, request_body):
        try:
            dal_client = DALClient()
            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.updateURL + query_id

            response = dal_client.send_post_request(url, params)

        except DalServerError:
            logger.error('update account info failed.')
            raise
        finally:
            dal_client.close()
        return response


    @classmethod
    def add_data_mysql(cls, request_body):
        try:
            dal_client = DALClient()
            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.addURL + query_id

            response = dal_client.send_post_request(url, params)

        except DalServerError:
            logger.error('add account info failed.')
            raise
        finally:
            dal_client.close()
        return response

    @classmethod
    def del_data_mysql(cls, request_body):
        try:
            dal_client = DALClient()
            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()

            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.delURL + query_id
            response = dal_client.send_post_request(url, params)

        except DalServerError:
            raise
        finally:
            dal_client.close()

        return response


class RegisterInfo(CommonBase):
    getURL = 'getRegisterInfoInfo?'
    getURLMainland = 'getRegisterInfo?'

    accountId = ''

    def __init__(self, **kwargs):
        for k, v in kwargs.iteritems():
            setattr(self, k, v)

    @classmethod
    def get_data_cassandra(cls, request_body):
        try:
            dal_client = DALClient(host=conf.dalHostList.get(request_body.get('selectedRegion'), None))
            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()
            query_id = dal_client.get_query_id()
            if isGlobal:
                url = dalVersionPath + cls.getURL + query_id
            else:
                url = dalVersionPath + cls.getURLMainland + query_id
            response = dal_client.send_post_request(url, params)
        except DalServerError:
            raise
        finally:
            dal_client.close()

        return response


class DeviceUserInfo(CommonBase):
    getURL = 'getDeviceUserInfoList?'

    userId = ''
    ownerId = ''

    def __init__(self, **kwargs):
        for k, v in kwargs.iteritems():
            setattr(self, k, v)

    @classmethod
    def get_data_cassandra_list(cls, request_body):
        try:
            dal_client = DALClient(host=conf.dalHostList.get(request_body.get('selectedRegion'), None))

            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getURL + query_id
            response = dal_client.send_post_request(url, params)
        except DalServerError:
            raise
        finally:
            dal_client.close()

        return response


