# -*- coding:utf-8 -*-
#
#Copyright (c) 2017, TP-Link Co.,Ltd.
#Author:  yuzhijiang <yuzhijiang@tp-link.com.cn>
#Created: 2017-9-20
#
#
from django.conf.urls import url
from . import views


urlpatterns = [
    url(r'^getAccountInfo$', views.get_account_info, name='get_account_info'),
    url(r'^readAccountInfo$', views.read_account_info, name='read_account_info'),
    # url(r'^readDeviceDetailInfo$', views.read_device_detail_info, name='read_device_detail_info'),
    url(r'^readTargetEditingAccountInfo$', views.read_target_editing_account_info,
        name='read_target_editing_account_info'),
    url(r'^getAccountExtraInfo$', views.get_account_extra_info,name='get_account_extra_info'),
    url(r'^modifyAccountInfo$', views.modify_account_info, name='modify_account_info'),
    url(r'^addAccountInfo$', views.add_account_info, name='add_account_info'),
    url(r'^delAccountInfo$', views.del_account_info, name='del_account_info'),

    url(r'^readDeviceInfo$', views.read_device_info, name='read_device_info'),
]