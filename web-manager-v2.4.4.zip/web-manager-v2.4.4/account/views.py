# -*- coding:utf-8 -*-
#
# Copyright (c) 2017, TP-Link Co.,Ltd.
# Author:  yuzhijiang <yuzhijiang@tp-link.com.cn>
# Created: 2017-9-20
#
#
import copy
import datetime
import json
import logging
import time
import traceback

from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader

from common.digest_utils import get_sha1, get_string_md5, fuzzy_finder
from common.mysql_dao import MysqlOp
from device.models import Device, ConnectorIp
from interceptor.auth_interceptor import check_authority, check_super_admin_authority
from webmanager.conf import conf
from webmanager.settings import MySQLConfig, Config
from .models import Account, AccountInfo, RegisterInfo, DeviceUserInfo

logger = logging.getLogger(__name__)
isGlobal = Config['isGlobal']


def get_account_info(request):
    str = 'account/account-info.html'
    str_login = '/webManager/login'
    try:
        session = request.COOKIES["session_id"]
    except:
        return HttpResponseRedirect(str_login)

    mysql_op = MysqlOp(MySQLConfig['host'],
                       MySQLConfig['port'],
                       MySQLConfig['user'],
                       MySQLConfig['passwd'],
                       MySQLConfig['db'])
    session_info = mysql_op.check_session(session)

    if session_info is not None:
        if isGlobal:
            account_fields_priority = copy.deepcopy(conf.all_fields_account_filter.get('priority'))
        else:
            account_fields_priority = copy.deepcopy(conf.all_fields_account_filter_mainland.get('priority'))
        response_data = {'priority_fields_account': account_fields_priority}
        response_data.update({'priority_fields_device': conf.all_fields_device_filter.get('priority')})
        email = session_info['email']
        response_data.update({'user': email.split("@")[0], 'web_user_role': session_info.get('role_id'),
                              'region_list': conf.regionList, 'default_region': conf.defaultRegion,
                              'isGlobal': isGlobal})

        response = render(request, str, response_data)
        response.set_cookie("session_id", session, conf.session_ttl)

        return response
    else:
        logger.warn("get_account_info. checking-session failed. the session is ------>%s" % session)
        return HttpResponseRedirect(str_login)


@check_authority
def read_account_info(request):
    request_body = request.POST.copy()
    content_type = request.META['CONTENT_TYPE']
    if 'application/json' in content_type:
        request_body.update(json.loads(request.body))

    account_id = request_body.get('accountId', '')
    email = request_body.get('email', '')
    mobile = request_body.get('mobile', '')
    status = request_body.get('status', '')

    logger.info("read account priority-info started. the request is ------>%s" % request_body)
    # time-format converting
    start_time_request = request_body.get('startTime')
    if start_time_request is None or start_time_request == "null" or start_time_request == '':
        start_time_msecs = 0
    else:
        start_time_temp = start_time_request.split('-')
        start_time = []
        for each in start_time_temp:
            start_time.append(int(each))
        start_time = start_time + [0, 0, 0, 0, 0, 0]
        start_time_msecs = time.mktime(start_time) * 1000

    end_time_request = request_body.get('endTime')
    if end_time_request is None or end_time_request == "null" or end_time_request == '':
        end_time_msecs = time.time() * 1000
    else:
        end_time_temp = end_time_request.split('-')
        end_time = []
        for each in end_time_temp:
            end_time.append(int(each))
        end_time = end_time + [23, 59, 59, 0, 0, 0]
        end_time_msecs = time.mktime(end_time) * 1000

    records_total_count = Account.get_data_mysql_count({"email": "", "beginDate": "", "endDate": ""})
    records_total = records_total_count["responseBody"]

    if account_id is not None and account_id != "null" and account_id != '':
        try:
            response = Account.get_data_mysql_exactly({'accountId': account_id})
            response_filter = response['responseBody']
        except:
            logger.error("failed in getting account data by accountId from models-layer. %s", traceback.format_exc())
            raise

        response_temp = []
        if response_filter is None or response_filter == '' or response_filter == 'null':
            data = {'data': response_temp, 'recordsFiltered': 0, 'recordsTotal': records_total}
            logger.info("read account priority-info finished.")
            return HttpResponse(json.dumps(data))
        if email is not None and email != '':
            matched = fuzzy_finder(email, response_filter['email'])
            if not matched:
                data = {'data': response_temp, 'recordsFiltered': 0, 'recordsTotal': records_total}
                logger.info("read account priority-info finished.")
                return HttpResponse(json.dumps(data))

        if mobile is not None and mobile != '':
            matched = fuzzy_finder(mobile, response_filter['mobile'])
            if not matched:
                data = {'data': response_temp, 'recordsFiltered': 0, 'recordsTotal': records_total}
                logger.info("read account priority-info finished.")
                return HttpResponse(json.dumps(data))

        if status is not None and status != '':
            matched = (status == response_filter['status'])
            if not matched:
                data = {'data': response_temp, 'recordsFiltered': 0, 'recordsTotal': records_total}
                logger.info("read account priority-info finished.")
                return HttpResponse(json.dumps(data))
        if response_filter['registerDate'] < start_time_msecs or response_filter['registerDate'] > end_time_msecs:
            data = {'data': response_temp, 'recordsFiltered': 0, 'recordsTotal': records_total}
            logger.info("read account priority-info finished.")
            return HttpResponse(json.dumps(data))

        lock_end_date = response_filter['lockEndDate']
        if lock_end_date is not None and lock_end_date != '' and lock_end_date != 'null':
            if lock_end_date <= time.time() * 1000:
                response_filter['status'] = 'NORMAL'

        response_temp.append(response_filter)
        for each in response_temp:
            for key in list(each.keys()):
                if each[key] == '' or each[key] == 'null' or each[key] is None:
                    each[key] = '-'
        data = {'data': response_temp, 'recordsFiltered': 1, 'recordsTotal': records_total}
        logger.info("read account priority-info finished.")
        return HttpResponse(json.dumps(data))

    # if the request parameters does not has the value of accountId, paging query is directly implemented.
    request_body.pop('accountId')
    request_body['beginDate'] = int(start_time_msecs)
    request_body['endDate'] = int(end_time_msecs)
    try:
        response = Account.get_data_mysql_by_page(request_body)
        response_count = Account.get_data_mysql_count(request_body)
        response_data = response['responseBody']
        records_filtered = response_count['responseBody']
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        raise

    if type(response_data) is type(list()):
        response_temp = []
        for each in response_data:
            lock_end_date = each['lockEndDate']
            if lock_end_date is not None and lock_end_date != '' and lock_end_date != 'null' \
                    and each['status'] == 'LOCKED':
                # if the lock_end_date is before the present time, the locked status will be ineffective.
                # (That is, the status is normal indeed.)
                if lock_end_date <= time.time() * 1000:
                    each['status'] = 'NORMAL'
                    if status == 'LOCKED':
                        continue
            response_temp.append(each)
    else:
        response_temp = []
        records_filtered = 0
        logger.info("the type of the data from DAL is null.%s" % type(response_data))

    for each in response_temp:
        for key in list(each.keys()):
            if each[key] == '' or each[key] == 'null' or each[key] is None:
                each[key] = '-'
    data = {'data': response_temp, 'recordsFiltered': records_filtered, 'recordsTotal': records_total}
    logger.info("read account priority-info finished.")
    return HttpResponse(json.dumps(data))


@check_authority
def read_target_editing_account_info(request):
    request_body = request.POST
    str_account_editing = 'account/add-modify-modal-content.html'
    template = loader.get_template(str_account_editing)

    logger.info("read_target_editing_account_info started. the request is ------>%s" % request_body)

    try:
        response_1 = Account.get_data_mysql_exactly(request_body)
        response_account_1 = response_1['responseBody']

        account_version = response_account_1['version']
        response_account_1.pop('version')
        response_account_1['account_version'] = account_version
        response_account = response_account_1.copy()

        if isGlobal:
            response_2 = AccountInfo.get_data_mysql(request_body)
            response_account_2 = response_2['responseBody']

            if response_account_2 == "null" or response_account_2 == "" or response_account_2 is None:
                response_account_2 = []
            response_account.update(response_account_2)

    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        response_account = 'fail'
        data = {'account': response_account}
        return HttpResponse(json.dumps({'html': template.render(data)}))

    lock_end_date = response_account['lockEndDate']
    if lock_end_date is not None and lock_end_date != '' and lock_end_date != 'null':
        if lock_end_date <= time.time() * 1000:
            response_account['status'] = 'NORMAL'

    if isGlobal:
        target_account_info_filter = copy.deepcopy(conf.all_fields_account_filter.get('priority', []))
        target_account_info_filter = target_account_info_filter + list(conf.all_fields_account_filter.get('other', []))
    else:
        target_account_info_filter = copy.deepcopy(conf.all_fields_account_filter_mainland.get('priority', []))
    for each in target_account_info_filter:
        field_name_en = each['field_name_en']
        each['field_value'] = response_account.get(field_name_en, '')  # filter operation
        if each.get('value_type', '') == 'date':
            date_value = each['field_value']
            if date_value is not None and date_value != '' and date_value != 'null':
                each['field_value'] = datetime.datetime.fromtimestamp(date_value / 1000)

    data = {'account': target_account_info_filter}
    logger.info("read_target_editing_account_info finished. the result is ------>%s" % data)
    return HttpResponse(json.dumps({'html': template.render(data)}))


@check_authority
def get_account_extra_info(request):
    request_body = request.POST.copy()

    logger.info("get_account_extra_info started. the request is ------>%s" % request_body)

    try:
        response = Device.get_data_cassandra(request_body)
        response_data = response['responseBody']
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        raise

    try:
        response_1 = Account.get_data_mysql_exactly(request_body)
        response_account_1 = response_1['responseBody']

        response_account = response_account_1.copy()

        if isGlobal:
            response_2 = AccountInfo.get_data_mysql(request_body)
            response_account_2 = response_2['responseBody']
            if response_account_2 == "null" or response_account_2 == "" or response_account_2 is None:
                response_account_2 = {}
            response_account.update(response_account_2)

            response_account_filter = copy.deepcopy(
                conf.all_fields_account_filter.get('other') + conf.all_fields_account_filter.get(
                    'register_info'))
        else:
            response_account_filter = copy.deepcopy(
                conf.all_fields_account_filter_mainland.get('other') + conf.all_fields_account_filter.get(
                    'register_info'))

        response_3 = RegisterInfo.get_data_cassandra(request_body)
        response_register_info = response_3['responseBody']
        if response_register_info == "null" or response_register_info == "" or response_register_info is None:
            response_register_info = {}
        response_account.update(response_register_info)
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        raise

    for each in response_account_filter:
        field_name_en = each['field_name_en']
        each['field_value'] = response_account.get(field_name_en, '-')  # filter operation
        if each['field_value'] == '' or each['field_value'] == 'null':
            each['field_value'] = '-'
        if each.get('value_type', '') == 'date':
            date_value = each['field_value']
            if date_value is not None and date_value != '' and date_value != '-':
                each['field_value'] = datetime.datetime.fromtimestamp(date_value / 1000)
    if type(response_data) is type(list()):
        response_temp = response_data
    elif type(response_data) is type(dict()):
        response_temp = [response_data]
    else:
        response_temp = []
        logger.info("the type of the data from DAL is wrong.%s" % type(response_data))

    priority_fields_device = copy.deepcopy(conf.all_fields_device_filter.get('priority'))
    data = {'all_fields_account': response_account_filter,
            'priority_fields_device': priority_fields_device,
            'list_length': len(response_temp)}

    template = loader.get_template('account/account-extra-info.html')
    logger.info("get_account_extra_info finished. the result is ------>%s" % data)
    return HttpResponse(json.dumps({'html': template.render(data)}))


@check_authority
def modify_account_info(request):
    request_body = request.POST.copy()
    response_data = ""

    logger.info("modify_account_info started. the request is ------>%s" % request_body)

    try:
        # change the time format
        lock_end_date = request_body['lockEndDate']
        register_date = request_body['registerDate']
        birthday = request_body.get('birthday')
        if lock_end_date != 'null' and lock_end_date != '' and lock_end_date is not None:
            request_body['lockEndDate'] = int(time.mktime(time.strptime(lock_end_date, '%Y-%m-%d %H:%M:%S'))) * 1000
        if register_date != 'null' and register_date != '' and register_date is not None:
            request_body['registerDate'] = int(time.mktime(time.strptime(register_date, '%Y-%m-%d %H:%M:%S'))) * 1000
        if birthday != 'null' and birthday != '' and birthday is not None:
            request_body['birthday'] = int(time.mktime(time.strptime(birthday, '%Y-%m-%d %H:%M:%S'))) * 1000
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        data = {'result': 'false'}
        return HttpResponse(json.dumps(data))

    try:
        response_get_account_version = Account.get_data_mysql_exactly({'accountId': request_body['accountId']})
        version = response_get_account_version['responseBody'].get('version')
        request_body['version'] = version
        response_account = Account.update_data_mysql(request_body)
        response_data_account = response_account['success']

        if isGlobal:
            response_get_account_info_version = AccountInfo.get_data_mysql({'accountId': request_body['accountId']})

            if response_get_account_info_version['responseBody'] != 'null':
                version = response_get_account_info_version['responseBody'].get('version')
                request_body['version'] = version
                response_account_info = AccountInfo.update_data_mysql(request_body)
                response_data_account_info = response_account_info['responseBody']
            else:
                request_body['version'] = 0
                response_account_info = AccountInfo.add_data_mysql(request_body)
                response_data_account_info = response_account_info['responseBody']

            if response_data_account == 'true' and response_data_account_info == 'true':
                response_data = 'true'

        else:
            if response_data_account == 'true':
                response_data = 'true'

    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())

    data = {'result': response_data}
    logger.info("modify_account_info finished. the result is ------>%s" % data)
    return HttpResponse(json.dumps(data))


@check_authority
def add_account_info(request):
    request_body = request.POST.copy()

    logger.info("add_account_info started. the request is ------>%s" % request_body)

    password = request_body['password']
    password_sha = get_sha1(password)
    password_salt = get_string_md5(password)
    password_salt_sha = get_sha1(password_sha + password_salt)
    request_body['password'] = password_salt_sha

    response_data = "true"
    try:
        response = Account.add_data_mysql(request_body)
        response_data = response['success']
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())

    data = {'result': response_data}
    logger.info("add_account_info finished. the result is ------>%s" % data)
    return HttpResponse(json.dumps(data))


# the version must equal to that in the database, or the "deleting operation" will be failed.
# the version is not obtained from the front. It is fetched in this del_account_info function.
# this "deleting operation" is indeed an modifying operation.
@check_authority
def del_account_info(request):
    request_body = request.POST.copy()

    logger.info("del_account_info started. the request is ------>%s" % request_body)

    account_id = request_body["accountId"]
    response_data = "false"
    try:
        target_account = Account.get_data_mysql_exactly({"accountId": account_id})
        response_body = target_account["responseBody"]
        email_before_deleted = response_body.get("email")
        mobile_before_deleted = response_body.get("mobile")

        timestamp = str(int(round(time.time() * 1000)))
        if email_before_deleted is not None and email_before_deleted != '' and email_before_deleted != 'null'\
                and email_before_deleted != '-':
            email_after_deleted = email_before_deleted + '_' + timestamp[-8:]
            response_body['email'] = email_after_deleted
        if mobile_before_deleted is not None and mobile_before_deleted != '' and mobile_before_deleted != 'null' \
                and mobile_before_deleted != '-':
            mobile_after_deleted = mobile_before_deleted[-6:] + '_' + timestamp[-6:]
            response_body['mobile'] = mobile_after_deleted

        response_account = Account.update_data_mysql(response_body)
        response_account_data = response_account['success']

        if response_account_data == 'true':
            data = {'result': 'true'}
        else:
            data = {'result': response_data}

        logger.info("del_account_info finished. the result is ------>%s" % data)
        return HttpResponse(json.dumps(data))
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        data = {'result': response_data}
        return HttpResponse(json.dumps(data))


@check_authority
def read_device_info(request):
    request_body = request.POST.copy()

    logger.info("read_device_info started, in account-management. the request is ------>%s" % request_body)

    response_temp = []

    try:
        response = Device.get_data_cassandra(request_body)
        response_data = response.get('responseBody', [])

        for each in response_data:
            each.update({'role': 'Owner'})

        user_id = request_body['accountId']
        response_device_user = DeviceUserInfo.get_data_cassandra_list({'userId': user_id,
                                                                       'selectedRegion': request_body.get(
                                                                           'selectedRegion')})
        response_device_user_list = response_device_user.get('responseBody', [])
        if response_device_user_list == 'null' or response_device_user_list is None:
            response_device_user_list = []

        for each in response_device_user_list:
            device_id = each['deviceId']
            flag_temp = False
            for each_device in response_data:
                if device_id == each_device['deviceId']:
                    flag_temp = True
                    break
            if not flag_temp:
                each_device_response = Device.get_data_cassandra_exactly({'deviceId': device_id,
                                                                          'selectedRegion': request_body.get(
                                                                              'selectedRegion')})
                if each_device_response != 'null' and each_device_response is not None:
                    each_device_response.update({'role': 'User'})
                    response_data.append(each_device_response)
    except:
        logger.info("failed in getting data from models-layer. %s", traceback.format_exc())
        raise

    if type(response_data) is type(list()):
        data = {'data': response_data}
    elif type(response_data) is type(dict()):
        response_temp.append(response_data)
        data = {'data': response_temp}
    else:
        data = {'data': response_temp}
        logger.info("the type of the data from DAL is null.%s" % type(response_data))
    for each in data.get('data', []):
        device_id = each.get('deviceId', '')
        result = ConnectorIp.get_data_redis(
            {'deviceId': device_id, 'selectedRegion': request_body.get('selectedRegion')})

        if result.get('empty', 'true') == 'true':
            each['online'] = 'N'
        else:
            each['online'] = 'Y'
    logger.info("read_device_info finished, in account-management. the result is ------>%s" % data)
    return HttpResponse(json.dumps(data))
