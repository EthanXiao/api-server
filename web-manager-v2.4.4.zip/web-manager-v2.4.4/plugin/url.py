# -*- coding:utf-8 -*-
#
# Copyright (c) 2017, TP-Link Co.,Ltd.
# Author:  yuzhijiang <yuzhijiang@tp-link.com.cn>
# Created: 2017-10-10
#
#
from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^getPluginInfo$', views.get_plugin_info, name='get_plugin_info'),
    url(r'^readPluginInfo$', views.read_plugin_info, name='read_plugin_info'),
    url(r'^getPluginExtraInfo$', views.get_plugin_extra_info, name='get_plugin_extra_info'),


    url(r'^getPluginSuitableModelInfo$', views.get_plugin_suitable_model_info, name='get_plugin_suitable_model_info'),
    url(r'^readPluginSuitableModelInfo$', views.read_plugin_suitable_model_info, name='read_plugin_suitable_model_info'),


    url(r'^getPluginReleaseTaskInfo$', views.get_plugin_release_task_info, name='get_plugin_release_task_info'),
    url(r'^readPluginReleaseTaskInfo$', views.read_plugin_release_task_info,
        name='read_plugin_release_task_info'),
    url(r'^getPluginReleaseTaskExtraInfo$', views.get_plugin_release_task_extra_info,
        name='get_plugin_release_task_extra_info'),

    url(r'^getPluginUpgradeCacheInfo$', views.get_plugin_upgrade_cache_info,
        name='get_plugin_upgrade_cache_info'),
    url(r'^readPluginUpgradeCacheInfo$', views.read_plugin_upgrade_cache_info,
        name='read_plugin_upgrade_cache_info'),

]
