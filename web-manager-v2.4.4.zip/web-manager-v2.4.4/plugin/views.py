# -*- coding:utf-8 -*-
#
# Copyright (c) 2017, TP-Link Co.,Ltd.
# Author:  yuzhijiang <yuzhijiang@tp-link.com.cn>
# Created: 2017-10-10
#
#
import datetime
import json
import logging
import traceback

from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader

from common.mysql_dao import MysqlOp
from interceptor.auth_interceptor import check_authority
from plugin.models import PluginUpgradeCacheInfo, PluginReleaseTaskInfo, PluginSuitableModelInfo, PluginInfo
from webmanager.conf import conf
from webmanager.settings import MySQLConfig, Config

logger = logging.getLogger(__name__)
isGlobal = Config['isGlobal']

def get_plugin_info(request):
    str = 'plugin/plugin/plugin-info.html'
    str_login = '/webManager/login'
    try:
        session = request.COOKIES["session_id"]
    except:
        logger.error('ERROR, the user has not logined. %s', traceback.format_exc())
        return HttpResponseRedirect(str_login)

    mysql_op = MysqlOp(MySQLConfig['host'],
                       MySQLConfig['port'],
                       MySQLConfig['user'],
                       MySQLConfig['passwd'],
                       MySQLConfig['db'])
    session_info = mysql_op.check_session(session)

    if session_info is not None:
        response_data = {'priority_fields': conf.all_fields_plugin_filter.get('priority')}
        email = session_info['email']
        response_data.update({'user': email.split("@")[0], 'web_user_role': session_info.get('role_id'),
                              'isGlobal': isGlobal})

        response = render(request, str, response_data)
        response.set_cookie("session_id", session, conf.session_ttl)
        return response
    else:
        logger.warn("get_plugin_info. checking-session failed. the session is ------>%s" % session)
        return HttpResponseRedirect(str_login)


@check_authority
def read_plugin_info(request):
    request_body = request.POST.copy()

    logger.info("read_plugin_info started. the request is ------>%s" % request_body)

    content_type = request.META['CONTENT_TYPE']
    if 'application/json' in content_type:
        request_body.update(json.loads(request.body))

    try:
        response = PluginInfo.get_data_mysql_by_page(request_body)
        response_count = PluginInfo.get_data_mysql_count(request_body)
        response_data = response['responseBody']
        records_filtered = response_count['responseBody']

        records_total_count = PluginInfo.get_data_mysql_count({"pluginId": ""})
        records_total = records_total_count["responseBody"]
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        raise

    if type(response_data) is type(list()):
        data = {'data': response_data, 'recordsFiltered': records_filtered, 'recordsTotal': records_total}
    elif type(response_data) is type(dict()):
        response_temp = [response_data]
        data = {'data': response_temp, 'recordsFiltered': 1, 'recordsTotal': records_total}
    else:
        response_temp = []
        data = {'data': response_temp, 'recordsFiltered': 0, 'recordsTotal': records_total}
        logger.info("the type of the data from DAL is -----> %s" % type(response_data))
    for each in data['data']:
        for key in list(each.keys()):
            if each[key] == ' ' or each[key] == '' or each[key] == 'null' or each[key] is None:
                each[key] = '-'
    return HttpResponse(json.dumps(data))


@check_authority
def get_plugin_extra_info(request):
    str_device_detail = 'plugin/plugin/plugin-extra-info.html'
    request_body = request.POST.copy()

    logger.info("get_plugin_extra_info started. the request is ------>%s" % request_body)

    plugin_id = request_body.get('pluginId', '')
    template = loader.get_template(str_device_detail)

    try:
        response = PluginInfo.get_data_mysql_exactly({"pluginId": plugin_id,
                                                      "pluginVersion": request_body.get('pluginVersion')})  # queried by modelId
        response_plugin_info_list = response['responseBody']

        if response_plugin_info_list is None or response_plugin_info_list == '' \
                or response_plugin_info_list == "null":
            response_plugin_info_filter = 'null'
        else:
            response_plugin_info = response_plugin_info_list
            response_plugin_info_filter = conf.all_fields_plugin_filter.get('other')
            for each in response_plugin_info_filter:
                field_name_en = each['field_name_en']
                each['field_value'] = response_plugin_info.get(field_name_en, '-')  # filter operation
                if each['field_value'] == ' ' or each['field_value'] == '' or each['field_value'] == 'null' or each[
                    'field_value'] is None:
                    each['field_value'] = '-'
                if each.get('value_type', '') == 'date':
                    date_value = each['field_value']
                    if date_value is not None and date_value != '' and date_value != '-':
                        each['field_value'] = datetime.datetime.fromtimestamp(date_value / 1000)
    except:
        logger.error("failed in getting plugin info from models-layer. %s", traceback.format_exc())
        response_plugin_info_filter = 'fail'

    data = {'plugin': response_plugin_info_filter}
    return HttpResponse(json.dumps({'html': template.render(data)}))


def get_plugin_suitable_model_info(request):
    str = 'plugin/plugin-suitable-model/plugin-suitable-model-info.html'
    str_login = '/webManager/login'
    try:
        session = request.COOKIES["session_id"]
    except:
        logger.error('ERROR, the user has not logined. %s', traceback.format_exc())
        return HttpResponseRedirect(str_login)

    mysql_op = MysqlOp(MySQLConfig['host'],
                       MySQLConfig['port'],
                       MySQLConfig['user'],
                       MySQLConfig['passwd'],
                       MySQLConfig['db'])
    session_info = mysql_op.check_session(session)

    if session_info is not None:
        response_data = {'priority_fields': conf.all_fields_plugin_suitable_model_filter.get('priority')}
        email = session_info['email']
        response_data.update({'user': email.split("@")[0], 'web_user_role': session_info.get('role_id'),
                              'isGlobal': isGlobal})

        response = render(request, str, response_data)
        response.set_cookie("session_id", session, conf.session_ttl)
        return response
    else:
        logger.warn("get_plugin_suitable_model_info. checking-session failed. the session is ------>%s" % session)
        return HttpResponseRedirect(str_login)


@check_authority
def read_plugin_suitable_model_info(request):
    request_body = request.POST.copy()

    logger.info("read_plugin_suitable_model_info started. the request is ------>%s" % request_body)

    content_type = request.META['CONTENT_TYPE']
    if 'application/json' in content_type:
        request_body.update(json.loads(request.body))

    try:
        response = PluginSuitableModelInfo.get_data_mysql_by_page(request_body)
        response_count = PluginSuitableModelInfo.get_data_mysql_count(request_body)
        response_data = response['responseBody']
        records_filtered = response_count['responseBody']

        records_total_count = PluginSuitableModelInfo.get_data_mysql_count({"pluginId": ""})
        records_total = records_total_count["responseBody"]
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        raise

    if type(response_data) is type(list()):
        data = {'data': response_data, 'recordsFiltered': records_filtered, 'recordsTotal': records_total}
    elif type(response_data) is type(dict()):
        response_temp = [response_data]
        data = {'data': response_temp, 'recordsFiltered': 1, 'recordsTotal': records_total}
    else:
        response_temp = []
        data = {'data': response_temp, 'recordsFiltered': 0, 'recordsTotal': records_total}
        logger.info("the type of the data from DAL is -----> %s" % type(response_data))
    return HttpResponse(json.dumps(data))


def get_plugin_release_task_info(request):
    str = 'plugin/plugin-release-task/plugin-release-task-info.html'
    str_login = '/webManager/login'
    try:
        session = request.COOKIES["session_id"]
    except:
        logger.error('ERROR, the user has not logined. %s', traceback.format_exc())
        return HttpResponseRedirect(str_login)

    mysql_op = MysqlOp(MySQLConfig['host'],
                       MySQLConfig['port'],
                       MySQLConfig['user'],
                       MySQLConfig['passwd'],
                       MySQLConfig['db'])
    session_info = mysql_op.check_session(session)

    if session_info is not None:
        response_data = {'priority_fields': conf.all_fields_plugin_release_task_filter.get('priority')}
        email = session_info['email']
        response_data.update({'user': email.split("@")[0], 'web_user_role': session_info.get('role_id'),
                              'isGlobal': isGlobal})

        response = render(request, str, response_data)
        response.set_cookie("session_id", session, conf.session_ttl)
        return response
    else:
        logger.warn("get_plugin_release_task_info. checking-session failed. the session is ------>%s" % session)
        return HttpResponseRedirect(str_login)


@check_authority
def read_plugin_release_task_info(request):
    request_body = request.POST

    logger.info("read_plugin_release_task_info started. the request is ------>%s" % request_body)

    try:
        response = PluginReleaseTaskInfo.get_data_mysql_by_page(request_body)
        response_count = PluginReleaseTaskInfo.get_data_mysql_count(request_body)
        response_data = response['responseBody']
        records_filtered = response_count['responseBody']
        records_total_count = PluginReleaseTaskInfo.get_data_mysql_count(
            {"modelId": "", "hardwareType": "", "hardwareVersion": ""})
        records_total = records_total_count["responseBody"]
    except:
        logger.error("reading model info by page failed in getting data in models-layer. %s", traceback.format_exc())
        raise

    if type(response_data) is type(list()):
        data = {'data': response_data, 'recordsFiltered': records_filtered, 'recordsTotal': records_total}
    elif type(response_data) is type(dict()):
        response_temp = [response_data]
        data = {'data': response_temp, 'recordsFiltered': 1, 'recordsTotal': records_total}
    else:
        response_temp = []
        data = {'data': response_temp, 'recordsFiltered': 0, 'recordsTotal': records_total}
        logger.info("the type of the data from DAL is -----> %s" % type(response_data))

    for each in data['data']:
        for key in list(each.keys()):
            if each[key] == ' ' or each[key] == '' or each[key] == 'null' or each[key] is None:
                each[key] = '-'
    return HttpResponse(json.dumps(data))


@check_authority
def get_plugin_release_task_extra_info(request):
    str_device_detail = 'plugin/plugin-release-task/plugin-release-task-extra-info.html'

    request_body = request.POST.copy()

    logger.info("get_plugin_release_task_extra_info started. the request is ------>%s" % request_body)

    task_id = request_body.get('taskId', '')
    template = loader.get_template(str_device_detail)

    try:
        response = PluginReleaseTaskInfo.get_data_mysql_exactly({"taskId": task_id})  # queried by modelId
        response_plugin_release_info = response['responseBody']

        if response_plugin_release_info == '' or response_plugin_release_info == 'null':
            response_plugin_release_info_filter = 'null'
        else:
            response__plugin_release = response_plugin_release_info
            response_plugin_release_info_filter = conf.all_fields_plugin_release_task_filter.get('other')
            for each in response_plugin_release_info_filter:
                field_name_en = each['field_name_en']
                each['field_value'] = response__plugin_release.get(field_name_en, '-')  # filter operation
                if each['field_value'] == ' ' or each['field_value'] == '' or each['field_value'] == 'null' or each[
                    'field_value'] is None:
                    each['field_value'] = '-'
                if each.get('value_type', '') == 'date':
                    date_value = each['field_value']
                    if date_value is not None and date_value != '' and date_value != 'null':
                        each['field_value'] = datetime.datetime.fromtimestamp(date_value / 1000)
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        response_plugin_release_info_filter = 'fail'

    data = {'plugin_release_task': response_plugin_release_info_filter}
    return HttpResponse(json.dumps({'html': template.render(data)}))


def get_plugin_upgrade_cache_info(request):
    str = 'plugin/plugin-upgrade-cache/plugin-upgrade-cache-info.html'
    str_login = '/webManager/login'
    try:
        session = request.COOKIES["session_id"]
    except:
        logger.error('ERROR, the user has not logined. %s', traceback.format_exc())
        return HttpResponseRedirect(str_login)

    mysql_op = MysqlOp(MySQLConfig['host'],
                       MySQLConfig['port'],
                       MySQLConfig['user'],
                       MySQLConfig['passwd'],
                       MySQLConfig['db'])
    session_info = mysql_op.check_session(session)

    if session_info is not None:
        response_data = {'priority_fields': conf.all_fields_plugin_upgrade_cache_filter.get('priority')}
        email = session_info['email']
        response_data.update({'user': email.split("@")[0], 'web_user_role': session_info.get('role_id'),
                              'isGlobal': isGlobal})

        response = render(request, str, response_data)
        response.set_cookie("session_id", session, conf.session_ttl)
        return response
    else:
        logger.warn("get_plugin_upgrade_cache_export_info. checking-session failed. the session is ------>%s" % session)
        return HttpResponseRedirect(str_login)


@check_authority
def read_plugin_upgrade_cache_info(request):
    request_body = request.POST.copy()

    logger.info("read_plugin_upgrade_cache_export_info started. the request is ------>%s" % request_body)

    content_type = request.META['CONTENT_TYPE']
    if 'application/json' in content_type:
        request_body.update(json.loads(request.body))

    try:
        response = PluginUpgradeCacheInfo.get_data_mysql_by_page(request_body)
        response_count = PluginUpgradeCacheInfo.get_data_mysql_count(request_body)
        response_data = response['responseBody']
        records_filtered = response_count['responseBody']

        records_total_count = PluginUpgradeCacheInfo.get_data_mysql_count({"pluginId": ""})
        records_total = records_total_count["responseBody"]
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        raise

    if type(response_data) is type(list()):
        data = {'data': response_data, 'recordsFiltered': records_filtered, 'recordsTotal': records_total}
    elif type(response_data) is type(dict()):
        response_temp = [response_data]
        data = {'data': response_temp, 'recordsFiltered': 1, 'recordsTotal': records_total}
    else:
        response_temp = []
        data = {'data': response_temp, 'recordsFiltered': 0, 'recordsTotal': records_total}
        logger.info("the type of the data from DAL is -----> %s" % type(response_data))
    return HttpResponse(json.dumps(data))
