# -*- coding:utf-8 -*-
#
# Copyright (c) 2017, TP-Link Co.,Ltd.
# Author:  yuzhijiang <yuzhijiang@tp-link.com.cn>
# Created: 2017-10-10
#
#
from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^getDeviceInfo$', views.get_device_info, name='get_device_info'),
    url(r'^readDeviceInfo$', views.read_device_info, name='read_device_info'),
    url(r'^getDeviceExtraInfo$', views.get_device_extra_info, name='get_device_extra_info'),
    url(r'^readTargetEditingDeviceInfo$', views.read_target_editing_device_info,
        name='read_target_editing_device_info'),
    url(r'^modifyDeviceInfo$', views.modify_device_info, name='modify_device_info'),
    url(r'^delDeviceInfo$', views.del_device_info, name='del_device_info')
]
