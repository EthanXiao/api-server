# -*- coding:utf-8 -*-
#
# Copyright (c) 2017, TP-Link Co.,Ltd.
# Author:  yuzhijiang <yuzhijiang@tp-link.com.cn>
# Created: 2017-10-10
#
#
import copy
import datetime
import json
import logging
import traceback

from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader

from common.mysql_dao import MysqlOp
from factorydata.models import DeviceFactoryInfo, ModelInfo
from interceptor.auth_interceptor import check_authority, check_super_admin_authority
from webmanager.conf import conf
from webmanager.settings import MySQLConfig, Config
from .models import Device, DeviceStaticInfo, DeviceOnlineStatus, DeviceBindStatistic, ConnectorIp

logger = logging.getLogger(__name__)
isGlobal = Config['isGlobal']


def get_device_info(request):
    str = 'device/device-link/device-info.html'
    str_login = '/webManager/login'
    try:
        session = request.COOKIES["session_id"]
    except:
        logger.error('ERROR, the user has not logined. %s', traceback.format_exc())
        return HttpResponseRedirect(str_login)

    mysql_op = MysqlOp(MySQLConfig['host'],
                       MySQLConfig['port'],
                       MySQLConfig['user'],
                       MySQLConfig['passwd'],
                       MySQLConfig['db'])
    session_info = mysql_op.check_session(session)

    if session_info is not None:
        response_data = {'priority_fields_device': copy.deepcopy(conf.all_fields_device_filter.get('priority'))}
        if {
            'field_name_cn': '该账户角色',
            'field_name_en': 'role',
            'field_value': {
                'data': 'role',
                'className': 'role',
                'width': '6%'
            },
        } in response_data['priority_fields_device']:
            response_data['priority_fields_device'].remove({
                'field_name_cn': '该账户角色',
                'field_name_en': 'role',
                'field_value': {
                    'data': 'role',
                    'className': 'role',
                    'width': '6%'
                },
            }, )
        email = session_info['email']
        response_data.update({'user': email.split("@")[0], 'web_user_role': session_info.get('role_id'),
                              'region_list': conf.regionList, 'default_region': conf.defaultRegion, 'isGlobal': isGlobal})

        response = render(request, str, response_data)
        response.set_cookie("session_id", session, conf.session_ttl)
        return response
    else:
        logger.warn("get_device_info. checking-session failed. the session is ------>%s" % session)
        return HttpResponseRedirect(str_login)


@check_authority
def read_device_info(request):
    request_body = request.POST

    logger.info("read_device_info started, in device-management. the request is ------>%s" % request_body)

    response_temp = []
    mac = request_body['mac']

    if mac == 'null' or mac is None or mac == '':
        try:
            response = Device.get_data_cassandra(request_body)
            response_data = response['responseBody']
        except:
            logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
            raise

        if type(response_data) is type(list()):
            data = {'data': response_data}
        elif type(response_data) is type(dict()):
            response_temp.append(response_data)
            data = {'data': response_temp}
        else:
            data = {'data': response_temp}
            logger.info("the type of the data from DAL is null.%s" % type(response_data))

        for each in data.get('data', []):
            device_id = each.get('deviceId', '')
            result = ConnectorIp.get_data_redis({'deviceId': device_id,
                                                 'selectedRegion': request_body.get('selectedRegion')})
            logger.info("getting connectorip. the response is %s", result)
            if result.get('empty', 'true') == 'true':
                each['online'] = 'N'
            else:
                each['online'] = 'Y'

        return HttpResponse(json.dumps(data))

    response_factory_data = DeviceFactoryInfo.get_data_mysql_by_mac(request_body)
    response_factory_data_list = response_factory_data['responseBody']
    if response_factory_data_list is None or response_factory_data_list == '' or response_factory_data_list == 'null' \
            or response_factory_data_list == []:
        data = {'data': response_temp}
        return HttpResponse(json.dumps(data))

    device_id_request = request_body['deviceId']
    account_id_request = request_body['accountId']

    if device_id_request is None or device_id_request == '' or device_id_request == 'null':
        device_id_request_is_none = True
    else:
        device_id_request_is_none = False

    response_device_info_list = []

    for each in response_factory_data_list:
        device_id = each['deviceId']

        if device_id is None or device_id == '' or device_id == 'null':
            device_id_is_none = True
        else:
            device_id_is_none = False

        if (device_id_request_is_none or device_id == device_id_request) and not device_id_is_none:

            try:
                response_each = Device.get_data_cassandra({"deviceId": device_id, "accountId": account_id_request,
                                                           'selectedRegion': request_body.get('selectedRegion')})
                response_device_info_each = response_each['responseBody']
            except:
                logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
                raise

            if type(response_device_info_each) is type(list()):
                response_device_info_list = response_device_info_list + response_device_info_each
            elif type(response_device_info_each) is type(dict()):
                response_device_info_list.append(response_device_info_each)
            else:
                logger.info("the type of the data from DAL (read device info by mac->deviceId) is null.%s"
                            % type(response_device_info_each))

    for each in response_device_info_list:
        device_id = each.get('deviceId', '')
        result = ConnectorIp.get_data_redis({'deviceId': device_id,
                                             'selectedRegion': request_body.get('selectedRegion')})
        if result.get('empty', 'true') == 'true':
            each['online'] = 'N'
        else:
            each['online'] = 'Y'

    data = {'data': response_device_info_list}
    return HttpResponse(json.dumps(data))


@check_authority
def get_device_extra_info(request):
    str_device_detail = 'device/device-link/device-extra-info.html'
    referer_url = request.META.get('HTTP_REFERER')
    response_device_filter = copy.deepcopy(conf.all_fields_device_filter.get('device'))
    if {
        'field_name_cn': '型号ID',
        'field_name_en': 'modelId',
        'field_value': ''
    } in response_device_filter:
        response_device_filter.remove({
            'field_name_cn': '型号ID',
            'field_name_en': 'modelId',
            'field_value': ''
        }, )

    logger.info("get_device_extra_info started. the request is ------>%s" % request.POST)
    if '/account/getAccountInfo' in referer_url:
        str_device_detail = 'account/device-detail-info.html'
        response_device_filter = copy.deepcopy(conf.all_fields_device_filter.get('priority')) \
                                 + response_device_filter
        if {
            'field_name_cn': '该账户角色',
            'field_name_en': 'role',
            'field_value': {
                'data': 'role',
                'className': 'role',
                'width': '6%'
            },
        } in response_device_filter:
            response_device_filter.remove({
                'field_name_cn': '该账户角色',
                'field_name_en': 'role',
                'field_value': {
                    'data': 'role',
                    'className': 'role',
                    'width': '6%'
                },
            }, )
        logger.info("the get_device_extra_info request is from account-management.")

    request_body = request.POST
    device_id = request_body.get('deviceId', '')
    template = loader.get_template(str_device_detail)

    try:
        response_1 = Device.get_data_cassandra(request_body)  # queried by deviceId
        response_device = response_1['responseBody'][0]

        if response_device is None or response_device == 'null' or response_device == '':
            response_device_filter = 'null'
        else:
            device_online_reality = ConnectorIp.get_data_redis({'deviceId': device_id,
                                                                'selectedRegion': request_body.get('selectedRegion')})
            if device_online_reality.get('empty', 'true') == 'true':
                response_device['online'] = 'N'
            else:
                response_device['online'] = 'Y'

            for each in response_device_filter:
                field_name_en = each['field_name_en']
                each['field_value'] = response_device.get(field_name_en, 'null')  # filter operation
                if each.get('value_type', '') == 'date':
                    date_value = each['field_value']
                    if date_value is not None and date_value != '' and date_value != 'null':
                        each['field_value'] = datetime.datetime.fromtimestamp(date_value / 1000)
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        response_device_filter = 'fail'

    try:
        response_factorydata = DeviceFactoryInfo.get_data_mysql_exactly({'deviceId': device_id})
        if response_factorydata == "null" or response_factorydata == "" or response_factorydata is None:
            response_factorydata = {}

        request_model = {"modelId": response_factorydata.get('modelId')}
        response_2 = ModelInfo.get_data_mysql_list(request_model)
        response_device_model_list = response_2['responseBody']
        if not response_device_model_list or response_device_model_list == 'null' or response_device_model_list == '':
            response_device_model = {}
        else:
            response_device_model = response_device_model_list[0]

        response_device_model.update(response_factorydata)

        if response_device_model is None or response_device_model == 'null' or response_device_model == {}:
            response_model_info_filter = 'null'
        else:
            response_model_info_filter = copy.deepcopy(conf.all_fields_factorydata_filter.get('priority'))
            if {
                'field_name_cn': '型号ID',
                'field_name_en': 'modelId',
                'field_value': {
                    'data': 'modelId',
                    'className': 'modelId',
                    'width': '7%'
                },
            } in response_model_info_filter:
                response_model_info_filter.remove({
                    'field_name_cn': '型号ID',
                    'field_name_en': 'modelId',
                    'field_value': {
                        'data': 'modelId',
                        'className': 'modelId',
                        'width': '7%'
                    },
                }, )
            response_model_info_filter = response_model_info_filter + copy.deepcopy(
                conf.all_fields_factorydata_filter.get('device_model_info'))
            for each in response_model_info_filter:
                field_name_en = each['field_name_en']
                each['field_value'] = response_device_model.get(field_name_en, 'null')  # filter operation
                if each.get('value_type', '') == 'date':
                    date_value = each['field_value']
                    if date_value is not None and date_value != '' and date_value != 'null':
                        each['field_value'] = datetime.datetime.fromtimestamp(date_value / 1000)
    except:
        logger.error("failed in getting factorydata from models-layer. %s", traceback.format_exc())
        response_model_info_filter = 'fail'

    response_statistic_info = {}
    try:
        response_3 = DeviceStaticInfo.get_data_cassandra(request_body)
        response_device_3 = response_3['responseBody']
        if response_device_3 == "null" or response_device_3 == "" or response_device_3 is None:
            response_device_3 = {}
        response_statistic_info.update(response_device_3)
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        data = {'device': response_device_filter, 'device_model': response_model_info_filter,
                'device_statistic_info': 'fail'}
        return HttpResponse(json.dumps({'html': template.render(data)}))

    try:
        response_4 = DeviceOnlineStatus.get_data_cassandra(request_body)
        response_device_4 = response_4['responseBody']
        if response_device_4 == "null" or response_device_4 == "" or response_device_4 is None:
            response_device_4 = {}
        else:
            device_online_reality = ConnectorIp.get_data_redis({'deviceId': device_id,
                                                                'selectedRegion': request_body.get('selectedRegion')})
            if device_online_reality.get('empty', 'true') == 'true':
                response_device_4['online'] = 'N'
            else:
                response_device_4['online'] = 'Y'
        response_statistic_info.update(response_device_4)
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        data = {'device': response_device_filter, 'device_model': response_model_info_filter,
                'device_statistic_info': 'fail'}
        return HttpResponse(json.dumps({'html': template.render(data)}))

    try:
        response_5 = DeviceBindStatistic.get_data_cassandra(request_body)
        response_device_5 = response_5['responseBody']
        if response_device_5 == "null" or response_device_5 == "" or response_device_5 is None:
            response_device_5 = {}
        response_statistic_info.update(response_device_5)
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        data = {'device': response_device_filter, 'device_model': response_model_info_filter,
                'device_statistic_info': 'fail'}
        return HttpResponse(json.dumps({'html': template.render(data)}))

    if response_statistic_info == {}:
        data = {'device': response_device_filter, 'device_model': response_model_info_filter,
                'device_statistic_info': 'null'}
        return HttpResponse(json.dumps({'html': template.render(data)}))

    response_statistic_info_filter = conf.all_fields_device_filter.get('device_statistic_info')
    for each in response_statistic_info_filter:
        field_name_en = each['field_name_en']
        each['field_value'] = response_statistic_info.get(field_name_en, 'null')  # filter operation
        if each.get('value_type', '') == 'date':
            date_value = each['field_value']
            if date_value is not None and date_value != '' and date_value != 'null':
                each['field_value'] = datetime.datetime.fromtimestamp(date_value / 1000)

    data = {'device': response_device_filter, 'device_model': response_model_info_filter,
            'device_statistic_info': response_statistic_info_filter}
    return HttpResponse(json.dumps({'html': template.render(data)}))


@check_authority
def read_target_editing_device_info(request):
    request_body = request.POST.copy()

    logger.info("read_target_editing_device_info started. the request is ------>%s" % request.POST)

    str_account_editing = 'device/device-link/add-modify-modal-content.html'
    template = loader.get_template(str_account_editing)

    str_login = '/webManager/login'
    try:
        session = request.COOKIES["session_id"]
    except:
        return HttpResponseRedirect(str_login)

    mysql_op = MysqlOp(MySQLConfig['host'],
                       MySQLConfig['port'],
                       MySQLConfig['user'],
                       MySQLConfig['passwd'],
                       MySQLConfig['db'])
    session_info = mysql_op.check_session(session)

    if session_info is None:
        logger.warn("read_target_device_info. checking-session failed. the session is ------>%s" % session)
        return HttpResponseRedirect(str_login)

    device_id = request_body['deviceId']
    try:
        response = Device.get_data_cassandra({'deviceId': device_id,
                                              'selectedRegion': request_body.get('selectedRegion')})
        response_device = response['responseBody']
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        response_device = 'fail'
        data = {'device': response_device}
        return HttpResponse(json.dumps({'html': template.render(data)}))
    device_online_reality = ConnectorIp.get_data_redis({'deviceId': device_id,
                                                        'selectedRegion': request_body.get('selectedRegion')})
    if device_online_reality.get('empty', 'true') == 'true':
        response_device[0]['online'] = 'N'
    else:
        response_device[0]['online'] = 'Y'

    target_device_info_filter = copy.deepcopy(conf.all_fields_device_filter.get('priority', []))

    target_device_info_filter = target_device_info_filter + list(conf.all_fields_device_filter.get('device', []))

    if {
        "field_name_cn": "设备ID",
        'field_name_en': 'deviceId',
        "field_value": ''
    } in target_device_info_filter:
        target_device_info_filter.remove({
            "field_name_cn": "设备ID",
            'field_name_en': 'deviceId',
            "field_value": ''
        }, )

    if {
        'field_name_cn': '该账户角色',
        'field_name_en': 'role',
        'field_value': {
            'data': 'role',
            'className': 'role',
            'width': '6%'
        },
    } in target_device_info_filter:
        target_device_info_filter.remove({
            'field_name_cn': '该账户角色',
            'field_name_en': 'role',
            'field_value': {
                'data': 'role',
                'className': 'role',
                'width': '6%'
            },
        }, )

    if not isGlobal:
        target_device_info_filter.remove({
            'field_name_cn': 'oemId',
            'field_name_en': 'oemId',
            'field_value': '',
        },)
    for each in target_device_info_filter:
        field_name_en = each['field_name_en']
        each['field_value'] = response_device[0].get(field_name_en, '')  # filter operation
        if each.get('value_type', '') == 'date':
            date_value = each['field_value']
            if date_value is not None and date_value != '' and date_value != 'null':
                each['field_value'] = datetime.datetime.fromtimestamp(date_value / 1000)

    data = {'device': target_device_info_filter, 'web_user_role': session_info.get("role_id")}
    return HttpResponse(json.dumps({'html': template.render(data)}))


@check_authority
def modify_device_info(request):
    request_body = request.POST.copy()

    logger.info("modify_device_info started. the request is ------>%s" % request.POST)

    response_data = ""

    try:
        response_device = Device.update_data_cassandra(request_body)
        response_data = response_device['success']
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())

    data = {'result': response_data}
    return HttpResponse(json.dumps(data))


@check_super_admin_authority
def del_device_info(request):
    request_body = request.POST

    logger.info("del_device_info started. the request is ------>%s" % request_body)

    try:
        response = Device.del_data_cassandra(request_body)
        response_data = response['success']
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        response_data = "false"

    data = {'result': response_data}
    return HttpResponse(json.dumps(data))
