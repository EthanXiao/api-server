# -*- coding:utf-8 -*-
#
# Copyright (c) 2017, TP-Link Co.,Ltd.
# Author:  yuzhijiang <yuzhijiang@tp-link.com.cn>
# Created: 2017-9-20
#
#
import logging
import traceback

from common.common_base_model import CommonBase
from common.common_exception import DalResponseError, DalServerError
from common.http_client import DALClient
from webmanager.conf import conf
from webmanager.settings import Config

dalVersionPath = Config['dalVersionPath']
cacheDalPath = Config['cacheDalPath']

logger = logging.getLogger(__name__)
isGlobal = Config['isGlobal']


class Device(CommonBase):
    getURL = 'getDeviceInfo?'
    getListURL = 'getDeviceInfoList?'
    updateURL = 'updateDeviceInfo?'
    delURL = 'delDeviceInfo?'
    addURL = 'setDeviceInfo?'

    deviceId = ''
    modelId = ''
    mac = ''
    fwId = ''
    accountId = ''
    deviceName = ''
    region = ''
    fwVer = ''
    hwId = ''
    hwVer = ''
    oemId = ''
    alias = ''
    categoryName = ''


    def __init__(self, **kwargs):
        for k, v in kwargs.iteritems():
            setattr(self, k, v)

    @classmethod
    def get_data_cassandra_exactly(cls, request_body):
        try:
            dal_client = DALClient(host=conf.dalHostList.get(request_body.get('selectedRegion'), None))
            params_tempt = cls.convert_dict_to_obj(request_body)
            params = dal_client.group_params(params_tempt.convert_to_dict())
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getURL + query_id
            response = dal_client.send_get_request(url, params)
        except (DalResponseError, DalServerError):
            raise
            # raise
        finally:
            dal_client.close()
        return response

    @classmethod
    def get_data_cassandra(cls, request_body):
        try:
            dal_client = DALClient(host=conf.dalHostList.get(request_body.get('selectedRegion'), None))

            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getListURL + query_id
            response = dal_client.send_post_request(url, params)
        except (DalResponseError, DalServerError):
            raise
        finally:
            dal_client.close()
        return response

    @classmethod
    def update_data_cassandra(cls, request_body):
        try:
            dal_client = DALClient(host=conf.dalHostList.get(request_body.get('selectedRegion'), None))

            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.updateURL + query_id
            response = dal_client.send_post_request(url, params)

        except (DalResponseError, DalServerError):
            logger.error('update account info failed.')
            raise
        finally:
            dal_client.close()
        return response

    @classmethod
    def del_data_cassandra(cls, request_body):
        try:
            dal_client = DALClient(host=conf.dalHostList.get(request_body.get('selectedRegion'), None))

            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()

            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.delURL + query_id
            response = dal_client.send_post_request(url, params)

        except (DalResponseError, DalServerError):
            raise
        finally:
            dal_client.close()
        return response


class DeviceStaticInfo(CommonBase):
    getURL = 'getDeviceStaticInfoStats?'

    deviceId = ''

    def __init__(self, **kwargs):
        for k, v in kwargs.iteritems():
            setattr(self, k, v)

    @classmethod
    def get_data_cassandra(cls, request_body):
        try:
            dal_client = DALClient(host=conf.dalHostList.get(request_body.get('selectedRegion'), None))

            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getURL + query_id
            response = dal_client.send_post_request(url, params)
        except (DalResponseError, DalServerError):
            raise

        finally:
            dal_client.close()
        return response


class DeviceOnlineStatus(CommonBase):
    getURL = 'getDeviceOnlineStatusInfo?'

    deviceId = ''

    def __init__(self, **kwargs):
        for k, v in kwargs.iteritems():
            setattr(self, k, v)

    @classmethod
    def get_data_cassandra(cls, request_body):
        try:
            dal_client = DALClient(host=conf.dalHostList.get(request_body.get('selectedRegion'), None))

            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getURL + query_id
            response = dal_client.send_post_request(url, params)
        except (DalResponseError, DalServerError):
            raise
        finally:
            dal_client.close()

        return response


class DeviceBindStatistic(CommonBase):
    getURL = 'getDeviceBindStatisticInfo?'

    deviceId = ''

    def __init__(self, **kwargs):
        for k, v in kwargs.iteritems():
            setattr(self, k, v)

    @classmethod
    def get_data_cassandra(cls, request_body):
        try:
            dal_client = DALClient(host=conf.dalHostList.get(request_body.get('selectedRegion'), None))

            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getURL + query_id
            response = dal_client.send_post_request(url, params)
        except (DalResponseError, DalServerError):
            raise
        finally:
            dal_client.close()

        return response


class ConnectorIp(CommonBase):
    getURL = 'getConnectorIp?'
    connectorIpKey = ''
    deviceId = ''

    def __init__(self, **kwargs):
        for k, v in kwargs.iteritems():
            setattr(self, k, v)

    @classmethod
    def get_data_redis(cls, request_body):

        logger.info("get device online-status started. the request is: %s", request_body)
        try:

            dal_client = DALClient(host=conf.dalHostList.get(request_body.get('selectedRegion'), None))
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getURL + query_id

            params_tempt = cls.convert_dict_to_obj(request_body)
            params_dict = params_tempt.convert_to_dict()
            params = dal_client.group_params(params_dict)

            response = dal_client.send_get_request(url, params)

        except (DalResponseError, DalServerError):
            logger.error("error in getting device online-status from redis. %s", traceback.format_exc())
            raise

        finally:
            dal_client.close()
        logger.info("get device online-status finished. the response is: %s", response)
        return response


