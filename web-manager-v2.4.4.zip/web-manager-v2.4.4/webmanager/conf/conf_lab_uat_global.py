# this file is the config property of the web-manager
# -*- coding:utf-8 -*-

# the web service server on mainland or export


isGlobal = True

# regionList = ['us-east-1', 'ap-southeast-1','eu-west-1']
regionList = ['us-east-1']
# regionList = ['cn-north-1']
defaultRegion = 'us-east-1'
# defaultRegion = 'cn-north-1'
# dalHostList = {'us-east-1': '172.31.1.153:19193', 'ap-southeast-1': '172.31.1.153:19193'}
dalHostList = {'us-east-1': '222.9.9.83:19193'}
# 'us-east-1', 'ap-southeast-1', 'eu-west-1', 'cn-north-1':
# are the four region names are embedded in the codes of the system.
# Hence we mustn't use other names to substitute these names.
dalDefaultHost = dalHostList.get(defaultRegion, None)
dalVersionPath = '/access/v1/'
cacheDalPath = '/access/v1/'

reportExcelPath = '/schedule/'

opDataReceiverHostList = ['222.9.9.83:10880']
opDataReceiverHostSelector = 0
opDataReceiverHost = opDataReceiverHostList[opDataReceiverHostSelector]
opDataReceiverPath = '/OAManager/'
# codeLocationPath='/home/cloud/cloud/cloud-webManager'
codeLocation_path = ''
# configuration for mysql (where session saved.)
MysqlHost = '222.9.9.84'
MysqlPost = 3306
MysqlUser = 'cloud'
MysqlPassW = 'tplinkcloud'
MysqlDbSession = 'cloud_webmanager'

MysqlTableSession = 'webmanager_session'
MysqlWebmanagerUser = 'webmanager_user'
# superadmin
superadmin_authority = 'SUPERADMIN'
admin_authority = 'READONLY'

# OA unified account
email = 'operation_from_webmanager@tp-link.com.cn'
password = '356a192b7913b04c54574d18c28d46e6395428ab'
# session_setting
session_ttl = 3600 * 24
email_cookie = 3600 * 24 * 14
upload_device_factory_info_max_size = 50
# log file path
log_path = codeLocation_path + 'logs/cloud-webManager.log'

console_log_level = 'ERROR'
file_log_level = 'INFO'
common_log_level = 'INFO'
app_log_level = 'INFO'
interceptor_log_level = 'INFO'
account_log_level = 'INFO'
device_log_level = 'INFO'
user_log_level = 'INFO'
firmware_log_level = 'INFO'
plugin_log_level = 'INFO'
signature_log_level = 'INFO'
factorydata_log_level = 'INFO'

# The follows list all the fields that need to show in the front.
# contain not only prior fields but also other valued fields.
# priority is firstly shown in the datatable.
all_fields_account_filter = {
    'priority': [
        {
            "field_name_cn": "账号ID",
            'field_name_en': 'accountId',
            "field_value": {
                'data': 'accountId',
                'className': 'accountId',
                'width': '10%'
            },
        },
        {
            'field_name_cn': '用户名',
            'field_name_en': 'username',
            'field_value': {
                'data': 'username',
                'className': 'username',
                'width': '12%'
            },
        },
        {
            'field_name_cn': '邮箱',
            'field_name_en': 'email',
            'field_value': {
                'data': 'email',
                'className': 'email',
                'width': '14%'
            },
        },
        {
            'field_name_cn': '账号状态',
            'field_name_en': 'status',
            'field_value': {
                'data': 'status',
                'className': 'status',
                'width': '10%'
            },
        },
        {
            'field_name_cn': '注册时间',
            'field_name_en': 'registerDate',
            'field_value': {
                'data': 'registerDate',
                'className': 'registerDate',
                'width': '12%'
            },
            'value_type': 'date'
        },
        {
            'field_name_cn': '锁定截至时间',
            'field_name_en': 'lockEndDate',
            'field_value': {
                'data': 'lockEndDate',
                'className': 'lockEndDate',
                'width': '12%'
            },
            'value_type': 'date',
        },
    ],
    'other': [
        {
            'field_name_cn': '昵称',
            'field_name_en': 'nickName',
            'field_value': '',
        },
        {
            'field_name_cn': '性别',
            'field_name_en': 'sex',
            'field_value': '',
        },
        {
            'field_name_cn': '生日',
            'field_name_en': 'birthday',
            'field_value': '',
            'value_type': 'date',
        },
        {
            'field_name_cn': '头像文件ID',
            'field_name_en': 'avatarFileId',
            'field_value': '',
        },
        {
            'field_name_cn': '头像文件URL',
            'field_name_en': 'avatarUrl',
            'field_value': '',
            'value_type': 'url'
        },
    ],
    'register_info': [
        {
            'field_name_cn': '注册IP',
            'field_name_en': 'registerIp',
            'field_value': '',
        },
        {
            'field_name_cn': '注册国家',
            'field_name_en': 'registerCountry',
            'field_value': '',
        },
        {
            'field_name_cn': '注册地区',
            'field_name_en': 'registerRegion',
            'field_value': '',
        },
        {
            'field_name_cn': '注册APP方式',
            'field_name_en': 'registerAppType',
            'field_value': '',
        },
        {
            'field_name_cn': '注册APP平台',
            'field_name_en': 'registerAppPlatform',
            'field_value': '',
        },
        {
            'field_name_cn': '注册APP版本',
            'field_name_en': 'registerAppVersion',
            'field_value': '',
        },
        {
            'field_name_cn': '注册设备ID',
            'field_name_en': 'registerDeviceId',
            'field_value': '',
        },
    ]
}
all_fields_account_filter_mainland = {
    'priority': [
        {
            "field_name_cn": "账号ID",
            'field_name_en': 'accountId',
            "field_value": {
                'data': 'accountId',
                'className': 'accountId',
                'width': '10%'
            },
        },
        {
            'field_name_cn': '手机号',
            'field_name_en': 'mobile',
            'field_value': {
                'data': 'mobile',
                'className': 'mobile',
                'width': '12%'
            },
        },
        {
            'field_name_cn': '邮箱',
            'field_name_en': 'email',
            'field_value': {
                'data': 'email',
                'className': 'email',
                'width': '14%'
            },
        },
        {
            'field_name_cn': '账号状态',
            'field_name_en': 'status',
            'field_value': {
                'data': 'status',
                'className': 'status',
                'width': '10%'
            },
        },
        {
            'field_name_cn': '注册时间',
            'field_name_en': 'registerDate',
            'field_value': {
                'data': 'registerDate',
                'className': 'registerDate',
                'width': '12%'
            },
            'value_type': 'date'
        },
        {
            'field_name_cn': '锁定截至时间',
            'field_name_en': 'lockEndDate',
            'field_value': {
                'data': 'lockEndDate',
                'className': 'lockEndDate',
                'width': '12%'
            },
            'value_type': 'date',
        },
    ],
    'other': [
    ],
    'register_info': [
        {
            'field_name_cn': '注册IP',
            'field_name_en': 'registerIp',
            'field_value': '',
        },
        {
            'field_name_cn': '注册国家',
            'field_name_en': 'registerCountry',
            'field_value': '',
        },
        {
            'field_name_cn': '注册地区',
            'field_name_en': 'registerRegion',
            'field_value': '',
        },
        {
            'field_name_cn': '注册APP方式',
            'field_name_en': 'registerAppType',
            'field_value': '',
        },
        {
            'field_name_cn': '注册APP平台',
            'field_name_en': 'registerAppPlatform',
            'field_value': '',
        },
        {
            'field_name_cn': '注册APP版本',
            'field_name_en': 'registerAppVersion',
            'field_value': '',
        },
        {
            'field_name_cn': '注册设备ID',
            'field_name_en': 'registerDeviceId',
            'field_value': '',
        },
    ]
}

all_fields_device_filter = {
    'priority': [
        {
            "field_name_cn": "设备ID",
            'field_name_en': 'deviceId',
            "field_value": {
                'data': 'deviceId',
                'className': 'deviceId',
                'width': '19%'
            },
        },
        {
            'field_name_cn': '地区',
            'field_name_en': 'region',
            'field_value': {
                'data': 'region',
                'className': 'region',
                'width': '5%'
            },
        },
        {
            'field_name_cn': '在线状态',
            'field_name_en': 'online',
            'field_value': {
                'data': 'online',
                'className': 'online',
                'width': '6%'
            },
        },
        {
            'field_name_cn': '固件版本',
            'field_name_en': 'fwVer',
            'field_value': {
                'data': 'fwVer',
                'className': 'fwVer',
                'width': '11%'
            },
        },
        {
            'field_name_cn': '硬件ID',
            'field_name_en': 'hwId',
            'field_value': {
                'data': 'hwId',
                'className': 'hwId',
                'width': '14%'
            },
        },

        {
            'field_name_cn': 'MAC地址',
            'field_name_en': 'mac',
            'field_value': {
                'data': 'mac',
                'className': 'mac',
                'width': '7%'
            },
        },
        {
            'field_name_cn': 'Owner账号ID',
            'field_name_en': 'accountId',
            'field_value': {
                'data': 'accountId',
                'className': 'accountId',
                'width': '6%'
            },
        },

        {
            'field_name_cn': '该账户角色',
            'field_name_en': 'role',
            'field_value': {
                'data': 'role',
                'className': 'role',
                'width': '6%'
            },
        },  # has deleted operation
    ],
    'device': [
        {
            'field_name_cn': '设备ID',
            'field_name_en': 'deviceId',
            'field_value': '',
        },
        {
            'field_name_cn': '设备名',
            'field_name_en': 'deviceName',
            'field_value': '',
        },
        {
            'field_name_cn': '别称',
            'field_name_en': 'alias',
            'field_value': '',
        },
        {
            'field_name_cn': '类别',
            'field_name_en': 'categoryName',
            'field_value': '',
        },
        {
            'field_name_cn': '型号ID',
            'field_name_en': 'modelId',
            'field_value': '',
        },
        {
            'field_name_cn': '固件ID',
            'field_name_en': 'fwId',
            'field_value': '',
        },
        {
            'field_name_cn': 'oemId',
            'field_name_en': 'oemId',
            'field_value': '',
        },
        {
            'field_name_cn': '硬件类型',
            'field_name_en': 'hwType',
            'field_value': '',
        },
        {
            'field_name_cn': '硬件版本',
            'field_name_en': 'hwVer',
            'field_value': '',
        },
    ],
    'device_statistic_info': [
        {
            'field_name_cn': '首次上线时间',
            'field_name_en': 'firstConnectTime',
            'field_value': '',
            'value_type': 'date'
        },
        {
            'field_name_cn': '首次上线IP',
            'field_name_en': 'firstConnectIp',
            'field_value': ''
        },
        {
            'field_name_cn': '首次上线地区',
            'field_name_en': 'firstConnectRegion',
            'field_value': ''
        },
        {
            'field_name_cn': '最近登录日期',
            'field_name_en': 'lastLoginDate',
            'field_value': '',
            'value_type': 'date',
        },
        {
            'field_name_cn': '最近下线时间',
            'field_name_en': 'lastDisconnectTime',
            'field_value': '',
            'value_type': 'date',
        },
        {
            'field_name_cn': '当前IP地址',
            'field_name_en': 'ipAddress',
            'field_value': ''
        },
        {
            'field_name_cn': '在线状态',
            'field_name_en': 'online',
            'field_value': ''
        },
        {
            'field_name_cn': '首次绑定时间',
            'field_name_en': 'firstBindTime',
            'field_value': '',
            'value_type': 'date',
        },
        {
            'field_name_cn': '首次解绑时间',
            'field_name_en': 'firstUnbindTime',
            'field_value': '',
            'value_type': 'date',
        },
        {
            'field_name_cn': '首次绑定账号ID',
            'field_name_en': 'firstBindAccountId',
            'field_value': ''
        },
        {
            'field_name_cn': '最近绑定时间',
            'field_name_en': 'lastBindTime',
            'field_value': '',
            'value_type': 'date',
        },
        {
            'field_name_cn': '最近解绑时间',
            'field_name_en': 'lastUnbindTime',
            'field_value': '',
            'value_type': 'date',
        },
    ],
    'device_model_info': [
        {
            'field_name_cn': '硬件类型',
            'field_name_en': 'hardwareType',
            'field_value': ''
        },
        {
            'field_name_cn': '硬件版本',
            'field_name_en': 'hardwareVersion',
            'field_value': ''
        },
        {
            'field_name_cn': '硬件ID',
            'field_name_en': 'hardwareId',
            'field_value': ''
        },
        {
            'field_name_cn': '类别',
            'field_name_en': 'categoryName',
            'field_value': ''
        }
    ]
}
all_fields_factorydata_filter = {
    'priority': [
        {
            "field_name_cn": "设备ID",
            'field_name_en': 'deviceId',
            "field_value": {
                'data': 'deviceId',
                'className': 'deviceId',
                'width': '18%'
            },
        },
        {
            'field_name_cn': 'MAC地址',
            'field_name_en': 'mac',
            'field_value': {
                'data': 'mac',
                'className': 'mac',
                'width': '14%'
            },
        },
        {
            'field_name_cn': 'SN',
            'field_name_en': 'sn',
            'field_value': {
                'data': 'sn',
                'className': 'sn',
                'width': '10%'
            },
        },
        {
            'field_name_cn': '固件ID',
            'field_name_en': 'firmwareId',
            'field_value': {
                'data': 'firmwareId',
                'className': 'firmwareId',
                'width': '16%'
            },
        },
        {
            'field_name_cn': '生产日期',
            'field_name_en': 'productionDate',
            'field_value': {
                'data': 'productionDate',
                'className': 'productionDate',
                'width': '10%',
            },
            'value_type': 'date',
        },

        {
            'field_name_cn': '型号ID',
            'field_name_en': 'modelId',
            'field_value': {
                'data': 'modelId',
                'className': 'modelId',
                'width': '7%',
            },  # deleted in read_target_factory_data
        },
    ],
    'device_model_info': [
        {
            'field_name_cn': '型号ID',
            'field_name_en': 'modelId',
            'field_value': {
                'data': 'modelId',
                'className': 'modelId',
                'width': '7%',
            },  # deleted in read_target_factory_data
        },
        {
            'field_name_cn': '硬件类型',
            'field_name_en': 'hardwareType',
            'field_value': {
                'data': 'hardwareType',
                'className': 'hardwareType',
                'width': '14%',
            },
        },
        {
            'field_name_cn': '硬件版本',
            'field_name_en': 'hardwareVersion',
            'field_value': {
                'data': 'hardwareVersion',
                'className': 'hardwareVersion',
                'width': '10%',
            },
        },
        {
            'field_name_cn': '硬件ID',
            'field_name_en': 'hardwareId',
            'field_value': {
                'data': 'hardwareId',
                'className': 'hardwareId',
                'width': '17%',
            },
        },
        {
            'field_name_cn': '类别',
            'field_name_en': 'categoryName',
            'field_value': {
                'data': 'categoryName',
                'className': 'categoryName',
                'width': '12%',
            },
        },
    ]
}


all_fields_firmware_filter = {
    'priority': [
        {
            "field_name_cn": "固件ID",
            'field_name_en': 'firmwareId',
            "field_value": {
                'data': 'firmwareId',
                'className': 'firmwareId',
                'width': '18%'
            },
        },
        {
            'field_name_cn': '固件版本',
            'field_name_en': 'firmwareVersion',
            'field_value': {
                'data': 'firmwareVersion',
                'className': 'firmwareVersion',
                'width': '17%'
            },
        },
        {
            'field_name_cn': '重要程度(fwType)',
            'field_name_en': 'fwType',
            'field_value': {
                'data': 'fwType',
                'className': 'fwType',
                'width': '8%'
            },
        },
        {
            'field_name_cn': 'oemId',
            'field_name_en': 'oemId',
            'field_value': {
                'data': 'oemId',
                'className': 'oemId',
                'width': '10%'
            },
        },
        {
            'field_name_cn': '硬件ID',
            'field_name_en': 'hwId',
            'field_value': {
                'data': 'hwId',
                'className': 'hwId',
                'width': '18%'
            },
        },
        {
            'field_name_cn': '固件文件名',
            'field_name_en': 'fileName',
            'field_value': {
                'data': 'fileName',
                'className': 'fileName',
                'width': '20%',
            },
        },
        {
            'field_name_cn': '协议',
            'field_name_en': 'protocol',
            'field_value': {
                'data': 'protocol',
                'className': 'protocol',
                'width': '6%'
            },
        },
        {
            'field_name_cn': '是否已召回',
            'field_name_en': 'revoked',
            'field_value': {
                'data': 'revoked',
                'className': 'revoked',
                'width': '6%'
            },
        },
    ],
    'other': [
        {
            'field_name_cn': '文件路径',
            'field_name_en': 'filePath',
            'field_value': '',
            'value_type': 'url'
        },
        {
            'field_name_cn': '发布日期',
            'field_name_en': 'releaseDate',
            'field_value': '',
            'value_type': 'date',
        },
        {
            'field_name_cn': '是否Beta固件',
            'field_name_en': 'isBeta',
            'field_value': ''
        },
        {
            'field_name_cn': 'oldestVersion',
            'field_name_en': 'oldestVersion',
            'field_value': ''
        },
        {
            'field_name_cn': '发布日志',
            'field_name_en': 'releaseLog',
            'field_value': ''
        },
    ]
}
all_fields_fw_release_task_filter = {
    'priority': [
        {
            "field_name_cn": "任务ID",
            'field_name_en': 'taskId',
            "field_value": {
                'data': 'taskId',
                'className': 'taskId',
                'width': '8%'
            },
        },
        {
            'field_name_cn': '固件ID',
            'field_name_en': 'firmwareId',
            'field_value': {
                'data': 'firmwareId',
                'className': 'firmwareId',
                'width': '17%'
            },
        },
        {
            'field_name_cn': '发布类型',
            'field_name_en': 'releaseType',
            'field_value': {
                'data': 'releaseType',
                'className': 'releaseType',
                'width': '10%'
            },
        },
        {
            'field_name_cn': '区域',
            'field_name_en': 'region',
            'field_value': {
                'data': 'region',
                'className': 'region',
                'width': '10%'
            },
        },
        {
            'field_name_cn': '推送状态',
            'field_name_en': 'statusCode',
            'field_value': {
                'data': 'statusCode',
                'className': 'statusCode',
                'width': '8%'
            },
        },
        {
            'field_name_cn': '完成情况（statusInfo）',
            'field_name_en': 'statusInfo',
            'field_value': {
                'data': 'statusInfo',
                'className': 'statusInfo',
                'width': '14%'
            },
        },
        {
            'field_name_cn': '完成数量',
            'field_name_en': 'completedQuantity',
            'field_value': {
                'data': 'completedQuantity',
                'className': 'completedQuantity',
                'width': '8%',
            },
        },
    ],
    'other': [
        {
            'field_name_cn': '申请人',
            'field_name_en': 'proposer',
            'field_value': ''
        },
        {
            'field_name_cn': '升级方式',
            'field_name_en': 'upgradeType',
            'field_value': ''
        },
        {
            'field_name_cn': '安装量预警',
            'field_name_en': 'installedQuantityWarn',
            'field_value': '',
        },
        {
            'field_name_cn': '通知数量',
            'field_name_en': 'notifyQuantity',
            'field_value': ''
        },
        {
            'field_name_cn': '通知方式',
            'field_name_en': 'notifyType',
            'field_value': ''
        },
        {
            'field_name_cn': '通知内容',
            'field_name_en': 'notifyContent',
            'field_value': ''
        },
        {
            'field_name_cn': '固件硬件匹配表',
            'field_name_en': 'fwHw',
            'field_value': ''
        },
        {
            'field_name_cn': '通知地区列表',
            'field_name_en': 'regionIdList',
            'field_value': ''
        },
        {
            'field_name_cn': '设备类别',
            'field_name_en': 'deviceCategory',
            'field_value': ''
        },
        {
            'field_name_cn': 'appCategoryList',
            'field_name_en': 'appCategoryList',
            'field_value': ''
        },
        {
            'field_name_cn': 'data',
            'field_name_en': 'data',
            'field_value': ''
        },
        {
            'field_name_cn': 'APP通知方式',
            'field_name_en': 'appNotifyType',
            'field_value': ''
        },
        {
            'field_name_cn': '固件通知方式',
            'field_name_en': 'fwNotifyType',
            'field_value': ''
        },

        {
            'field_name_cn': '是否Beta固件',
            'field_name_en': 'isBeta',
            'field_value': ''
        },
        {
            'field_name_cn': '是否下架',
            'field_name_en': 'onShelf',
            'field_value': ''
        },
        {
            'field_name_cn': '灰度发布',
            'field_name_en': 'grayRelease',
            'field_value': ''
        },
        {
            'field_name_cn': '灰度发布比例',
            'field_name_en': 'grayReleasePercentage',
            'field_value': ''
        },
        {
            'field_name_cn': 'dmsId',
            'field_name_en': 'dmsId',
            'field_value': ''
        },
        {
            'field_name_cn': 'query',
            'field_name_en': 'query',
            'field_value': ''
        },
        {
            'field_name_cn': 'version',
            'field_name_en': 'version',
            'field_value': ''
        },
    ]
}
all_fields_fw_locale_filter = {
    'priority': [
        {
            'field_name_cn': 'ID',
            'field_name_en': 'id',
            'field_value': {
                'data': 'id',
                'className': 'id',
                'width': '7%'
            },
        },
        {
            "field_name_cn": "固件ID",
            'field_name_en': 'firmwareId',
            "field_value": {
                'data': 'firmwareId',
                'className': 'firmwareId',
                'width': '18%'
            },
        },
        {
            'field_name_cn': 'locale',
            'field_name_en': 'locale',
            'field_value': {
                'data': 'locale',
                'className': 'locale',
                'width': '10%'
            },
        },
        {
            'field_name_cn': '发布日志',
            'field_name_en': 'releaseLog',
            'field_value': {
                'data': 'releaseLog',
                'className': 'releaseLog',
                'width': '16%'
            },
        },
        {
            'field_name_cn': '固件Title',
            'field_name_en': 'fwTitle',
            'field_value': {
                'data': 'fwTitle',
                'className': 'fwTitle',
                'width': '10%'
            },
        }
    ],
}

all_fields_firmware_filter_mainland = {
    'priority': [
        {
            "field_name_cn": "固件ID",
            'field_name_en': 'firmwareId',
            "field_value": {
                'data': 'firmwareId',
                'className': 'firmwareId',
                'width': '15%'
            },
        },
        {
            'field_name_cn': '固件版本',
            'field_name_en': 'firmwareVersion',
            'field_value': {
                'data': 'firmwareVersion',
                'className': 'firmwareVersion',
                'width': '13%'
            },
        },
        {
            'field_name_cn': '重要程度',
            'field_name_en': 'priority',
            'field_value': {
                'data': 'priority',
                'className': 'priority',
                'width': '7%'
            },
        },

        {
            'field_name_cn': '固件文件名',
            'field_name_en': 'fileName',
            'field_value': {
                'data': 'fileName',
                'className': 'fileName',
                'width': '20%',
            },
        },
        {
            'field_name_cn': '发布日期',
            'field_name_en': 'releaseDate',
            'field_value': {
                'data': 'releaseDate',
                'className': 'releaseDate',
                'width': '7%'
            },
        },
        {
            'field_name_cn': '协议',
            'field_name_en': 'protocol',
            'field_value': {
                'data': 'protocol',
                'className': 'protocol',
                'width': '7%'
            },
        },
    ],
    'other': [
        {
            'field_name_cn': '文件路径',
            'field_name_en': 'filePath',
            'field_value': '',
            'value_type': 'url'
        },
        {
            'field_name_cn': '固件种子路径',
            'field_name_en': 'fwTorrentPath',
            'field_value': '',
            'value_type': 'url'
        },
        {
            'field_name_cn': '种子Hash',
            'field_name_en': 'torrentHash',
            'field_value': '',
        },
        {
            'field_name_cn': '发布日志',
            'field_name_en': 'releaseLog',
            'field_value': '',
        },

        {
            'field_name_cn': '是否Beta固件',
            'field_name_en': 'isBeta',
            'field_value': ''
        },
        {
            'field_name_cn': '日志(log)',
            'field_name_en': 'log',
            'field_value': ''
        },
    ]
}
all_fields_fw_release_task_mainland_filter = {
    'priority': [
        {
            "field_name_cn": "任务ID",
            'field_name_en': 'taskId',
            "field_value": {
                'data': 'taskId',
                'className': 'taskId',
                'width': '8%'
            },
        },
        {
            'field_name_cn': '固件ID',
            'field_name_en': 'firmwareId',
            'field_value': {
                'data': 'firmwareId',
                'className': 'firmwareId',
                'width': '17%'
            },
        },
        {
            'field_name_cn': '发布类型',
            'field_name_en': 'releaseType',
            'field_value': {
                'data': 'releaseType',
                'className': 'releaseType',
                'width': '10%'
            },
        },
        {
            'field_name_cn': '推送状态',
            'field_name_en': 'statusCode',
            'field_value': {
                'data': 'statusCode',
                'className': 'statusCode',
                'width': '8%'
            },
        },
        {
            'field_name_cn': '完成情况（status）',
            'field_name_en': 'status',
            'field_value': {
                'data': 'status',
                'className': 'status',
                'width': '14%'
            },
        },
        {
            'field_name_cn': '完成数量',
            'field_name_en': 'completedQuantity',
            'field_value': {
                'data': 'completedQuantity',
                'className': 'completedQuantity',
                'width': '8%',
            },
        },
    ],
    'other': [
        {
            'field_name_cn': '申请人',
            'field_name_en': 'proposer',
            'field_value': ''
        },
        {
            'field_name_cn': '升级方式',
            'field_name_en': 'upgradeType',
            'field_value': ''
        },
        {
            'field_name_cn': '安装量预警',
            'field_name_en': 'installedQuantityWarn',
            'field_value': '',
        },
        {
            'field_name_cn': '通知数量',
            'field_name_en': 'notifyQuantity',
            'field_value': ''
        },
        {
            'field_name_cn': '通知方式',
            'field_name_en': 'notifyType',
            'field_value': ''
        },
        {
            'field_name_cn': '通知内容',
            'field_name_en': 'notifyContent',
            'field_value': ''
        },
        {
            'field_name_cn': '固件硬件匹配表',
            'field_name_en': 'fwHw',
            'field_value': ''
        },
        {
            'field_name_cn': '通知地区列表',
            'field_name_en': 'regionIdList',
            'field_value': ''
        },
        {
            'field_name_cn': '设备类别',
            'field_name_en': 'deviceCategory',
            'field_value': ''
        },
        {
            'field_name_cn': 'appCategoryList',
            'field_name_en': 'appCategoryList',
            'field_value': ''
        },
        {
            'field_name_cn': 'data',
            'field_name_en': 'data',
            'field_value': ''
        },

        {
            'field_name_cn': '是否Beta固件',
            'field_name_en': 'isBeta',
            'field_value': ''
        },
        {
            'field_name_cn': 'retainedMessageBar',
            'field_name_en': 'retainedMessageBar',
            'field_value': ''
        }
    ]
}
all_fields_fw_upgrade_cache_export_filter = {
    'priority': [
        {
            'field_name_cn': '硬件ID',
            'field_name_en': 'hwId',
            'field_value': {
                'data': 'hwId',
                'className': 'hwId',
                'width': '17%'
            },
        },
        {
            "field_name_cn": "oemID",
            'field_name_en': 'oemId',
            "field_value": {
                'data': 'oemId',
                'className': 'oemId',
                'width': '14%'
            },
        },
        {
            'field_name_cn': '源版本',
            'field_name_en': 'version',
            'field_value': {
                'data': 'version',
                'className': 'version',
                'width': '10%'
            },
        },
        {
            'field_name_cn': '目标版本',
            'field_name_en': 'versionNewest',
            'field_value': {
                'data': 'versionNewest',
                'className': 'versionNewest',
                'width': '10%'
            },
        },
        {
            'field_name_cn': '目标固件ID',
            'field_name_en': 'fwIdNewest',
            'field_value': {
                'data': 'fwIdNewest',
                'className': 'fwIdNewest',
                'width': '17%'
            },
        }
    ],
}
all_fields_fw_upgrade_cache_mainland_filter = {
    'priority': [
        {
            'field_name_cn': '固件ID',
            'field_name_en': 'firmwareId',
            'field_value': {
                'data': 'firmwareId',
                'className': 'firmwareId',
                'width': '17%'
            },
        },
        {
            'field_name_cn': '硬件ID',
            'field_name_en': 'hardwareId',
            'field_value': {
                'data': 'hardwareId',
                'className': 'hardwareId',
                'width': '17%'
            },
        },

        {
            'field_name_cn': '目标固件ID',
            'field_name_en': 'firmwareIdTarget',
            'field_value': {
                'data': 'firmwareIdTarget',
                'className': 'firmwareIdTarget',
                'width': '17%'
            },
        },

        {
            'field_name_cn': '升级方式',
            'field_name_en': 'upgradeType',
            'field_value': {
                'data': 'upgradeType',
                'className': 'upgradeType',
                'width': '10%'
            },
        },
    ],
}
all_fields_firmware_upgrade_relationship_mainland_filter = {
    'priority': [
        {
            'field_name_cn': '固件ID',
            'field_name_en': 'firmwareIdUpgrade',
            'field_value': {
                'data': 'firmwareIdUpgrade',
                'className': 'firmwareIdUpgrade',
                'width': '17%'
            },
        },
        {
            'field_name_cn': '硬件ID',
            'field_name_en': 'hardwareId',
            'field_value': {
                'data': 'hardwareId',
                'className': 'hardwareId',
                'width': '17%'
            },
        },

        {
            'field_name_cn': '目标固件ID',
            'field_name_en': 'firmwareId',
            'field_value': {
                'data': 'firmwareId',
                'className': 'firmwareId',
                'width': '17%'
            },
        },
    ],
}
all_fields_firmware_degrade_relationship_mainland_filter = {
    'priority': [
        {
            'field_name_cn': '固件ID',
            'field_name_en': 'firmwareId',
            'field_value': {
                'data': 'firmwareId',
                'className': 'firmwareId',
                'width': '17%'
            },
        },
        {
            'field_name_cn': '硬件ID',
            'field_name_en': 'hardwareId',
            'field_value': {
                'data': 'hardwareId',
                'className': 'hardwareId',
                'width': '17%'
            },
        },
        {
            'field_name_cn': '目标固件ID',
            'field_name_en': 'firmwareIdDegrade',
            'field_value': {
                'data': 'firmwareIdDegrade',
                'className': 'firmwareIdDegrade',
                'width': '17%'
            },
        },
    ],
}
all_fields_firmware_suitable_model_mainland_filter = {
    'priority': [
        {
            'field_name_cn': '固件ID',
            'field_name_en': 'firmwareId',
            'field_value': {
                'data': 'firmwareId',
                'className': 'firmwareId',
                'width': '17%'
            },
        },
        {
            'field_name_cn': '硬件ID',
            'field_name_en': 'hardwareId',
            'field_value': {
                'data': 'hardwareId',
                'className': 'hardwareId',
                'width': '17%'
            },
        }
    ],
}
all_fields_fw_rollback_task_mainland_filter = {
    'priority': [
        {
            'field_name_cn': '固件ID',
            'field_name_en': 'firmwareId',
            'field_value': {
                'data': 'firmwareId',
                'className': 'firmwareId',
                'width': '17%'
            },
        },
        {
            'field_name_cn': '召回类型',
            'field_name_en': 'rollbackType',
            'field_value': {
                'data': 'rollbackType',
                'className': 'rollbackType',
                'width': '8%'
            },
        },
        {
            'field_name_cn': '通知方式',
            'field_name_en': 'notifyType',
            'field_value': {
                'data': 'notifyType',
                'className': 'notifyType',
                'width': '8%'
            },
        },
        {
            'field_name_cn': '推送状态',
            'field_name_en': 'statusCode',
            'field_value': {
                'data': 'statusCode',
                'className': 'statusCode',
                'width': '8%'
            },
        },
        {
            'field_name_cn': '完成情况（status）',
            'field_name_en': 'status',
            'field_value': {
                'data': 'status',
                'className': 'status',
                'width': '14%'
            },
        },
        {
            'field_name_cn': '完成数量',
            'field_name_en': 'completedQuantity',
            'field_value': {
                'data': 'completedQuantity',
                'className': 'completedQuantity',
                'width': '8%',
            },
        },
    ],
    'other': [
        {
            'field_name_cn': '硬件ID列表',
            'field_name_en': 'hwIdList',
            'field_value': ''
        },
        {
            'field_name_cn': '通知内容',
            'field_name_en': 'notifyContent',
            'field_value': ''
        },
        {
            'field_name_cn': 'retainedMessageBar',
            'field_name_en': 'retainedMessageBar',
            'field_value': ''
        }
    ]
}


all_fields_app_version_filter = {
    'priority': [
        {
            "field_name_cn": "APPID",
            'field_name_en': 'appVersionId',
            "field_value": {
                'data': 'appVersionId',
                'className': 'appVersionId',
                'width': '8%'
            },
        },
        {
            'field_name_cn': 'APP包名',
            'field_name_en': 'packageName',
            'field_value': {
                'data': 'packageName',
                'className': 'packageName',
                'width': '12%'
            },
        },
        {
            'field_name_cn': 'APP名称',
            'field_name_en': 'appName',
            'field_value': {
                'data': 'appName',
                'className': 'appName',
                'width': '10%'
            },
        },
        {
            'field_name_cn': 'APP版本',
            'field_name_en': 'appVersionName',
            'field_value': {
                'data': 'appVersionName',
                'className': 'appVersionName',
                'width': '10%'
            },
        },
        {
            'field_name_cn': 'AppVersionCode',
            'field_name_en': 'appVersionCode',
            'field_value': {
                'data': 'appVersionCode',
                'className': 'appVersionCode',
                'width': '8%'
            },
        },
        {
            'field_name_cn': '状态(onShelf)',
            'field_name_en': 'onShelf',
            'field_value': {
                'data': 'onShelf',
                'className': 'onShelf',
                'width': '8%'
            },
        },
        {
            'field_name_cn': 'APP包大小（KB）',
            'field_name_en': 'size',
            'field_value': {
                'data': 'size',
                'className': 'size',
                'width': '10%'
            },
        },
        {
            'field_name_cn': '平台',
            'field_name_en': 'platform',
            'field_value': {
                'data': 'platform',
                'className': 'platform',
                'width': '10%'
            },
        },
        {
            'field_name_cn': 'APP发布日期',
            'field_name_en': 'appReleaseDate',
            'field_value': {
                'data': 'appReleaseDate',
                'className': 'appReleaseDate',
                'width': '10%',
            },
        }
    ],
    'other': [
        {
            'field_name_cn': 'APPUrl',
            'field_name_en': 'appUrl',
            'field_value': '',
            'value_type': 'url'
        },
        {
            'field_name_cn': 'displayType',
            'field_name_en': 'displayType',
            'field_value': '',
        },
        {
            'field_name_cn': 'retainedMessageBar',
            'field_name_en': 'retainedMessageBar',
            'field_value': ''
        },
        {
            'field_name_cn': 'APP介绍',
            'field_name_en': 'appIntroduction',
            'field_value': ''
        },
        {
            'field_name_cn': 'MD5',
            'field_name_en': 'md5',
            'field_value': ''
        },

        {
            'field_name_cn': 'APP更新日志',
            'field_name_en': 'appUpdateLog',
            'field_value': ''
        },
        {
            'field_name_cn': 'appUpdateType',
            'field_name_en': 'appUpdateType',
            'field_value': ''
        }
    ]
}
all_fields_app_release_task_filter = {
    'priority': [
        {
            "field_name_cn": "任务ID",
            'field_name_en': 'taskId',
            "field_value": {
                'data': 'taskId',
                'className': 'taskId',
                'width': '8%'
            },
        },
        {
            'field_name_cn': 'APP文件包名',
            'field_name_en': 'packageName',
            'field_value': {
                'data': 'packageName',
                'className': 'packageName',
                'width': '12%'
            },
        },
        {
            'field_name_cn': 'AppVersionCode',
            'field_name_en': 'appVersionCode',
            'field_value': {
                'data': 'appVersionCode',
                'className': 'appVersionCode',
                'width': '8%'
            },
        },
        {
            'field_name_cn': '推送状态',
            'field_name_en': 'statusCode',
            'field_value': {
                'data': 'statusCode',
                'className': 'statusCode',
                'width': '8%'
            },
        },
        {
            'field_name_cn': '完成情况',
            'field_name_en': 'status',
            'field_value': {
                'data': 'status',
                'className': 'status',
                'width': '8%'
            },
        },
        {
            'field_name_cn': '完成数量',
            'field_name_en': 'completedQuantity',
            'field_value': {
                'data': 'completedQuantity',
                'className': 'completedQuantity',
                'width': '8%',
            },
        },
        {
            'field_name_cn': '通知方式',
            'field_name_en': 'notifyType',
            'field_value': {
                'data': 'notifyType',
                'className': 'notifyType',
                'width': '8%'
            },
        },
        {
            'field_name_cn': 'retainedMessageBar',
            'field_name_en': 'retainedMessageBar',
            'field_value': {
                'data': 'retainedMessageBar',
                'className': 'retainedMessageBar',
                'width': '8%'
            },
        },
        {
            'field_name_cn': '通知内容',
            'field_name_en': 'notifyContent',
            'field_value': {
                'data': 'notifyContent',
                'className': 'notifyContent',
                'width': '18%'
            },
        },
        {
            'field_name_cn': 'data',
            'field_name_en': 'data',
            'field_value': {
                'data': 'data',
                'className': 'data',
                'width': '14%'
            },
        },
    ],
    'other': [
    ]
}

all_fields_app_version_mainland_filter = {
    'priority': [
        {
            "field_name_cn": "APPID",
            'field_name_en': 'appVersionId',
            "field_value": {
                'data': 'appVersionId',
                'className': 'appVersionId',
                'width': '8%'
            },
        },
        {
            'field_name_cn': 'APP包名',
            'field_name_en': 'packageName',
            'field_value': {
                'data': 'packageName',
                'className': 'packageName',
                'width': '12%'
            },
        },
        {
            'field_name_cn': 'APP名称',
            'field_name_en': 'appName',
            'field_value': {
                'data': 'appName',
                'className': 'appName',
                'width': '10%'
            },
        },
        {
            'field_name_cn': 'APP版本',
            'field_name_en': 'appVersionName',
            'field_value': {
                'data': 'appVersionName',
                'className': 'appVersionName',
                'width': '10%'
            },
        },
        {
            'field_name_cn': 'AppVersionCode',
            'field_name_en': 'appVersionCode',
            'field_value': {
                'data': 'appVersionCode',
                'className': 'appVersionCode',
                'width': '8%'
            },
        },
        {
            'field_name_cn': '状态(onShelf)',
            'field_name_en': 'onShelf',
            'field_value': {
                'data': 'onShelf',
                'className': 'onShelf',
                'width': '8%'
            },
        },
        {
            'field_name_cn': 'APP包大小（KB）',
            'field_name_en': 'size',
            'field_value': {
                'data': 'size',
                'className': 'size',
                'width': '10%'
            },
        },
        {
            'field_name_cn': 'APP发布日期',
            'field_name_en': 'appReleaseDate',
            'field_value': {
                'data': 'appReleaseDate',
                'className': 'appReleaseDate',
                'width': '10%',
            },
        }
    ],
    'other': [
        {
            'field_name_cn': 'APPUrl',
            'field_name_en': 'appUrl',
            'field_value': '',
            'value_type': 'url'
        },
        {
            'field_name_cn': 'displayType',
            'field_name_en': 'displayType',
            'field_value': '',
        },
        {
            'field_name_cn': 'retainedMessageBar',
            'field_name_en': 'retainedMessageBar',
            'field_value': ''
        },
        {
            'field_name_cn': 'APP介绍',
            'field_name_en': 'appIntroduction',
            'field_value': ''
        },
        {
            'field_name_cn': 'MD5',
            'field_name_en': 'md5',
            'field_value': ''
        },

        {
            'field_name_cn': 'APP更新日志',
            'field_name_en': 'appUpdateLog',
            'field_value': ''
        },
        {
            'field_name_cn': 'appUpdateLevel',
            'field_name_en': 'appUpdateLevel',
            'field_value': ''
        },
    ]
}
all_fields_app_link_info_filter = {
    'priority': [
        {
            "field_name_cn": "账户ID",
            'field_name_en': 'accountId',
            "field_value": {
                'data': 'accountId',
                'className': 'accountId',
                'width': '8%'
            },
        },
        {
            "field_name_cn": "APP类型",
            'field_name_en': 'appType',
            "field_value": {
                'data': 'appType',
                'className': 'appType',
                'width': '8%'
            },
        },
        {
            'field_name_cn': 'APP包名',
            'field_name_en': 'packageName',
            'field_value': {
                'data': 'packageName',
                'className': 'packageName',
                'width': '12%'
            },
        },

        {
            'field_name_cn': 'APP版本编码',
            'field_name_en': 'versionCode',
            'field_value': {
                'data': 'versionCode',
                'className': 'versionCode',
                'width': '8%'
            },
        },
        {
            'field_name_cn': '状态',
            'field_name_en': 'online',
            'field_value': {
                'data': 'online',
                'className': 'online',
                'width': '8%'
            },
        },
        {
            'field_name_cn': '机型',
            'field_name_en': 'model',
            'field_value': {
                'data': 'model',
                'className': 'model',
                'width': '8%'
            },
        },
        {
            'field_name_cn': '安卓版本',
            'field_name_en': 'androidVersion',
            'field_value': {
                'data': 'androidVersion',
                'className': 'androidVersion',
                'width': '8%'
            },
        },
        {
            'field_name_cn': '上次登录日期',
            'field_name_en': 'lastLoginDate',
            'field_value': {
                'data': 'lastLoginDate',
                'className': 'lastLoginDate',
                'width': '8%'
            },
            'value_type': 'date'
        },
    ],
    'other': [
        {
            'field_name_cn': 'badge',
            'field_name_en': 'badge',
            'field_value': '',
        },
        {
            'field_name_cn': 'Linux内核版本',
            'field_name_en': 'kernelVersion',
            'field_value': '',
        },
        {
            'field_name_cn': '系统版本',
            'field_name_en': 'systemVersion',
            'field_value': ''
        },
        {
            'field_name_cn': '机型',
            'field_name_en': 'model',
            'field_value': ''
        },
        {
            'field_name_cn': '内存',
            'field_name_en': 'memory',
            'field_value': ''
        },

        {
            'field_name_cn': '处理器',
            'field_name_en': 'processor',
            'field_value': ''
        },
        {
            'field_name_cn': '分辨率',
            'field_name_en': 'resolution',
            'field_value': ''
        },
        {
            'field_name_cn': '存储',
            'field_name_en': 'storage',
            'field_value': ''
        },
        {
            'field_name_cn': 'deviceToken',
            'field_name_en': 'deviceToken',
            'field_value': ''
        },
        {
            'field_name_cn': 'loginToken',
            'field_name_en': 'loginToken',
            'field_value': ''
        }
    ]
}
all_fields_app_new_link_info_filter = {
    'priority': [
        {
            "field_name_cn": "AppKey",
            'field_name_en': 'appKey',
            "field_value": {
                'data': 'appKey',
                'className': 'appKey',
                'width': '16%'
            },
        },
        {
            "field_name_cn": "账户ID",
            'field_name_en': 'accountId',
            "field_value": {
                'data': 'accountId',
                'className': 'accountId',
                'width': '5%'
            },
        },

        {
            'field_name_cn': 'APP包名',
            'field_name_en': 'packageName',
            'field_value': {
                'data': 'packageName',
                'className': 'packageName',
                'width': '12%'
            },
        },

        {
            'field_name_cn': 'APP版本编码',
            'field_name_en': 'versionCode',
            'field_value': {
                'data': 'versionCode',
                'className': 'versionCode',
                'width': '5%'
            },
        },
        {
            'field_name_cn': '状态',
            'field_name_en': 'online',
            'field_value': {
                'data': 'online',
                'className': 'online',
                'width': '5%'
            },
        },
        {
            'field_name_cn': '产品类别',
            'field_name_en': 'productType',
            'field_value': {
                'data': 'productType',
                'className': 'productType',
                'width': '12%'
            },
        },
        {
            'field_name_cn': '推送类型',
            'field_name_en': 'pushType',
            'field_value': {
                'data': 'pushType',
                'className': 'pushType',
                'width': '8%'
            },
        },
        {
            'field_name_cn': '上次登录日期',
            'field_name_en': 'lastLoginDate',
            'field_value': {
                'data': 'lastLoginDate',
                'className': 'lastLoginDate',
                'width': '8%'
            },
            'value_type': 'date'
        },
    ],
    'other': [
        {
            "field_name_cn": "APP-ID",
            'field_name_en': 'appId',
            "field_value": ''
        },
        {
            'field_name_cn': 'badge',
            'field_name_en': 'badge',
            'field_value': '',
        },
        {
            'field_name_cn': 'loginToken',
            'field_name_en': 'loginToken',
            'field_value': ''
        },
        {
            'field_name_cn': '订阅消息类型',
            'field_name_en': 'subscribeMsgType',
            'field_value': ''
        }
    ]
}

all_fields_plugin_filter = {
    'priority': [
        {
            "field_name_cn": "插件ID",
            'field_name_en': 'pluginId',
            "field_value": {
                'data': 'pluginId',
                'className': 'pluginId',
                'width': '13%'
            },
        },
        {
            'field_name_cn': '插件版本',
            'field_name_en': 'pluginVersion',
            'field_value': {
                'data': 'pluginVersion',
                'className': 'pluginVersion',
                'width': '10%'
            },
        },
        {
            'field_name_cn': '状态',
            'field_name_en': 'onShelf',
            'field_value': {
                'data': 'onShelf',
                'className': 'onShelf',
                'width': '7%'
            },
        },
        {
            'field_name_cn': '名称',
            'field_name_en': 'name',
            'field_value': {
                'data': 'name',
                'className': 'name',
                'width': '10%'
            },
        },
        {
            'field_name_cn': '大小(Byte)',
            'field_name_en': 'size',
            'field_value': {
                'data': 'size',
                'className': 'size',
                'width': '10%'
            },
        },
        {
            'field_name_cn': '发布时间',
            'field_name_en': 'releaseTime',
            'field_value': {
                'data': 'releaseTime',
                'className': 'releaseTime',
                'width': '10%',
            },
        },
        {
            'field_name_cn': '是否Beta',
            'field_name_en': 'isBeta',
            'field_value': {
                'data': 'isBeta',
                'className': 'isBeta',
                'width': '6%'
            },
        },
    ],
    'other': [
        {
            'field_name_cn': '作者（author）',
            'field_name_en': 'author',
            'field_value': '',
        },
        {
            'field_name_cn': 'tag',
            'field_name_en': 'tag',
            'field_value': '',
        },
        {
            'field_name_cn': 'dataFileName',
            'field_name_en': 'dataFileName',
            'field_value': ''
        },
        {
            'field_name_cn': 'dataFileUrl',
            'field_name_en': 'dataFileUrl',
            'field_value': '',
            'value_type': 'url'
        },
        {
            'field_name_cn': 'pcDescFileName',
            'field_name_en': 'pcDescriptionFileName',
            'field_value': ''
        },
        {
            'field_name_cn': 'pcDescFileUrl',
            'field_name_en': 'pcDescriptionFileUrl',
            'field_value': '',
            'value_type': 'url'
        },
        {
            'field_name_cn': 'mobDescFileName',
            'field_name_en': 'mobileDescriptionFileName',
            'field_value': ''
        },
        {
            'field_name_cn': 'mobDescFileUrl',
            'field_name_en': 'mobileDescriptionFileUrl',
            'field_value': '',
            'value_type': 'url'
        },
        {
            'field_name_cn': 'pcIconFileName',
            'field_name_en': 'pcIconFileName',
            'field_value': ''
        },
        {
            'field_name_cn': 'pcIconFileUrl',
            'field_name_en': 'pcIconFileUrl',
            'field_value': '',
            'value_type': 'url'
        },
        {
            'field_name_cn': 'mobIconFileName',
            'field_name_en': 'mobileIconFileName',
            'field_value': ''
        },
        {
            'field_name_cn': 'mobIconFileUrl',
            'field_name_en': 'mobileIconFileUrl',
            'field_value': '',
            'value_type': 'url'
        },
        {
            'field_name_cn': 'appWebZipFileName',
            'field_name_en': 'appWebZipFileName',
            'field_value': ''
        },
        {
            'field_name_cn': 'appWebZipFileUrl',
            'field_name_en': 'appWebZipFileUrl',
            'field_value': '',
            'value_type': 'url'
        },
        {
            'field_name_cn': '更新日志',
            'field_name_en': 'updateLog',
            'field_value': '',
        },

        {
            'field_name_cn': 'MD5',
            'field_name_en': 'md5',
            'field_value': ''
        },
        {
            'field_name_cn': 'Components',
            'field_name_en': 'components',
            'field_value': ''
        },
        {
            'field_name_cn': '插件类别',
            'field_name_en': 'pluginCategory',
            'field_value': '',
        },

        {
            'field_name_cn': 'accessoryList',
            'field_name_en': 'accessoryList',
            'field_value': ''
        },
        {
            'field_name_cn': 'appTypeList',
            'field_name_en': 'applicationTypeList',
            'field_value': ''
        },
        {
            'field_name_cn': 'excellentImgFileUrl',
            'field_name_en': 'excellentImgFileUrl',
            'field_value': '',
            'value_type': 'url'
        },
        {
            'field_name_cn': 'goodIconFileUrl',
            'field_name_en': 'goodIconFileUrl',
            'field_value': '',
            'value_type': 'url'
        },
        {
            'field_name_cn': 'winPcExcIconUrl',
            'field_name_en': 'winPcExcellentIconUrl',
            'field_value': '',
            'value_type': 'url'
        },
        {
            'field_name_cn': 'winPcDescUrl',
            'field_name_en': 'winPcDescUrl',
            'field_value': '',
            'value_type': 'url'
        },
        {
            'field_name_cn': 'winPcSetPageUrl',
            'field_name_en': 'winPcSetPageUrl',
            'field_value': '',
            'value_type': 'url'
        },
    ]
}
all_fields_plugin_release_task_filter = {
    'priority': [
        {
            "field_name_cn": "任务ID",
            'field_name_en': 'taskId',
            "field_value": {
                'data': 'taskId',
                'className': 'taskId',
                'width': '8%'
            },
        },
        {
            'field_name_cn': '插件ID',
            'field_name_en': 'pluginId',
            'field_value': {
                'data': 'pluginId',
                'className': 'pluginId',
                'width': '14%'
            },
        },
        {
            'field_name_cn': '插件版本',
            'field_name_en': 'pluginVersion',
            'field_value': {
                'data': 'pluginVersion',
                'className': 'pluginVersion',
                'width': '8%'
            },
        },
        {
            'field_name_cn': '发布类型',
            'field_name_en': 'releaseType',
            'field_value': {
                'data': 'releaseType',
                'className': 'releaseType',
                'width': '8%'
            },
        },
        {
            'field_name_cn': '通知方式',
            'field_name_en': 'notifyType',
            'field_value': {
                'data': 'notifyType',
                'className': 'notifyType',
                'width': '10%'
            },
        },
        {
            'field_name_cn': '推送状态',
            'field_name_en': 'statusCode',
            'field_value': {
                'data': 'statusCode',
                'className': 'statusCode',
                'width': '8%'
            },
        },
        {
            'field_name_cn': '完成情况（status）',
            'field_name_en': 'statusInfo',
            'field_value': {
                'data': 'status',
                'className': 'status',
                'width': '14%'
            },
        },
        {
            'field_name_cn': '完成数量',
            'field_name_en': 'completedQuantity',
            'field_value': {
                'data': 'completedQuantity',
                'className': 'completedQuantity',
                'width': '8%',
            },
        },
    ],
    'other': [
        {
            'field_name_cn': '申请人',
            'field_name_en': 'proposer',
            'field_value': ''
        },
        {
            'field_name_cn': '安装量预警',
            'field_name_en': 'installedQuantityWarn',
            'field_value': '',
        },
        {
            'field_name_cn': '通知内容',
            'field_name_en': 'notifyContent',
            'field_value': ''
        },
        {
            'field_name_cn': '通知数量',
            'field_name_en': 'notifyQuantity',
            'field_value': ''
        },
        {
            'field_name_cn': 'retainedMessageBar',
            'field_name_en': 'retainedMessageBar',
            'field_value': ''
        },
        {
            'field_name_cn': '固件硬件匹配表',
            'field_name_en': 'fwHw',
            'field_value': ''
        },
        {
            'field_name_cn': '插件版本列表',
            'field_name_en': 'pluginVersionList',
            'field_value': ''
        },
        {
            'field_name_cn': '通知地区列表',
            'field_name_en': 'regionIdList',
            'field_value': ''
        },
        {
            'field_name_cn': '通知未安装',
            'field_name_en': 'notInstalledNotify',
            'field_value': ''
        },
        {
            'field_name_cn': '设备类别',
            'field_name_en': 'deviceCategory',
            'field_value': ''
        },
        {
            'field_name_cn': 'appCategoryList',
            'field_name_en': 'appCategoryList',
            'field_value': ''
        },
        {
            'field_name_cn': 'data',
            'field_name_en': 'data',
            'field_value': ''
        },

        {
            'field_name_cn': '是否Beta固件',
            'field_name_en': 'isBeta',
            'field_value': ''
        }
    ]
}
all_fields_plugin_suitable_model_filter = {
    'priority': [
        {
            'field_name_cn': '插件ID',
            'field_name_en': 'pluginId',
            'field_value': {
                'data': 'pluginId',
                'className': 'pluginId',
                'width': '18%'
            },
        },
        {
            'field_name_cn': '插件版本号',
            'field_name_en': 'pluginVersion',
            'field_value': {
                'data': 'pluginVersion',
                'className': 'pluginVersion',
                'width': '14%'
            },
        },
        {
            "field_name_cn": "固件ID",
            'field_name_en': 'fwId',
            "field_value": {
                'data': 'fwId',
                'className': 'fwId',
                'width': '18%'
            },
        },
        {
            "field_name_cn": "硬件ID",
            'field_name_en': 'hwId',
            "field_value": {
                'data': 'hwId',
                'className': 'hwId',
                'width': '18%'
            },
        },
    ],
}
all_fields_plugin_upgrade_cache_filter = {
    'priority': [
        {
            "field_name_cn": "插件ID",
            'field_name_en': 'pluginId',
            "field_value": {
                'data': 'pluginId',
                'className': 'pluginId',
                'width': '17%'
            },
        },

        {
            'field_name_cn': '硬件ID',
            'field_name_en': 'hwId',
            'field_value': {
                'data': 'hwId',
                'className': 'hwId',
                'width': '17%'
            },
        },

        {
            'field_name_cn': '固件ID',
            'field_name_en': 'fwId',
            'field_value': {
                'data': 'fwId',
                'className': 'fwId',
                'width': '17%'
            },
        },

        {
            'field_name_cn': '插件最新版本',
            'field_name_en': 'pluginVersionNewest',
            'field_value': {
                'data': 'pluginVersionNewest',
                'className': 'pluginVersionNewest',
                'width': '12%'
            },
        },

    ],
}
