"""
WSGI config for webManager project.

It exposes the WSGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/1.11/howto/deployment/wsgi/
"""
# -*- coding:utf-8 -*-

import os

import sys
from django.core.wsgi import get_wsgi_application

reload(sys)
sys.setdefaultencoding('utf-8')

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "webmanager.settings")

application = get_wsgi_application()

# initTask()
