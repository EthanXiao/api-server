from django import template
from django.template.defaultfilters import stringfilter

register = template.Library()


@register.filter
@stringfilter
def str_replace(value):
    value.replace(';', '; ')
    return value

# register.filter('str_replace', str_replace)
