/**
 * Created by yuzhijiang on 2017/11/8.
 */

// $.ajaxSetup({
//     data: {
//         authority: 'APP'
//     }
// });

$(document).ready(function () {

    load_search_result();
                //点击事件
    $('#table-account-info-cn-north-1')
        .on('click', ".parent-tr-cn-north-1", function () {

        if ($(this).is('.parent-tr-cn-north-1')) {
            var email = $(this).find('.email').text().trim();
            var accountId = $(this).find('.accountId').text().trim();
            if (email == 'null' || email.length == 0) {
                alert("请绑定账户邮箱");
                return
            }

            var $tr = $(this);
            var table_name1 = ('table-account-info-cn-north-1').replace(/-/g, '_');
            var row = window[table_name1].row($tr);

            if (row.child.isShown()) {
                row.child.hide();
                $tr.removeClass('shown');
            } else {

                $.ajax({
                    url: "/account/getAccountExtraInfo",
                    type: "POST",
                    dataType: "json",
                    data: {
                        accountId: accountId,
                        selectedRegion: 'cn-north-1'
                    },
                    success: function (data) {
                        var data1 = eval(data);
                        row.child(data1.html).show();
                        $(this).addClass('shown');

                        load_child_table(accountId,'cn-north-1');
                    },
                    error: function (data) {
                        $('#universal-title').html('<strong>绑定信息查询结果</strong>');
                        $('#universal-message').html('绑定信息查询失败。<br/>请稍后重试。');
                        $('#universal-modal').modal('show')
                        alert("您可能已退出。");
                    }
                });

            }
        }
    });
                //点击事件
    $('#table-account-info-us-east-1')
        .on('click', ".parent-tr-us-east-1", function () {

        if ($(this).is('.parent-tr-us-east-1')) {
            var email = $(this).find('.email').text().trim();
            var accountId = $(this).find('.accountId').text().trim();
            if (email == 'null' || email.length == 0) {
                alert("请绑定账户邮箱");
                return
            }

            var $tr = $(this);
            var table_name1 = ('table-account-info-us-east-1').replace(/-/g, '_');
            var row = window[table_name1].row($tr);

            if (row.child.isShown()) {
                row.child.hide();
                $tr.removeClass('shown');
            } else {

                $.ajax({
                    url: "/account/getAccountExtraInfo",
                    type: "POST",
                    dataType: "json",
                    data: {
                        accountId: accountId,
                        selectedRegion: 'us-east-1'
                    },
                    success: function (data) {
                        var data1 = eval(data);
                        row.child(data1.html).show();
                        $(this).addClass('shown');

                        load_child_table(accountId,'us-east-1');
                    },
                    error: function (data) {
                        $('#universal-title').html('<strong>绑定信息查询结果</strong>');
                        $('#universal-message').html('绑定信息查询失败。<br/>请稍后重试。');
                        $('#universal-modal').modal('show')
                        alert("您可能已退出。");
                    }
                });

            }
        }
    });

    //点击事件
    $('#table-account-info-eu-west-1')
        .on('click', ".parent-tr-eu-west-1", function () {

        if ($(this).is('.parent-tr-eu-west-1')) {
            var email = $(this).find('.email').text().trim();
            var accountId = $(this).find('.accountId').text().trim();
            if (email == 'null' || email.length == 0) {
                alert("请绑定账户邮箱");
                return
            }

            var $tr = $(this);
            var table_name1 = ('table-account-info-eu-west-1').replace(/-/g, '_');
            var row = window[table_name1].row($tr);

            if (row.child.isShown()) {
                row.child.hide();
                $tr.removeClass('shown');
            } else {

                $.ajax({
                    url: "/account/getAccountExtraInfo",
                    type: "POST",
                    dataType: "json",
                    data: {
                        accountId: accountId,
                        selectedRegion: 'eu-west-1'
                    },
                    success: function (data) {
                        var data1 = eval(data);
                        row.child(data1.html).show();
                        $(this).addClass('shown');

                        load_child_table(accountId,'eu-west-1');
                    },
                    error: function (data) {
                        $('#universal-title').html('<strong>绑定信息查询结果</strong>');
                        $('#universal-message').html('绑定信息查询失败。<br/>请稍后重试。');
                        $('#universal-modal').modal('show')
                        alert("您可能已退出。");
                    }
                });
            }
        }
    });

    //点击事件
    $('#table-account-info-ap-southeast-1')
        .on('click', ".parent-tr-ap-southeast-1", function () {

        if ($(this).is('.parent-tr-ap-southeast-1')) {
            var email = $(this).find('.email').text().trim();
            var accountId = $(this).find('.accountId').text().trim();
            if (email == 'null' || email.length == 0) {
                alert("请绑定账户邮箱");
                return
            }

            var $tr = $(this);
            var table_name1 = ('table-account-info-ap-southeast-1').replace(/-/g, '_');
            var row = window[table_name1].row($tr);

            if (row.child.isShown()) {
                row.child.hide();
                $tr.removeClass('shown');
            } else {

                $.ajax({
                    url: "/account/getAccountExtraInfo",
                    type: "POST",
                    dataType: "json",
                    data: {
                        accountId: accountId,
                        selectedRegion: 'ap-southeast-1'
                    },
                    success: function (data) {
                        var data1 = eval(data);
                        row.child(data1.html).show();
                        $(this).addClass('shown');

                        load_child_table(accountId,'ap-southeast-1');
                    },
                    error: function (data) {
                        $('#universal-title').html('<strong>绑定信息查询结果</strong>');
                        $('#universal-message').html('绑定信息查询失败。<br/>请稍后重试。');
                        $('#universal-modal').modal('show')
                        alert("您可能已退出。");
                    }
                });

            }
        }
    });

    $("#table-account-info-cn-north-1").on("click", ".edit-job-button", function (e) {
    e.stopPropagation();
    var table_name = ('table-account-info-cn-north-1').replace(/-/g, '_');
    window[table_name].$('tr.modify-tag').removeClass('modify-tag');
    $(this).parents('tr').addClass('modify-tag');
    var account_id = $(this).parents('tr').find('.accountId').text().trim();

    if (account_id == 'null' || account_id.length == 0) {
        $('#universal-title').html('<strong>无法编辑</strong>');
        $('#universal-message').html('请补充账号ID字段信息。<br/>');
        $('#universal-modal').modal('show');
        return
    }


    $.ajax({
        url: "/account/readTargetEditingAccountInfo",
        type: "POST",
        dataType: "json",
        data: {
            accountId: account_id
        },
        success: function (data) {
            $('#modify-modal-body').html(data.html);
            $('#modify-modal').modal('show')
        },
        error: function (data) {
            alert("FAILED.");
        }
    })
});
    $("#table-account-info-cn-north-1").on("click", ".delete-job-button", function (e) {
        e.stopPropagation();
        var table_name = ('table-account-info-cn-north-1').replace(/-/g, '_');
        window[table_name].$('tr.remove-tag').removeClass('remove-tag');
        $(this).parents('tr').addClass('remove-tag');
        var account_id = $(this).parents('tr').find('.accountId').text().trim();
        if (account_id == 'null' || account_id.length == 0) {
            $('#universal-title').html('<strong>无法删除</strong>');
            $('#universal-message').html('请补充账号ID字段信息。<br/>');
            $('#universal-modal').modal('show');
            return
        }
        var email = $(this).parents('tr').find('.email').text().trim();
        var username = $(this).parents('tr').find('.username').text().trim();
        var version = $(this).parents('tr').find('.version').text().trim();
        $('#accountId_d').val(account_id);
        $('#username_d').val(username);
        $('#email_d').val(email);
        $('#version_d').val(version);
        $('#delete-account-region').val('cn-north-1');
        $('#delete_job').modal('show')
    });

    $("#table-account-info-us-east-1").on("click", ".edit-job-button", function (e) {
    e.stopPropagation();
    var table_name = ('table-account-info-us-east-1').replace(/-/g, '_');
    window[table_name].$('tr.modify-tag').removeClass('modify-tag');
    $(this).parents('tr').addClass('modify-tag');
    var account_id = $(this).parents('tr').find('.accountId').text().trim();

    if (account_id == 'null' || account_id.length == 0) {
        $('#universal-title').html('<strong>无法编辑</strong>');
        $('#universal-message').html('请补充账号ID字段信息。<br/>');
        $('#universal-modal').modal('show');
        return
    }
    $('#modify-account-region').val('us-east-1');

    $.ajax({
        url: "/account/readTargetEditingAccountInfo",
        type: "POST",
        dataType: "json",
        data: {
            accountId: account_id
        },
        success: function (data) {
            $('#modify-modal-body').html(data.html);
            $('#modify-modal').modal('show')
        },
        error: function (data) {
            alert("FAILED.");
        }
    })
});
    $("#table-account-info-us-east-1").on("click", ".delete-job-button", function (e) {
        e.stopPropagation();
        var table_name = ('table-account-info-us-east-1').replace(/-/g, '_');
        window[table_name].$('tr.remove-tag').removeClass('remove-tag');
        $(this).parents('tr').addClass('remove-tag');
        var account_id = $(this).parents('tr').find('.accountId').text().trim();
        if (account_id == 'null' || account_id.length == 0) {
            $('#universal-title').html('<strong>无法删除</strong>');
            $('#universal-message').html('请补充账号ID字段信息。<br/>');
            $('#universal-modal').modal('show');
            return
        }
        var email = $(this).parents('tr').find('.email').text().trim();
        var username = $(this).parents('tr').find('.username').text().trim();
        var version = $(this).parents('tr').find('.version').text().trim();
        $('#accountId_d').val(account_id);
        $('#username_d').val(username);
        $('#email_d').val(email);
        $('#version_d').val(version);
        $('#delete-account-region').val('us-east-1');
        $('#delete_job').modal('show')
    });

    $("#table-account-info-ap-southeast-1").on("click", ".edit-job-button", function (e) {
    e.stopPropagation();
    var table_name = ('table-account-info-ap-southeast-1').replace(/-/g, '_');
    window[table_name].$('tr.modify-tag').removeClass('modify-tag');
    $(this).parents('tr').addClass('modify-tag');
    var account_id = $(this).parents('tr').find('.accountId').text().trim();

    if (account_id == 'null' || account_id.length == 0) {
        $('#universal-title').html('<strong>无法编辑</strong>');
        $('#universal-message').html('请补充账号ID字段信息。<br/>');
        $('#universal-modal').modal('show');
        return
    }

    $('#modify-account-region').val('ap-southeast-1');

    $.ajax({
        url: "/account/readTargetEditingAccountInfo",
        type: "POST",
        dataType: "json",
        data: {
            accountId: account_id
        },
        success: function (data) {
            $('#modify-modal-body').html(data.html);
            $('#modify-modal').modal('show')
        },
        error: function (data) {
            alert("FAILED.");
        }
    })
});
    $("#table-account-info-ap-southeast-1").on("click", ".delete-job-button", function (e) {
        e.stopPropagation();
        var table_name = ('table-account-info-ap-southeast-1').replace(/-/g, '_');
        window[table_name].$('tr.remove-tag').removeClass('remove-tag');
        $(this).parents('tr').addClass('remove-tag');
        var account_id = $(this).parents('tr').find('.accountId').text().trim();
        if (account_id == 'null' || account_id.length == 0) {
            $('#universal-title').html('<strong>无法删除</strong>');
            $('#universal-message').html('请补充账号ID字段信息。<br/>');
            $('#universal-modal').modal('show');
            return
        }
        var email = $(this).parents('tr').find('.email').text().trim();
        var username = $(this).parents('tr').find('.username').text().trim();
        var version = $(this).parents('tr').find('.version').text().trim();
        $('#accountId_d').val(account_id);
        $('#username_d').val(username);
        $('#email_d').val(email);
        $('#version_d').val(version);
        $('#delete-account-region').val('ap-southeast-1');
        $('#delete_job').modal('show')
    });

    $("#table-account-info-eu-west-1").on("click", ".edit-job-button", function (e) {
    e.stopPropagation();
    var table_name = ('table-account-info-eu-west-1').replace(/-/g, '_');
    window[table_name].$('tr.modify-tag').removeClass('modify-tag');
    $(this).parents('tr').addClass('modify-tag');
    var account_id = $(this).parents('tr').find('.accountId').text().trim();

    if (account_id == 'null' || account_id.length == 0) {
        $('#universal-title').html('<strong>无法编辑</strong>');
        $('#universal-message').html('请补充账号ID字段信息。<br/>');
        $('#universal-modal').modal('show');
        return
    }

    $('#modify-account-region').val('eu-west-1');

    $.ajax({
        url: "/account/readTargetEditingAccountInfo",
        type: "POST",
        dataType: "json",
        data: {
            accountId: account_id
        },
        success: function (data) {
            $('#modify-modal-body').html(data.html);
            $('#modify-modal').modal('show');
        },
        error: function (data) {
            alert("FAILED.");
        }
    })
});
    $("#table-account-info-eu-west-1").on("click", ".delete-job-button", function (e) {
        e.stopPropagation();
        var table_name = ('table-account-info-eu-west-1').replace(/-/g, '_');
        window[table_name].$('tr.remove-tag').removeClass('remove-tag');
        $(this).parents('tr').addClass('remove-tag');
        var account_id = $(this).parents('tr').find('.accountId').text().trim();
        if (account_id == 'null' || account_id.length == 0) {
            $('#universal-title').html('<strong>无法删除</strong>');
            $('#universal-message').html('请补充账号ID字段信息。<br/>');
            $('#universal-modal').modal('show');
            return
        }
        var email = $(this).parents('tr').find('.email').text().trim();
        var username = $(this).parents('tr').find('.username').text().trim();
        var version = $(this).parents('tr').find('.version').text().trim();
        $('#accountId_d').val(account_id);
        $('#username_d').val(username);
        $('#email_d').val(email);
        $('#version_d').val(version);
        $('#delete-account-region').val('eu-west-1');
        $('#delete_job').modal('show')
    });


    $('.need-hover').hover(function () {
            $(this).addClass('divOver');
        }, function () {
            $(this).removeClass('divOver');
        }
    );


});


function load_search_result() {

    var columns = columns_account;
    $.fn.dataTable.ext.errMode = function (e, settings, techNote, message) {
        console.log('An error has been reported by DataTables: ', message);

        $('#universal-title').html('<strong>云账户信息查询结果</strong>');
        $('#universal-message').html('云账户信息查询失败。<br/>请稍后重试！');
        $('#universal-modal').modal('show')
    };
    for (var region in region_list_font){

        $('#table-account-info-'+region_list_font[region]).dataTable().fnClearTable(false);
        $('#table-account-info-'+region_list_font[region]).dataTable().fnDestroy(false);
        var accountId = document.getElementById("accountId_search").value;
        var email = document.getElementById("email_search").value;
        var start_time = document.getElementById("start_time").value;
        var end_time = document.getElementById("end_time").value;
        var status = document.getElementById("status_search").value;
        if (is_global == 'False'){
            var mobile = document.getElementById("mobile_search").value;
        }else {
            var mobile = '';
        }


        var table_name = ('table-account-info-'+region_list_font[region]).replace(/-/g, '_');
        window[table_name] = $('#table-account-info-'+ region_list_font[region]).DataTable({
            "lengthChange": true,
            "autoWidth": false,
            "processing": false,
            "paging": true,
            "searching": false,
            "ordering": false,
            "Info": true,
            "serverSide": true,
            "stripeClasses": ['odd parent-tr-' + region_list_font[region], 'even  parent-tr-' + region_list_font[region]],

            "lengthMenu": [[8, 15, 30, 50, 100], [8, 15, 30, 50, 100]],
            "order": [[0, 'asc']],
            "oLanguage": {
                "oAria": {
                    "sSortAscending": " - click/return to sort ascending",
                    "sSortDescending": " - click/return to sort descending"
                },
                "sLengthMenu": "显示 _MENU_ 记录",
                "sZeroRecords": "查询结果中无相关数据",
                "sEmptyTable": "未有相关数据",
                "sLoadingRecords": "正在加载数据-请等待...",
                "sInfo": "当前显示 _START_ 到 _END_ 条，共 _TOTAL_ 条记录。",
                "sInfoEmpty": "当前显示0到0条，共0条记录",
                "sInfoFiltered": "（数据库中共有 _MAX_ 条记录）",
                "sProcessing": "正在加载数据...",
                "sSearch": "搜索：",
                "sUrl": "",
                "oPaginate": {
                    "sFirst": "首页",
                    "sPrevious": " 上一页 ",
                    "sNext": " 下一页 ",
                    "sLast": " 尾页 "
                }
            },

            "ajax": {
                url: "/account/readAccountInfo",
                type: "POST",
                dataType: "json",
                data: {
                    accountId: accountId,
                    email: email,
                    mobile:mobile,
                    startTime: start_time,
                    endTime: end_time,
                    status: status
                },

            },
            "columns": columns,
            "createdRow": function (row, data, index) {
                if (data['authority'] == 'no permission'){
                    alert('NO PERMISSION')
                    return;
                }

                var status_normal = '<span style="width:60px" class="label label-sm label-success">NORMAL</span>';
                var status_inactivate = '<span style="width:70px" class="label label-sm label-unknown">INACTIVATE</span>';
                var status_locked = '<span style="width:60px" class="label label-sm label-warning">LOCKED</span>';
                var status_unknown = '<span style="width:64px" class="label label-sm ">UNKNOWN</span>';
                if (data['status'] == 'NORMAL') {
                    $('td', row).eq(3).html(status_normal);
                } else if (data['status'] == 'INACTIVATE') {
                    $('td', row).eq(3).html(status_inactivate);
                } else if (data['status'] == 'LOCKED') {
                    $('td', row).eq(3).html(status_locked);
                } else {
                    $('td', row).eq(3).html(status_unknown);
                }
                var registerDate_Long = data['registerDate'];
                if (registerDate_Long != null && registerDate_Long != '-') {
                    var registerDate_Date = new Date(registerDate_Long).format('yyyy-MM-dd  h:m:s')
                    $('td', row).eq(4).html(registerDate_Date);
                }
                var lockEndDate_Long = data['lockEndDate'];
                if (lockEndDate_Long != null && lockEndDate_Long != '-') {
                    var lockEndDate_Date = new Date(lockEndDate_Long).format('yyyy-MM-dd  h:m:s')
                    $('td', row).eq(5).html(lockEndDate_Date);
                }
            },
            "fnInitComplete": function () {

            }
        })
    }

}

function add_service_account() {
    var email = $('#email_a').val()
    if (email == "" || email == null) {
        $("#build_error_email_e").css("display", "block")
        setTimeout(function () {
            $("#build_error_email_e").css("display", "none");
        }, 2000);
        return;
    }

    var password = $('#password_a').val()
    if (password == "" || password == null) {
        $("#build_error_password_e").css("display", "block")
        setTimeout(function () {
            $("#build_error_password_e").css("display", "none");
        }, 2000);
        return;
    }
    var registerDate = $("#registerDate_a").val().trim()
    var status = $("#status_a").val().trim()
    var username = $('#username_a').val().trim();
    var lockEndDate = $('#lockEndDate_a').val().trim();

    $.ajax({
        url: "/account/addAccountInfo",
        type: "POST",
        dataType: "json",
        data: {
            email: email,
            password: password,
            username: username,
            status: status,
            registerDate: registerDate,
            lockEndDate: lockEndDate,
        },
        success: function (data) {
            var data1 = eval(data)
            $('#universal-title').html('<strong>添加账户信息</strong>')

            if (data1.result == 'true') {
                $('#universal-message').html("添加账户信息成功");
            } else {
                $('#universal-message').html("添加账户信息失败");
            }
            $('#add_account').modal('hide');
            $('#universal-modal').modal('show');
            var table_name1 = 'table-account-info'.replace(/-/g, '_');
            window[table_name1].ajax.reload();
        },
        error: function (data) {
            console.log("请登录")
            alert("请登录");
        }
    })
}

function modify_service_account() {
    var email = $("#email_m").val().trim();
    var registerDate = $("#registerDate_m").val().trim();
    var status = $("#status_m").val().trim();
    var accountId = $('#accountId_m').val().trim();
    var lockEndDate = $('#lockEndDate_m').val().trim();

    var selectedRegion = $('#modify-account-region').val();

    if (is_global == 'True') {
        var username = $('#username_m').val().trim();
        var nickName = $('#nickName_m').val().trim();
        var sex = $('#sex_m').val().trim();
        var birthday = $('#birthday_m').val().trim();
        var avatarFileId = $('#avatarFileId_m').val().trim();
        var avatarUrl = $('#avatarUrl_m').val().trim();

        var data_post = {
            email: email,
            username: username,
            status: status,
            accountId: accountId,
            registerDate: registerDate,
            lockEndDate: lockEndDate,

            nickName: nickName,
            birthday: birthday,
            sex: sex,
            avatarFileId: avatarFileId,
            avatarUrl: avatarUrl
        }
    } else {
        var mobile = $('#mobile_m').val().trim();
        var data_post = {
            email: email,
            status: status,
            accountId: accountId,
            registerDate: registerDate,
            lockEndDate: lockEndDate,
            mobile: mobile
        }
    }
    $.ajax({
        url: "/account/modifyAccountInfo",
        type: "POST",
        dataType: "json",
        data: data_post,
        success: function (data) {
            var data1 = eval(data);
            $('#universal-title').html('<strong>修改账户信息</strong>');

            if (data1.result == 'true') {
                $('#universal-message').html("修改账户信息成功");
            } else {
                $('#universal-message').html("修改账户信息失败");
            }
            $('#modify-modal').modal('hide');
            $('#universal-modal').modal('show');
            if (data1.result == 'true') {
                //job_name = 'scan-' + service_region + '-cloud-' + service_name
                var status_normal = '<span style="width:56px" class="label label-sm label-success">NORMAL</span>';
                var status_inactivate = '<span style="width:70px" class="label label-sm label-unknown">INACTIVATE</span>';
                var status_locked = '<span style="width:56px" class="label label-sm label-warning">LOCKED</span>';
                var status_after_m = '';
                if (status == 'NORMAL') {
                    status_after_m = status_normal
                } else if (status == 'INACTIVATE') {
                    status_after_m = status_inactivate
                } else {
                    status_after_m = status_locked
                }
                $('#table-account-info-'+ selectedRegion).find('.modify-tag').find('.email').html(email);
                $('#table-account-info-'+ selectedRegion).find('.modify-tag').find('.username').html(username);
                $('#table-account-info-'+ selectedRegion).find('.modify-tag').find('.registerDate').html(registerDate);
                $('#table-account-info-'+ selectedRegion).find('.modify-tag').find('.status').html(status_after_m);
                $('#table-account-info-'+ selectedRegion).find('.modify-tag').find('.lockEndDate').html(lockEndDate)
                // $('#table-account-info-'+ selectedRegion).find('.modify-tag').find('.lockEndDate').html(parseInt(version) + 1)
                for (var region in region_list_font){
                    if (region_list_font[region] != selectedRegion){
                        var table_name2 = ('table-account-info-'+ region_list_font[region]).replace(/-/g, '_');
                        window[table_name2].ajax.reload();
                    }
                }
            }
        },
        error: function (data) {
            alert("请登录");
        }
    })
}


$('#start_time').datepicker({
    format: "yyyy-mm-dd",
    autoclose: true
});

$('#end_time').datepicker({
    format: "yyyy-mm-dd",
    autoclose: true
});

$('#registerDate_a').datepicker({
    format: "yyyy-mm-dd",
    autoclose: true
});

function delete_alarming_job() {
    $('#delete_job').modal('hide');
    $('#delete_service_job').modal('show')
}

function delete_service_job() {
    var accountId = $('#accountId_d').val()
    var selectedRegion = $('#delete-account-region').val()
    $.ajax({
        url: "/account/delAccountInfo",
        type: "POST",
        dataType: "json",
        data: {
            accountId: accountId
        },
        success: function (data) {
            $('#delete_service_job').modal('hide');
            var data1 = eval(data)

            if (data1.result == 'true') {
                $('#universal-message').html("删除账户成功");
            } else {
                $('#universal-message').html("删除账户失败");
            }
            $('#universal-title').html('<strong>删除结果</strong>');
            $('#universal-modal').modal('show')
            if (data1.result == 'true') {
                var table_name1 = ('table-account-info-'+ selectedRegion).replace(/-/g, '_');
                window[table_name1].row('.remove-tag').remove().draw(false);
                for (var region in region_list_font){
                    if (region_list_font[region] != selectedRegion){
                        var table_name2 = ('table-account-info-'+ region_list_font[region]).replace(/-/g, '_');
                        window[table_name2].ajax.reload();
                    }
                }
            }
        },
        error: function (data) {
            alert("请登录");
        }
    })
}

function show_value_detail(field_value){
    // var reg = new RegExp("(\.\d+\.[a-zA-Z])","g");
    // var value = field_value.replace(reg,"([.][\n]\d+[.][a-zA-Z])")
    $('#universal-title').html('<strong>详情</strong>');
    $('#universal-message').html(field_value);
    $('#universal-modal').modal('show');
}

function load_child_table(accountId,region) {

    var columns = columns_device;

    $.fn.dataTable.ext.errMode = function (e, settings, techNote, message) {
        console.log('An error has been reported by DataTables: ', message);
        $('#universal-title').html('<strong>绑定设备信息查询结果</strong>');
        $('#universal-message').html('绑定设备信息查询失败。<br/>请稍后重试或请重新登录！');
        $('#universal-modal').modal('show')
    };
    $('#device-list-info').dataTable().fnClearTable(false);
    $('#device-list-info').dataTable().fnDestroy();

    var table_name = 'device-list-info'.replace(/-/g, '_');

    window[table_name] = $('#device-list-info').DataTable({
        "lengthChange": false,
        "autoWidth": true,
        "processing": false,
        "paging": true,
        "searching": false,
        "ordering": true,
        "Info": false,

        "lengthMenu": [[6, 15, 50, 100], [6, 15, 50, 100]],
        "order": [[0, 'asc']],
        "oLanguage": {
            "oAria": {
                "sSortAscending": " - click/return to sort ascending",
                "sSortDescending": " - click/return to sort descending"
            },
            "sLengthMenu": "显示 _MENU_ 记录",
            "sZeroRecords": "对不起，查询结果中无相关数据",
            "sEmptyTable": "该账户未绑定设备",
            "sLoadingRecords": "正在加载数据-请等待...",
            "sInfo": "共 _TOTAL_ 条关联设备记录",
            "sInfoEmpty": "共0条绑定设备记录",
            "sInfoFiltered": "（数据库中共为 _MAX_ 条记录）",
            "sProcessing": "正在加载数据...",
            "sSearch": "搜索：",
            "sUrl": "",
            "oPaginate": {
                "sFirst": "首页",
                "sPrevious": " 上一页 ",
                "sNext": " 下一页 ",
                "sLast": " 尾页 "
            }
        },

        "ajax": {
            url: "/account/readDeviceInfo",
            type: "POST",
            dataType: "json",
            data: {
                accountId: accountId,
                selectedRegion:region
            },

        },
        "columns": columns,
        "createdRow": function (row, data, index) {
            var status_online = '<span style="width:56px" class="label label-sm label-success">在线</span>';
            var status_offline = '<span style="width:56px" class="label label-sm label-warning">离线</span>';
            var status_unknown = '<span style="width:56px" class="label label-sm ">未知</span>';
            if (data['online'] == 'N') {
                $('td', row).eq(2).html(status_offline);
            } else if (data['online'] == 'Y') {
                $('td', row).eq(2).html(status_online);
            } else {

                $('td', row).eq(2).html(status_unknown);

            }
        },

        "fnInitComplete": function () {
            var timestamp = new Date().getTime();
            var child_table_name = 'child-table-' + timestamp + region;
            $("#device-list-info").attr('id', child_table_name);
            $("#" + child_table_name).on("click", ".detail-device-button", function (e) {
                var deviceId = $(this).closest('tr').find('.deviceId').text().trim();
                if (deviceId == 'null' || deviceId.length == 0) {
                    return
                }
                $.ajax({
                    url: "/device/getDeviceExtraInfo",
                    type: "POST",
                    dataType: "json",
                    data: {
                        deviceId: deviceId,
                        mac: "",
                        selectedRegion: region
                    },
                    success: function (data) {
                        $('#device-detail-info-modal').html(data.html);
                        $('#device-detail-info-modal').modal('show')
                    },
                    error: function (data) {
                        alert("FAILED.");
                    }
                })
            });
        }
    })
}



Date.prototype.format = function (format) {
    var date = {
        "M+": this.getMonth() + 1,
        "d+": this.getDate(),
        "h+": this.getHours()+8,
        "m+": this.getMinutes(),
        "s+": this.getSeconds(),
        "q+": Math.floor((this.getMonth() + 3) / 3),
        "S+": this.getMilliseconds()
    };
    if (/(y+)/i.test(format)) {
        format = format.replace(RegExp.$1, (this.getFullYear() + '').substr(4 - RegExp.$1.length));
    }
    for (var k in date) {
        if (new RegExp("(" + k + ")").test(format)) {
            format = format.replace(RegExp.$1, RegExp.$1.length == 2 ? date[k] : ("00" + date[k]).substr(("" + date[k]).length));
        }
    }
    return format;
}

