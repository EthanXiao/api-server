/**
 * Created by yuzhijiang on 2017/11/8.
 */



$(document).ready(function () {

    load_search_result();

    $("#table-device-info-cn-north-1").on("click", ".edit-job-button", function (e) {
        e.stopPropagation();
        var table_name = ('table-device-info-cn-north-1').replace(/-/g, '_');
        window[table_name].$('tr.modify-tag').removeClass('modify-tag');
        $(this).parents('tr').addClass('modify-tag');

        var device_id = $(this).parents('tr').find('.deviceId').text().trim();

        if (device_id == 'null' || device_id.length == 0) {
            $('#universal-title').html('<strong>无法编辑</strong>');
            $('#universal-message').html('请补充设备ID字段信息。<br/>');
            $('#universal-modal').modal('show');
            return
        }

        $('#modify-device-region').val('cn-north-1');

        $.ajax({
            url: "/device/readTargetEditingDeviceInfo",
            type: "POST",
            dataType: "json",
            data: {
                deviceId: device_id,
                selectedRegion: 'cn-north-1'
            },
            success: function (data) {
                $('#modify-modal-body').html(data.html);
                $('#modify-modal').modal('show')
            },
            error: function (data) {
                alert("FAILED.");
            }
        })
    });
    $("#table-device-info-cn-north-1").on("click", ".delete-job-button", function (e) {
        e.stopPropagation()
        var table_name = ('table-device-info-cn-north-1').replace(/-/g, '_');
        window[table_name].$('tr.remove-tag').removeClass('remove-tag');
        $(this).parents('tr').addClass('remove-tag');
        var device_id = $(this).parents('tr').find('.deviceId').text().trim();
        var mac = $(this).parents('tr').find('.mac').text().trim();
        var fw_ver = $(this).parents('tr').find('.fwVer').text().trim();
        var online = $(this).parents('tr').find('.online').text().trim();
        $('#deviceId_d').val(device_id);
        $('#mac_d').val(mac);
        $('#fwVer_d').val(fw_ver);
        $('#online_d').val(online);
        $('#delete-device-region').val('cn-north-1');
        $('#delete_job').modal('show')
    });

    $("#table-device-info-us-east-1").on("click", ".edit-job-button", function (e) {
        e.stopPropagation();
        var table_name = ('table-device-info-us-east-1').replace(/-/g, '_');
        window[table_name].$('tr.modify-tag').removeClass('modify-tag');
        $(this).parents('tr').addClass('modify-tag');

        var device_id = $(this).parents('tr').find('.deviceId').text().trim();

        if (device_id == 'null' || device_id.length == 0) {
            $('#universal-title').html('<strong>无法编辑</strong>');
            $('#universal-message').html('请补充设备ID字段信息。<br/>');
            $('#universal-modal').modal('show');
            return
        }
        $('#modify-device-region').val('us-east-1');

        $.ajax({
            url: "/device/readTargetEditingDeviceInfo",
            type: "POST",
            dataType: "json",
            data: {
                deviceId: device_id,
                selectedRegion: 'us-east-1'
            },
            success: function (data) {
                $('#modify-modal-body').html(data.html);
                $('#modify-modal').modal('show')
            },
            error: function (data) {
                alert("FAILED.");
            }
        })
    });
    $("#table-device-info-us-east-1").on("click", ".delete-job-button", function (e) {
        e.stopPropagation()
        var table_name = ('table-device-info-us-east-1').replace(/-/g, '_');
        window[table_name].$('tr.remove-tag').removeClass('remove-tag');
        $(this).parents('tr').addClass('remove-tag');
        var device_id = $(this).parents('tr').find('.deviceId').text().trim();
        var mac = $(this).parents('tr').find('.mac').text().trim();
        var fw_ver = $(this).parents('tr').find('.fwVer').text().trim();
        var online = $(this).parents('tr').find('.online').text().trim();
        $('#deviceId_d').val(device_id);
        $('#mac_d').val(mac);
        $('#fwVer_d').val(fw_ver);
        $('#online_d').val(online);
        $('#delete-device-region').val('us-east-1');
        $('#delete_job').modal('show')
    });

    $("#table-device-info-eu-west-1").on("click", ".edit-job-button", function (e) {
        e.stopPropagation();
        var table_name = ('table-device-info-eu-west-1').replace(/-/g, '_');
        window[table_name].$('tr.modify-tag').removeClass('modify-tag');
        $(this).parents('tr').addClass('modify-tag');

        var device_id = $(this).parents('tr').find('.deviceId').text().trim();

        if (device_id == 'null' || device_id.length == 0) {
            $('#universal-title').html('<strong>无法编辑</strong>');
            $('#universal-message').html('请补充设备ID字段信息。<br/>');
            $('#universal-modal').modal('show');
            return
        }

        $('#modify-device-region').val('eu-west-1');

        $.ajax({
            url: "/device/readTargetEditingDeviceInfo",
            type: "POST",
            dataType: "json",
            data: {
                deviceId: device_id,
                selectedRegion: 'eu-west-1'
            },
            success: function (data) {
                $('#modify-modal-body').html(data.html);
                $('#modify-modal').modal('show')
            },
            error: function (data) {
                alert("FAILED.");
            }
        })
    });
    $("#table-device-info-eu-west-1").on("click", ".delete-job-button", function (e) {
        e.stopPropagation()
        var table_name = ('table-device-info-eu-west-1').replace(/-/g, '_');
        window[table_name].$('tr.remove-tag').removeClass('remove-tag');
        $(this).parents('tr').addClass('remove-tag');
        var device_id = $(this).parents('tr').find('.deviceId').text().trim();
        var mac = $(this).parents('tr').find('.mac').text().trim();
        var fw_ver = $(this).parents('tr').find('.fwVer').text().trim();
        var online = $(this).parents('tr').find('.online').text().trim();
        $('#deviceId_d').val(device_id);
        $('#mac_d').val(mac);
        $('#fwVer_d').val(fw_ver);
        $('#online_d').val(online);
        $('#delete-device-region').val('eu-west-1');
        $('#delete_job').modal('show')
    });

    $("#table-device-info-ap-southeast-1").on("click", ".edit-job-button", function (e) {
        e.stopPropagation();
        var table_name = ('table-device-info-ap-southeast-1').replace(/-/g, '_');
        window[table_name].$('tr.modify-tag').removeClass('modify-tag');
        $(this).parents('tr').addClass('modify-tag');

        var device_id = $(this).parents('tr').find('.deviceId').text().trim();

        if (device_id == 'null' || device_id.length == 0) {
            $('#universal-title').html('<strong>无法编辑</strong>');
            $('#universal-message').html('请补充设备ID字段信息。<br/>');
            $('#universal-modal').modal('show');
            return
        }

        $('#modify-device-region').val('ap-southeast-1');

        $.ajax({
            url: "/device/readTargetEditingDeviceInfo",
            type: "POST",
            dataType: "json",
            data: {
                deviceId: device_id,
                selectedRegion: 'ap-southeast-1'
            },
            success: function (data) {
                $('#modify-modal-body').html(data.html);
                $('#modify-modal').modal('show')
            },
            error: function (data) {
                alert("FAILED.");
            }
        })
    });
    $("#table-device-info-ap-southeast-1").on("click", ".delete-job-button", function (e) {
        e.stopPropagation()
        var table_name = ('table-device-info-ap-southeast-1').replace(/-/g, '_');
        window[table_name].$('tr.remove-tag').removeClass('remove-tag');
        $(this).parents('tr').addClass('remove-tag');
        var device_id = $(this).parents('tr').find('.deviceId').text().trim();
        var mac = $(this).parents('tr').find('.mac').text().trim();
        var fw_ver = $(this).parents('tr').find('.fwVer').text().trim();
        var online = $(this).parents('tr').find('.online').text().trim();
        $('#deviceId_d').val(device_id);
        $('#mac_d').val(mac);
        $('#fwVer_d').val(fw_ver);
        $('#online_d').val(online);
        $('#delete-device-region').val('ap-southeast-1');
        $('#delete_job').modal('show')
    });



    $('.need-hover').hover(function () {
            $(this).addClass('divOver');
        }, function () {
            $(this).removeClass('divOver');
        }
    );

    //点击事件
    $('#table-device-info-cn-north-1').on('click', ".parent-tr-cn-north-1", function () {
        if ($(this).is('.parent-tr-cn-north-1')) {
            var deviceId = $(this).find('.deviceId').text().trim();
            if (deviceId == 'null' || deviceId.length == 0) {
                return
            }
            var $tr = $(this);
            var table_name1 = ('table-device-info-cn-north-1').replace(/-/g, '_');

            var row = window[table_name1].row($tr);

            if (row.child.isShown()) {
                row.child.hide();
                $tr.removeClass('shown');
            } else {
                $.ajax({
                    url: "/device/getDeviceExtraInfo",
                    type: "POST",
                    dataType: "json",
                    data: {
                        deviceId: deviceId,
                        selectedRegion:'cn-north-1'
                    },
                    success: function (data) {
                        var data1 = eval(data);
                        // {#                                        row.child(format(data1)).show();#}
                        row.child(data1.html).show();
                        $tr.addClass('shown');
                    },
                    error: function (data) {
                        alert("FAILED.");
                    }
                })
            }
        }
    });

    //点击事件
    $('#table-device-info-us-east-1').on('click', ".parent-tr-us-east-1", function () {
        if ($(this).is('.parent-tr-us-east-1')) {
            var deviceId = $(this).find('.deviceId').text().trim();
            if (deviceId == 'null' || deviceId.length == 0) {
                return
            }
            var $tr = $(this);
            var table_name1 = ('table-device-info-us-east-1').replace(/-/g, '_');

            var row = window[table_name1].row($tr);

            if (row.child.isShown()) {
                row.child.hide();
                $tr.removeClass('shown');
            } else {
                $.ajax({
                    url: "/device/getDeviceExtraInfo",
                    type: "POST",
                    dataType: "json",
                    data: {
                        deviceId: deviceId,
                        selectedRegion:'us-east-1'
                    },
                    success: function (data) {
                        var data1 = eval(data);
                        // {#                                        row.child(format(data1)).show();#}
                        row.child(data1.html).show();
                        $tr.addClass('shown');
                    },
                    error: function (data) {
                        alert("FAILED.");
                    }
                })
            }
        }
    });

    //点击事件
    $('#table-device-info-eu-west-1').on('click', ".parent-tr-eu-west-1", function () {
        if ($(this).is('.parent-tr-eu-west-1')) {
            var deviceId = $(this).find('.deviceId').text().trim();
            if (deviceId == 'null' || deviceId.length == 0) {
                return
            }
            var $tr = $(this);
            var table_name1 = ('table-device-info-eu-west-1').replace(/-/g, '_');

            var row = window[table_name1].row($tr);

            if (row.child.isShown()) {
                row.child.hide();
                $tr.removeClass('shown');
            } else {
                $.ajax({
                    url: "/device/getDeviceExtraInfo",
                    type: "POST",
                    dataType: "json",
                    data: {
                        deviceId: deviceId,
                        selectedRegion:'eu-west-1'
                    },
                    success: function (data) {
                        var data1 = eval(data);
                        // {#                                        row.child(format(data1)).show();#}
                        row.child(data1.html).show();
                        $tr.addClass('shown');
                    },
                    error: function (data) {
                        alert("FAILED.");
                    }
                })
            }
        }
    });

    //点击事件
    $('#table-device-info-ap-southeast-1').on('click', ".parent-tr-ap-southeast-1", function () {
        if ($(this).is('.parent-tr-ap-southeast-1')) {
            var deviceId = $(this).find('.deviceId').text().trim();
            if (deviceId == 'null' || deviceId.length == 0) {
                return
            }
            var $tr = $(this);
            var table_name1 = ('table-device-info-ap-southeast-1').replace(/-/g, '_');

            var row = window[table_name1].row($tr);

            if (row.child.isShown()) {
                row.child.hide();
                $tr.removeClass('shown');
            } else {
                $.ajax({
                    url: "/device/getDeviceExtraInfo",
                    type: "POST",
                    dataType: "json",
                    data: {
                        deviceId: deviceId,
                        selectedRegion:'ap-southeast-1'
                    },
                    success: function (data) {
                        var data1 = eval(data);
                        // {#                                        row.child(format(data1)).show();#}
                        row.child(data1.html).show();
                        $tr.addClass('shown');
                    },
                    error: function (data) {
                        alert("FAILED.");
                    }
                })
            }
        }
    });
});

function load_search_result() {
    var columns = columns_device

    $.fn.dataTable.ext.errMode = 'none';

    for (var region in region_list_font){
        $('#table-device-info-'+ region_list_font[region]).dataTable().fnClearTable(false);
        $('#table-device-info-'+ region_list_font[region]).dataTable().fnDestroy();

        var deviceId = document.getElementById("deviceId_search").value;
        var accountId = document.getElementById("accountId_search").value;
        var mac = document.getElementById("mac_search").value;

        var table_name = ('table-device-info-'+ region_list_font[region]).replace(/-/g, '_');

        window[table_name] = $('#table-device-info-'+ region_list_font[region]).on('error.dt', function (e, settings, techNote, message) {
            console.log('An error has been reported by DataTables: ', message);
            $('#universal-title').html('<strong>云设备信息查询结果</strong>');
            $('#universal-message').html('云设备信息查询失败。<br/>请稍后重试或请登录！');
            $('#universal-modal').modal('show')
        }).DataTable({
            "lengthChange": true,
            "autoWidth": false,
            "processing": false,
            "paging": true,
            "searching": false,
            "ordering": true,
            "Info": true,
            "stripeClasses": ['odd parent-tr-' + region_list_font[region], 'even  parent-tr-' + region_list_font[region]],
            "lengthMenu": [[15, 50, 100], [15, 50, 100]],
            "order": [[0, 'asc']],
            "oLanguage": {
                "oAria": {
                    "sSortAscending": " - click/return to sort ascending",
                    "sSortDescending": " - click/return to sort descending"
                },
                "sLengthMenu": "显示 _MENU_ 记录",
                "sZeroRecords": "对不起，查询结果中无相关数据",
                "sEmptyTable": "未有相关数据，请重新输入查询条件",
                "sLoadingRecords": "正在加载数据-请等待...",
                "sInfo": "当前显示 _START_ 到 _END_ 条，共 _TOTAL_ 条记录。",
                "sInfoEmpty": "当前显示0到0条，共0条记录",
                "sInfoFiltered": "（数据库中共有 _MAX_ 条记录）",
                "sProcessing": "正在加载数据...",
                "sSearch": "搜索：",
                "sUrl": "",
                "oPaginate": {
                    "sFirst": "首页",
                    "sPrevious": " 上一页 ",
                    "sNext": " 下一页 ",
                    "sLast": " 尾页 "
                }
            },

            "ajax": {
                url: "/device/readDeviceInfo",
                type: "POST",
                dataType: "json",
                data: {
                    deviceId: deviceId,
                    accountId: accountId,
                    mac: mac,
                    selectedRegion: region_list_font[region]
                },

            },
            "columns": columns,
            "createdRow": function (row, data, index) {
                var status_online = '<span style="width:56px" class="label label-sm label-success">在线</span>';
                var status_offline = '<span style="width:56px" class="label label-sm label-warning">离线</span>';
                var status_null = '<span style="width:56px" class="label label-sm ">未知</span>';
                if (data['online'] == 'N') {
                    $('td', row).eq(2).html(status_offline);
                } else if (data['online'] == 'Y') {
                    $('td', row).eq(2).html(status_online);
                } else {
                    $('td', row).eq(2).html(status_null);
                }
            },
            "fnInitComplete":function (object) {
                if (object.json.data.length != 0){
                    if(object.json.data[0]['region'] == 'ap-southeast-1'){
                    $('#tab-us-east-1').removeClass('active');
                    $('#device-us-east-1').removeClass('in active');
                    $('#tab-ap-southeast-1').addClass('active');
                    $('#device-ap-southeast-1').addClass('in active');
                }
                if(object.json.data[0]['region'] == 'eu-west-1'){
                    $('#tab-us-east-1').removeClass('active');
                    $('#device-us-east-1').removeClass('in active');
                    $('#tab-eu-west-1').addClass('active');
                    $('#device-eu-west-1').addClass('in active');
                }
                }
            }

        })
    }

}

function add_service_device() {
    var email = $('#email_a').val();
    if (email == "" || email == null) {
        $("#build_error_email_e").css("display", "block");
        setTimeout(function () {
            $("#build_error_email_e").css("display", "none");
        }, 2000);
        return;
    }

    var password = $('#password_a').val()
    if (password == "" || password == null) {
        $("#build_error_password_e").css("display", "block")
        setTimeout(function () {
            $("#build_error_password_e").css("display", "none");
        }, 2000);
        return;
    }
    var registerDate = ($("#registerDate_a").val().trim())
    var status = $("#status_a").val().trim()
    var username = $('#username_a').val().trim();
    var mobile = $('#mobile_a').val().trim();
    var lockEndDate = $('#lockEndDate_a').val().trim();
    var password = $('#password_a').val().trim();
    $.ajax({
        url: "/device/addDeviceInfo",
        type: "POST",
        dataType: "json",
        data: {
            email: email,
            password: password,
            username: username,
            mobile: mobile,
            status: status,
            registerDate: registerDate,
            lockEndDate: lockEndDate,
        },
        success: function (data) {
            var data1 = eval(data);
            $('#universal-title').html('<strong>添加设备信息</strong>');
            if (data1.result == 'true') {
                $('#universal-message').html("添加设备信息成功");
            } else {
                $('#universal-message').html("添加设备信息失败");
            }
            $('#add_device').modal('hide');
            $('#universal-modal').modal('show');
            var table_name1 = 'table-device-info'.replace(/-/g, '_');
            window[table_name1].ajax.reload();

        },
        error: function (data) {
            console.log("请登录");
            alert("请登录");
        }
    })
}

function modify_service_device() {

    var device_id = $("#deviceId_m").val().trim();
    var region = $("#region_m").val().trim();
    var hw_id = $('#hwId_m').val().trim();
    var hw_ver = $("#hwVer_m").val().trim();
    var hw_type = $("#hwType_m").val().trim();
    var fw_id = $('#fwId_m').val().trim();
    var fw_ver = $('#fwVer_m').val().trim();

    var mac = $('#mac_m').val().trim();
    var account_id = $('#accountId_m').val().trim();
    var alias = $('#alias_m').val().trim();
    var device_name = $('#deviceName_m').val().trim();
    var category_name = $("#categoryName_m").val().trim();
    var model_id = $('#modelId_m').val().trim();
    var selectedRegion = $('#modify-device-region').val();

    if (is_global == 'True'){
        var oem_id = $('#oemId_m').val().trim();
        var post_data = {
            deviceId: device_id,
            region: region,
            fwVer: fw_ver,
            hwVer: hw_ver,
            hwId: hw_id,
            oemId: oem_id,
            mac: mac,
            accountId: account_id,
            deviceName:device_name,
            alias:alias,
            categoryName:category_name,
            modelId:model_id,
            fwId:fw_id,
            hwType:hw_type,
            selectedRegion:selectedRegion
        }
    } else {
        var post_data = {
            deviceId: device_id,
            region: region,
            fwVer: fw_ver,
            hwVer: hw_ver,
            hwId: hw_id,
            mac: mac,
            accountId: account_id,
            deviceName:device_name,
            alias:alias,
            categoryName:category_name,
            modelId:model_id,
            fwId:fw_id,
            hwType:hw_type,
            selectedRegion:selectedRegion
        }
    }
    $.ajax({
        url: "/device/modifyDeviceInfo",
        type: "POST",
        dataType: "json",
        data: post_data,
        success: function (data) {
            var data1 = eval(data);
            $('#universal-title').html('<strong>修改设备信息</strong>');

            if (data1.result == 'true') {
                $('#universal-message').html("修改设备信息成功");
            } else {
                $('#universal-message').html("修改设备信息失败");
            }
            $('#modify-modal').modal('hide');
            $('#universal-modal').modal('show');
            if (data1.result == 'true') {
                $('#table-device-info-'+ selectedRegion).find('.modify-tag').find('.deviceId').html(device_id);
                $('#table-device-info-'+ selectedRegion).find('.modify-tag').find('.region').html(region);
                $('#table-device-info-'+ selectedRegion).find('.modify-tag').find('.fwVer').html(fw_ver);
                $('#table-device-info-'+ selectedRegion).find('.modify-tag').find('.hwId').html(hw_id);
                $('#table-device-info-'+ selectedRegion).find('.modify-tag').find('.oemId').html(oem_id);
                $('#table-device-info-'+ selectedRegion).find('.modify-tag').find('.mac').html(mac);
                $('#table-device-info-'+ selectedRegion).find('.modify-tag').find('.accountId').html(account_id)

                for (var region_index in region_list_font){
                    if (region_list_font[region_index] != selectedRegion){
                        var table_name2 = ('table-device-info-'+ region_list_font[region_index]).replace(/-/g, '_');
                        window[table_name2].ajax.reload();
                    }
                }
            }


        },
        error: function (data) {
            alert("请登录");
        }
    })
}

function delete_service_job() {
    var deviceId = $('#deviceId_d').val();
    var selectedRegion = $('#delete-device-region').val()
    $.ajax({
        url: "/device/delDeviceInfo",
        type: "POST",
        dataType: "json",
        data: {
            deviceId: deviceId,
            selectedRegion: selectedRegion
        },
        success: function (data) {
            $('#delete_job').modal('hide')
            var data1 = eval(data)

            if (data1.result == 'true') {
                $('#universal-message').html("删除设备成功");
            } else {
                $('#universal-message').html("删除设备失败");
            }
            $('#universal-title').html('<strong>删除结果</strong>')
            $('#universal-modal').modal('show')
            if (data1.result == 'true') {
                var table_name = ('table-device-info-'+selectedRegion).replace(/-/g, '_');
                window[table_name].row('.remove-tag').remove().draw(false)
                for (var region in region_list_font) {
                    if (region_list_font[region] != selectedRegion) {
                        var table_name2 = ('table-device-info-' + region_list_font[region]).replace(/-/g, '_');
                        window[table_name2].ajax.reload();
                    }
                }
            }
        },
        error: function (data) {
            alert("请登录");
        }
    })
}
