/**
 * Created by yuzhijiang on 2017/11/8.
 */


$(document).ready(function () {
    load_search_result();
    $("#parent-table-info").on("click", ".edit-job-button", function (e) {
        e.stopPropagation();
        var table_name = 'parent-table-info'.replace(/-/g, '_');
        window[table_name].$('tr.modify-tag').removeClass('modify-tag');
        $(this).parents('tr').addClass('modify-tag');
        var device_id = $(this).parents('tr').find('.deviceId').text().trim();

        if (device_id == 'null' || device_id.length == 0) {
            $('#universal-title').html('<strong>无法编辑</strong>');
            $('#universal-message').html('请补充设备ID字段信息。<br/>');
            $('#universal-modal').modal('show')
            return
        }

        var model_id = $(this).parents('tr').find('.modelId').text().trim();

        if (model_id == 'null' || model_id.length == 0) {
            $('#universal-title').html('<strong>无法编辑</strong>');
            $('#universal-message').html('缺失型号ID字段信息，无法编辑。<br/>');
            $('#universal-modal').modal('show')
            return
        }
        $.ajax({
            url: "/factorydata/readTargetEditingFactoryDataInfo",
            type: "POST",
            dataType: "json",
            data: {
                deviceId: device_id
            },
            success: function (data) {
                $('#modify-modal-body').html(data.html);
                $('#modify-modal').modal('show')
            },
            error: function (data) {
                alert("FAILED.");
            }
        })
    });

    $("#parent-table-info").on("click", ".delete-job-button", function (e) {
        e.stopPropagation()
        var table_name = 'parent-table-info'.replace(/-/g, '_');
        window[table_name].$('tr.remove-tag').removeClass('remove-tag');
        $(this).parents('tr').addClass('remove-tag');
        var device_id = $(this).parents('tr').find('.deviceId').text().trim();
        var mac = $(this).parents('tr').find('.mac').text().trim();
        var sn = $(this).parents('tr').find('.sn').text().trim();
        $('#deviceId_d').val(device_id);
        $('#mac_d').val(mac);
        $('#sn_d').val(sn);
        $('#delete-modal').modal('show')
    });


    $('.need-hover').hover(function () {
            $(this).addClass('divOver');
        }, function () {
            $(this).removeClass('divOver');
        }
    );

    //点击事件
    $('#parent-table-info').on('click', "tr", function () {
        if ($(this).is('.even') || $(this).is('.odd')) {
            var deviceId = $(this).find('.deviceId').text().trim();
            if (deviceId == 'null' || deviceId.length == 0) {
                return
            }
            var modelId = $(this).find('.modelId').text().trim();
            if (modelId == 'null' || modelId.length == 0) {
                $('#universal-title').html('<strong>无法查看绑定Model信息</strong>');
                $('#universal-message').html('请补充型号ID字段信息。<br/>');
                $('#universal-modal').modal('show')
                return
            }
            var $tr = $(this);
            var table_name1 = 'parent-table-info'.replace(/-/g, '_');
            var row = window[table_name1].row($tr);

            if (row.child.isShown()) {
                row.child.hide();
                $tr.removeClass('shown');
            } else {
                $.ajax({
                    url: "/factorydata/getFactoryDataExtraInfo",
                    type: "POST",
                    dataType: "json",
                    data: {
                        modelId: modelId
                    },
                    success: function (data) {
                        var data1 = eval(data);

                        row.child(data1.html).show();
                        $tr.addClass('shown');
                    },
                    error: function (data) {
                        alert("FAILED.");
                    }
                })
            }
        }
    });


    $('#start-time').datepicker({
        format: "yyyy-mm-dd",
        autoclose: true
    });

    $('#end-time').datepicker({
        format: "yyyy-mm-dd",
        autoclose: true
    });
});

function load_search_result() {
    var columns = columns_priority;

    $.fn.dataTable.ext.errMode = 'none';
    $('#parent-table-info').dataTable().fnClearTable(false);
    $('#parent-table-info').dataTable().fnDestroy();

    var device_id = document.getElementById("device-id-search").value;
    var mac = document.getElementById("mac-search").value;

    if (is_global == 'True'){
        var sn = document.getElementById("sn-search").value;
        var firmware_id = document.getElementById("firmware-id-search").value;

        var model_id = document.getElementById("model-id-search").value;

        var start_time = document.getElementById("start-time").value;
        var end_time = document.getElementById("end-time").value;

        var data_post = {
                deviceId: device_id,
                mac: mac,
                sn: sn,
                firmwareId: firmware_id,
                modelId: model_id,
                startTime: start_time,
                endTime: end_time
        }
    } else {
         var data_post = {
                deviceId: device_id,
                mac: mac,
        }
    }

    var table_name = 'parent-table-info'.replace(/-/g, '_');

    if (is_global == 'True'){
        window[table_name] = $('#parent-table-info').on('error.dt', function (e, settings, techNote, message) {
            console.log('An error has been reported by DataTables: ', message);
            $('#universal-title').html('<strong>生产设备信息查询结果</strong>');
            $('#universal-message').html('生产设备信息查询失败。<br/>请稍后重试或请登录！');
            $('#universal-modal').modal('show')
        }).DataTable({
            "lengthChange": true,
            "autoWidth": false,
            "processing": false,
            "paging": true,
            "searching": false,
            "ordering": false,
            "Info": true,
            "serverSide": true,
            "stripeClasses": ['odd parent-tr', 'even  parent-tr'],

            "lengthMenu": [[8, 15, 50, 100], [8, 15, 50, 100]],
            "order": [[0, 'asc']],
            "oLanguage": {
                "oAria": {
                    "sSortAscending": " - click/return to sort ascending",
                    "sSortDescending": " - click/return to sort descending"
                },
                "sLengthMenu": "显示 _MENU_ 记录",
                "sZeroRecords": "对不起，查询结果中无相关数据",
                "sEmptyTable": "未有相关数据，请重新输入查询条件",
                "sLoadingRecords": "正在加载数据-请等待...",
                "sInfo": "当前显示 _START_ 到 _END_ 条，共 _TOTAL_ 条记录。",
                "sInfoEmpty": "当前显示0到0条，共0条记录",
                "sInfoFiltered": "（数据库中共为 _MAX_ 条记录）",

                "sProcessing": "正在加载数据...",
                "sSearch": "搜索：",
                "sUrl": "",
                "oPaginate": {
                    "sFirst": "首页",
                    "sPrevious": " 上一页 ",
                    "sNext": " 下一页 ",
                    "sLast": " 尾页 "
                }
            },

            "ajax": {
                url: "/factorydata/readFactoryDataInfo",
                type: "POST",
                dataType: "json",
                data: data_post

            },
            "columns": columns,
            "createdRow": function (row, data, index) {

                var productionDate_Long = data['productionDate'];
                if (productionDate_Long != null && productionDate_Long != 'null') {
                    var productionDate_Date = new Date(productionDate_Long).format('yyyy-MM-dd  h:m:s');
                    $('td', row).eq(4).html(productionDate_Date);
                }
            }

        })
    } else {
        window[table_name] = $('#parent-table-info').on('error.dt', function (e, settings, techNote, message) {
            console.log('An error has been reported by DataTables: ', message);
            $('#universal-title').html('<strong>生产设备信息查询结果</strong>');
            $('#universal-message').html('生产设备信息查询失败。<br/>请稍后重试或请登录！');
            $('#universal-modal').modal('show')
        }).DataTable({
            "lengthChange": true,
            "autoWidth": false,
            "processing": false,
            "paging": true,
            "searching": false,
            "ordering": false,
            "Info": true,
            "serverSide": false,
            "stripeClasses": ['odd parent-tr', 'even  parent-tr'],

            "lengthMenu": [[8, 15, 50, 100], [8, 15, 50, 100]],
            "order": [[0, 'asc']],
            "oLanguage": {
                "oAria": {
                    "sSortAscending": " - click/return to sort ascending",
                    "sSortDescending": " - click/return to sort descending"
                },
                "sLengthMenu": "显示 _MENU_ 记录",
                "sZeroRecords": "对不起，查询结果中无相关数据",
                "sEmptyTable": "未有相关数据，请重新输入查询条件",
                "sLoadingRecords": "正在加载数据-请等待...",
                "sInfo": "当前显示 _START_ 到 _END_ 条，共 _TOTAL_ 条记录。",
                "sInfoEmpty": "当前显示0到0条，共0条记录",


                "sProcessing": "正在加载数据...",
                "sSearch": "搜索：",
                "sUrl": "",
                "oPaginate": {
                    "sFirst": "首页",
                    "sPrevious": " 上一页 ",
                    "sNext": " 下一页 ",
                    "sLast": " 尾页 "
                }
            },

            "ajax": {
                url: "/factorydata/readFactoryDataInfo",
                type: "POST",
                dataType: "json",
                data: data_post

            },
            "columns": columns,
            "createdRow": function (row, data, index) {

                var productionDate_Long = data['productionDate'];
                if (productionDate_Long != null && productionDate_Long != 'null') {
                    var productionDate_Date = new Date(productionDate_Long).format('yyyy-MM-dd  h:m:s');
                    $('td', row).eq(4).html(productionDate_Date);
                }
            }

        })
    }

}

function add_button (){
    $('#add-modal').modal('show')
}


function add_one_button () {

    $('#add-one-modal').modal('show');
    $('#production-date-add').datetimepicker({
        format: "YYYY-MM-DD HH:mm:ss"
    });

}

function upload_button() {
    window.open(host+"/OAManager/pd_file_upload.html");
}

function add_one_service() {
    var mac = $("#mac-add").val().trim();
    var sn = $("#sn-add").val().trim();
    var fw_id = $("#fw-id-add").val().trim();
    var device_id = $('#device-id-add').val().trim();
    var production_date = $('#production-date-add').val().trim();
    var category_name = $("#category-name-add").val().trim();
    var hw_type = $("#hw-type-add").val().trim();
    var hw_version = $("#hw-version-add").val().trim();
    var hw_id = $("#hw-id-add").val().trim();

    if (device_id.length != 40){
        document.getElementById("device-id-add").style.borderColor = "red";
        return;
    }else{
        document.getElementById("device-id-add").style.borderColor = "gray";
    }

    if (mac.length < 12){
        document.getElementById("mac-add").style.borderColor = "red";
        return;
    }else{
        document.getElementById("mac-add").style.borderColor = "gray";
    }

    if (sn.length > 13){
        document.getElementById("sn-add").style.borderColor = "red";
        return;
    } else {
        document.getElementById("sn-add").style.borderColor = "gray";
    }

    if (fw_id.length != 32){
        document.getElementById("fw-id-add").style.borderColor = "red";
        return;
    } else {
        document.getElementById("fw-id-add").style.borderColor = "gray";
    }

    var production_date_format = /^(?:19|20)[0-9][0-9]-(?:(?:0[1-9])|(?:1[0-2]))-(?:(?:[0-2][1-9])|(?:[1-3][0-1])) (?:(?:[0-2][0-3])|(?:[0-1][0-9])):[0-5][0-9]:[0-5][0-9]$/;
    if (!production_date_format.test(production_date)){
        document.getElementById("production-date-add").style.borderColor = "red";
        return;
    } else {
        document.getElementById("production-date-add").style.borderColor = "gray";
    }

    if (hw_type.length <= 0){
        document.getElementById("hw-type-add").style.borderColor = "red";
        return;
    } else {
        document.getElementById("hw-type-add").style.borderColor = "gray";
    }

    if (hw_version.length <= 0){
        document.getElementById("hw-version-add").style.borderColor = "red";
        return;
    } else {
        document.getElementById("hw-version-add").style.borderColor = "gray";
    }

    if (hw_type.length <= 0){
        document.getElementById("hw-type-add").style.borderColor = "red";
        return;
    } else {
        document.getElementById("hw-type-add").style.borderColor = "gray";
    }

    if (hw_id.length != 32){
        document.getElementById("hw-id-add").style.borderColor = "red";
        return;
    }else{
        document.getElementById("hw-id-add").style.borderColor = "gray";
    }

    if (category_name.length <= 0){
        document.getElementById("category-name-add").style.borderColor = "red";
        return;
    }else{
        document.getElementById("category-name-add").style.borderColor = "gray";
    }

    var device_list = {'deviceId':device_id,'mac':mac,'sn':sn, 'fwId':fw_id, 'hwId':hw_id, 'recordTime':production_date,
                        'hwType':hw_type,'hwVersion':hw_version,'categoryName':category_name};
    var device_list_a = '['+ JSON.stringify(device_list) + ']';

    $.ajax({
        url: "/factorydata/addFactoryDataInfo",
        type: "POST",
        dataType: "json",
        data: {
            deviceList:device_list_a
        },
        success: function (data) {
            var data1 = eval(data);
            $('#universal-title').html('<strong>修改设备信息</strong>');

            if (data1.result == 'true') {
                $('#universal-message').html("添加设备信息成功");
            } else {
                $('#universal-message').html("添加设备信息失败");
            }
            $('#add-one-modal').modal('hide');
            $('#universal-modal').modal('show');

            var table_name1 = 'parent-table-info'.replace(/-/g, '_');
            window[table_name1].ajax.reload();
        },
        error: function (data) {
            alert("请登录");
        }
    })
}

function add_service() {
    var device_list_a = $('#device_list_a').val().trim();
    if (device_list_a== null || device_list_a== '') {
        $('#universal-title').html('<strong>添加失败</strong>');
        $('#universal-message').html('请输入生产数据<br/>');
        $('#add-modal').modal('hide');
        $('#universal-modal').modal('show')
        return
    }

    var device_list = eval(device_list_a);

    if (device_list.length == 0) {
        $('#universal-title').html('<strong>添加失败</strong>');
        $('#universal-message').html('请输入生产数据<br/>');
        $('#add-modal').modal('hide');
        $('#universal-modal').modal('show')
        return
    }

    if (device_list.length > 50) {
        $('#universal-title').html('<strong>添加失败</strong>');
        $('#universal-message').html('一次最多添加50条生产数据<br/>');
        $('#add-modal').modal('hide');
        $('#universal-modal').modal('show')
        return
    }

    $.ajax({
        url: "/factorydata/addFactoryDataInfo",
        type: "POST",
        dataType: "json",
        data: {
            deviceList: device_list_a
        },
        success: function (data) {
            var data1 = eval(data);
            $('#universal-title').html('<strong>添加生产数据信息</strong>');
            if (data1.result == 'true') {
                $('#universal-message').html("添加设备生产数据信息成功");
            } else {
                $('#universal-message').html("添加设备生产数据信息失败");
            }
            $('#add-modal').modal('hide');
            $('#universal-modal').modal('show');
            var table_name1 = 'parent-table-info'.replace(/-/g, '_');
            window[table_name1].ajax.reload();

        },
        error: function (data) {
            console.log("请登录"),
            alert("请登录");
        }
    })
}

function modify_service() {
    var mac = $("#mac_m").val().trim();
    var sn = $("#sn_m").val().trim();
    var fw_id = $("#firmwareId_m").val().trim();
    var device_id = $('#deviceId_m').val().trim();
    var production_date = $('#productionDate_m').val().trim();
    var categoryName = $("#categoryName_m").val().trim();
    var hwType = $("#hardwareType_m").val().trim();
    var hwVersion = $("#hardwareVersion_m").val().trim();
    var hwId = $("#hardwareId_m").val().trim();
    $.ajax({
        url: "/factorydata/modifyFactoryDataInfo",
        type: "POST",
        dataType: "json",
        data: {
            deviceId: device_id,
            mac: mac,
            sn: sn,
            fwId: fw_id,
            recordTime: production_date,
            categoryName: categoryName,
            hwType: hwType,
            hwVersion: hwVersion,
            hwId: hwId
        },
        success: function (data) {
            var data1 = eval(data);
            $('#universal-title').html('<strong>修改设备信息</strong>');

            if (data1.result == 'true') {
                $('#universal-message').html("修改设备信息成功");
            } else {
                $('#universal-message').html("修改设备信息失败");
            }
            $('#modify-modal').modal('hide');
            $('#universal-modal').modal('show');
            if (data1.result == 'true') {
                $('#parent-table-info').find('.modify-tag').find('.mac').html(mac);
                $('#parent-table-info').find('.modify-tag').find('.sn').html(sn);
                $('#parent-table-info').find('.modify-tag').find('.firmwareId').html(fw_id);
                $('#parent-table-info').find('.modify-tag').find('.productionDate').html(production_date);
                $('#parent-table-info').find('.modify-tag').find('.modelId').html(data1.modelId);
            }
        },
        error: function (data) {
            alert("请登录");
        }
    })
}

function delete_service() {
    var device_id = $('#deviceId_d').val()
    $.ajax({
        url: "/factorydata/delFactoryDataInfo",
        type: "POST",
        dataType: "json",
        data: {
            deviceId: device_id
        },
        success: function (data) {
            $('#delete-modal').modal('hide')
            var data1 = eval(data);

            if (data1.result == 'true') {
                $('#universal-message').html("删除生产数据成功");
            } else {
                $('#universal-message').html("删除生产数据失败");
            }
            $('#universal-title').html('<strong>删除结果</strong>');
            $('#universal-modal').modal('show');
            if (data1.result == 'true') {
                var table_name = 'parent-table-info'.replace(/-/g, '_');
                window[table_name].row('.remove-tag').remove().draw(false)
            }
        },
        error: function (data) {
            alert("请登录");
        }
    })
}

Date.prototype.format = function (format) {
    var date = {
        "M+": this.getMonth() + 1,
        "d+": this.getDate(),
        "h+": this.getHours(),
        "m+": this.getMinutes(),
        "s+": this.getSeconds(),
        "q+": Math.floor((this.getMonth() + 3) / 3),
        "S+": this.getMilliseconds()
    };
    if (/(y+)/i.test(format)) {
        format = format.replace(RegExp.$1, (this.getFullYear() + '').substr(4 - RegExp.$1.length));
    }
    for (var k in date) {
        if (new RegExp("(" + k + ")").test(format)) {
            format = format.replace(RegExp.$1, RegExp.$1.length == 2 ? date[k] : ("00" + date[k]).substr(("" + date[k]).length));
        }
    }
    return format;
};

