/**
 * Created by yuzhijiang on 2017/11/8.
 */



$(document).ready(function () {
    load_search_result();
    $("#parent-table-info").on("click", ".edit-job-button", function (e) {
        e.stopPropagation();
        var table_name = 'parent-table-info'.replace(/-/g, '_');
        window[table_name].$('tr.modify-tag').removeClass('modify-tag');
        $(this).parents('tr').addClass('modify-tag');
        var device_id = $(this).parents('tr').find('.deviceId').text().trim();

        if (device_id == 'null' || device_id.length == 0) {
            $('#universal-title').html('<strong>无法编辑</strong>');
            $('#universal-message').html('请补充设备ID字段信息。<br/>');
            $('#universal-modal').modal('show')
            return
        }

        var model_id = $(this).parents('tr').find('.modelId').text().trim();
        if (model_id == 'null' || model_id.length == 0) {
            $('#universal-title').html('<strong>无法编辑</strong>');
            $('#universal-message').html('缺失型号ID字段信息，无法编辑。<br/>');
            $('#universal-modal').modal('show')
            return
        }
        $.ajax({
            url: "/factorydata/readTargetEditingFactoryDataInfo",
            type: "POST",
            dataType: "json",
            data: {
                deviceId: device_id
            },
            success: function (data) {
                $('#modify-modal-body').html(data.html);
                $('#modify-modal').modal('show')
            },
            error: function (data) {
                alert("FAILED.");
            }
        })
    });

    $("#parent-table-info").on("click", ".delete-job-button", function (e) {
        e.stopPropagation()
        var table_name = 'parent-table-info'.replace(/-/g, '_');
        window[table_name].$('tr.remove-tag').removeClass('remove-tag');
        $(this).parents('tr').addClass('remove-tag');
        var device_id = $(this).parents('tr').find('.deviceId').text().trim();
        var mac = $(this).parents('tr').find('.mac').text().trim();
        var sn = $(this).parents('tr').find('.sn').text().trim();
        $('#deviceId_d').val(device_id);
        $('#mac_d').val(mac);
        $('#sn_d').val(sn);
        $('#delete-modal').modal('show')
    });


    $('.need-hover').hover(function () {
            $(this).addClass('divOver');
        }, function () {
            $(this).removeClass('divOver');
        }
    );



    $('#start-time').datepicker({
        format: "yyyy-mm-dd",
        autoclose: true
    });

    $('#end-time').datepicker({
        format: "yyyy-mm-dd",
        autoclose: true
    });
});

function load_search_result() {
    var columns = columns_priority;

    $.fn.dataTable.ext.errMode = 'none';
    $('#parent-table-info').dataTable().fnClearTable(false);
    $('#parent-table-info').dataTable().fnDestroy();

    var plugin_id = document.getElementById("plugin-id-search").value;
    var plugin_version = document.getElementById("plugin-version-search").value;
    var fw_id = document.getElementById("fw-id-search").value;
    var hw_id = document.getElementById("hw-id-search").value;

    var table_name = 'parent-table-info'.replace(/-/g, '_');

    window[table_name] = $('#parent-table-info').on('error.dt', function (e, settings, techNote, message) {
        console.log('An error has been reported by DataTables: ', message);
        $('#universal-title').html('<strong>插件适配表信息查询结果</strong>');
        $('#universal-message').html('插件适配表信息查询失败。<br/>请稍后重试或请登录！');
        $('#universal-modal').modal('show')
    }).DataTable({
        "lengthChange": true,
        "autoWidth": false,
        "processing": false,
        "paging": true,
        "searching": false,
        "ordering": false,
        "Info": true,
        "serverSide": true,
        "stripeClasses": ['odd parent-tr', 'even  parent-tr'],

        "lengthMenu": [[10, 15, 50, 100], [10, 15, 50, 100]],
        "order": [[0, 'asc']],
        "oLanguage": {
            "oAria": {
                "sSortAscending": " - click/return to sort ascending",
                "sSortDescending": " - click/return to sort descending"
            },
            "sLengthMenu": "显示 _MENU_ 记录",
            "sZeroRecords": "对不起，查询结果中无相关数据",
            "sEmptyTable": "未有相关数据，请重新输入查询条件",
            "sLoadingRecords": "正在加载数据-请等待...",
            "sInfo": "当前显示 _START_ 到 _END_ 条，共 _TOTAL_ 条记录。",
            "sInfoEmpty": "当前显示0到0条，共0条记录",
            "sInfoFiltered": "（数据库中共为 _MAX_ 条记录）",
            "sProcessing": "正在加载数据...",
            "sSearch": "搜索：",
            "sUrl": "",
            "oPaginate": {
                "sFirst": "首页",
                "sPrevious": " 上一页 ",
                "sNext": " 下一页 ",
                "sLast": " 尾页 "
            }
        },

        "ajax": {
            url: "/plugin/readPluginSuitableModelInfo",
            type: "POST",
            dataType: "json",
            data: {
                pluginId: plugin_id,
                pluginVersion:plugin_version,
                hwId:hw_id,
                fwId:fw_id
            }
        },
        "columns": columns

    })
}

function add_button_add(){
    window.open(host+"/OAManager/add_pi_adapter.html");
    // $('#add-modal').modal('show')
}

function add_button_delete(){
    window.open(host+"/OAManager/del_pi_adapter.html");
    // $('#add-modal').modal('show')
}

function modify_service() {
    var mac = $("#mac_m").val().trim();
    var sn = $("#sn_m").val().trim();
    var fw_id = $("#firmwareId_m").val().trim();
    var device_id = $('#deviceId_m').val().trim();
    var production_date = $('#productionDate_m').val().trim();
    var categoryName = $("#categoryName_m").val().trim();
    var hwType = $("#hardwareType_m").val().trim();
    var hwVersion = $("#hardwareVersion_m").val().trim();
    var hwId = $("#hardwareId_m").val().trim();
    $.ajax({
        url: "/factorydata/modifyFactoryDataInfo",
        type: "POST",
        dataType: "json",
        data: {
            deviceId: device_id,
            mac: mac,
            sn: sn,
            fwId: fw_id,
            recordTime: production_date,
            categoryName: categoryName,
            hwType: hwType,
            hwVersion: hwVersion,
            hwId: hwId
        },
        success: function (data) {
            var data1 = eval(data);
            $('#universal-title').html('<strong>修改设备信息</strong>');

            if (data1.result == 'true') {
                $('#universal-message').html("修改设备信息成功");
            } else {
                $('#universal-message').html("修改设备信息失败");
            }
            $('#modify-modal').modal('hide');
            $('#universal-modal').modal('show');
            if (data1.result == 'true') {
                $('#parent-table-info').find('.modify-tag').find('.mac').html(mac);
                $('#parent-table-info').find('.modify-tag').find('.sn').html(sn);
                $('#parent-table-info').find('.modify-tag').find('.firmwareId').html(fw_id);
                $('#parent-table-info').find('.modify-tag').find('.productionDate').html(production_date);
                $('#parent-table-info').find('.modify-tag').find('.modelId').html(data1.modelId);
            }
        },
        error: function (data) {
            alert("请登录");
        }
    })
}

function delete_service() {
    var device_id = $('#deviceId_d').val()
    $.ajax({
        url: "/factorydata/delFactoryDataInfoBeta",
        type: "POST",
        dataType: "json",
        data: {
            deviceId: device_id
        },
        success: function (data) {
            $('#delete-modal').modal('hide')
            var data1 = eval(data);

            if (data1.result == 'true') {
                $('#universal-message').html("删除生产数据成功");
            } else {
                $('#universal-message').html("删除生产数据失败");
            }
            $('#universal-title').html('<strong>删除结果</strong>');
            $('#universal-modal').modal('show');
            if (data1.result == 'true') {
                var table_name = 'parent-table-info'.replace(/-/g, '_');
                window[table_name].row('.remove-tag').remove().draw(false)
            }
        },
        error: function (data) {
            alert("请登录");
        }
    })
}

Date.prototype.format = function (format) {
    var date = {
        "M+": this.getMonth() + 1,
        "d+": this.getDate(),
        "h+": this.getHours(),
        "m+": this.getMinutes(),
        "s+": this.getSeconds(),
        "q+": Math.floor((this.getMonth() + 3) / 3),
        "S+": this.getMilliseconds()
    };
    if (/(y+)/i.test(format)) {
        format = format.replace(RegExp.$1, (this.getFullYear() + '').substr(4 - RegExp.$1.length));
    }
    for (var k in date) {
        if (new RegExp("(" + k + ")").test(format)) {
            format = format.replace(RegExp.$1, RegExp.$1.length == 2 ? date[k] : ("00" + date[k]).substr(("" + date[k]).length));
        }
    }
    return format;
};

