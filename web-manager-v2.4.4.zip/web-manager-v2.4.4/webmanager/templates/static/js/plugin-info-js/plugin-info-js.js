/**
 * Created by yuzhijiang on 2017/11/8.
 */



$(document).ready(function () {
    load_search_result();
    $("#parent-table-info").on("click", ".edit-job-button", function (e) {
        e.stopPropagation();
        var table_name = 'parent-table-info'.replace(/-/g, '_');
        window[table_name].$('tr.modify-tag').removeClass('modify-tag');
        $(this).parents('tr').addClass('modify-tag');
        var device_id = $(this).parents('tr').find('.deviceId').text().trim();

        if (device_id == 'null' || device_id.length == 0) {
            $('#universal-title').html('<strong>无法编辑</strong>');
            $('#universal-message').html('请补充设备ID字段信息。<br/>');
            $('#universal-modal').modal('show')
            return
        }

        var model_id = $(this).parents('tr').find('.modelId').text().trim();

        if (model_id == 'null' || model_id.length == 0) {
            $('#universal-title').html('<strong>无法编辑</strong>');
            $('#universal-message').html('缺失型号ID字段信息，无法编辑。<br/>');
            $('#universal-modal').modal('show')
            return
        }
        $.ajax({
            url: "/factorydata/readTargetEditingFactoryDataInfo",
            type: "POST",
            dataType: "json",
            data: {
                deviceId: device_id
            },
            success: function (data) {
                $('#modify-modal-body').html(data.html);
                $('#modify-modal').modal('show')
            },
            error: function (data) {
                alert("FAILED.");
            }
        })
    });

    $("#parent-table-info").on("click", ".delete-job-button", function (e) {
        e.stopPropagation()
        var table_name = 'parent-table-info'.replace(/-/g, '_');
        window[table_name].$('tr.remove-tag').removeClass('remove-tag');
        $(this).parents('tr').addClass('remove-tag');
        var device_id = $(this).parents('tr').find('.deviceId').text().trim();
        var mac = $(this).parents('tr').find('.mac').text().trim();
        var sn = $(this).parents('tr').find('.sn').text().trim();
        $('#deviceId_d').val(device_id);
        $('#mac_d').val(mac);
        $('#sn_d').val(sn);
        $('#delete-modal').modal('show')
    });


    $('.need-hover').hover(function () {
            $(this).addClass('divOver');
        }, function () {
            $(this).removeClass('divOver');
        }
    );

    //点击事件
    $('#parent-table-info').on('click', "tr", function () {
        if ($(this).is('.even') || $(this).is('.odd')) {

            var pluginId = $(this).find('.pluginId').text().trim();
            var pluginVersion = $(this).find('.pluginVersion').text().trim();
            if (pluginId == 'null' || pluginId.length == 0) {
                $('#universal-title').html('<strong>无法查看该插件详细信息</strong>');
                $('#universal-message').html('请补充插件ID字段信息。<br/>');
                $('#universal-modal').modal('show')
                return
            }

            if (pluginVersion == 'null' || pluginVersion.length == 0) {
                $('#universal-title').html('<strong>无法查看该插件详细信息</strong>');
                $('#universal-message').html('请补充插件版本号字段信息。<br/>');
                $('#universal-modal').modal('show')
                return
            }
            var $tr = $(this);
            var table_name1 = 'parent-table-info'.replace(/-/g, '_');
            var row = window[table_name1].row($tr);

            if (row.child.isShown()) {
                row.child.hide();
                $tr.removeClass('shown');
            } else {
                $.ajax({
                    url: "/plugin/getPluginExtraInfo",
                    type: "POST",
                    dataType: "json",
                    data: {
                        pluginId: pluginId,
                        pluginVersion: pluginVersion
                    },
                    success: function (data) {
                        var data1 = eval(data);

                        row.child(data1.html).show();
                        $tr.addClass('shown');
                    },
                    error: function (data) {
                        alert("FAILED.");
                    }
                })
            }
        }
    });


    $('#start-time').datepicker({
        format: "yyyy-mm-dd",
        autoclose: true
    });

    $('#end-time').datepicker({
        format: "yyyy-mm-dd",
        autoclose: true
    });
});

function load_search_result() {
    var columns = columns_priority;

    $.fn.dataTable.ext.errMode = 'none';
    $('#parent-table-info').dataTable().fnClearTable(false);
    $('#parent-table-info').dataTable().fnDestroy();

    var plugin_id = document.getElementById("plugin-id-search").value;
    var plugin_version = document.getElementById("plugin-version-search").value;

    var on_shelf = document.getElementById("on-shelf-search").value;


    var table_name = 'parent-table-info'.replace(/-/g, '_');

    var post_data = {
            pluginId: plugin_id,
            pluginVersion: plugin_version,
            onShelf: on_shelf,
        }



    window[table_name] = $('#parent-table-info').on('error.dt', function (e, settings, techNote, message) {
        console.log('An error has been reported by DataTables: ', message);
        $('#universal-title').html('<strong>插件信息查询结果</strong>');
        $('#universal-message').html('插件信息查询失败。<br/>请稍后重试或请登录！');
        $('#universal-modal').modal('show')
    }).DataTable({
        "lengthChange": true,
        "autoWidth": false,
        "processing": false,
        "paging": true,
        "searching": false,
        "ordering": false,
        "Info": true,
        "serverSide": true,
        "stripeClasses": ['odd parent-tr', 'even  parent-tr'],

        "lengthMenu": [[10, 15, 50, 100], [10, 15, 50, 100]],
        "order": [[0, 'asc']],
        "oLanguage": {
            "oAria": {
                "sSortAscending": " - click/return to sort ascending",
                "sSortDescending": " - click/return to sort descending"
            },
            "sLengthMenu": "显示 _MENU_ 记录",
            "sZeroRecords": "对不起，查询结果中无相关数据",
            "sEmptyTable": "未有相关数据，请重新输入查询条件",
            "sLoadingRecords": "正在加载数据-请等待...",
            "sInfo": "当前显示 _START_ 到 _END_ 条，共 _TOTAL_ 条记录。",
            "sInfoEmpty": "当前显示0到0条，共0条记录",
            "sInfoFiltered": "（数据库中共为 _MAX_ 条记录）",
            "sProcessing": "正在加载数据...",
            "sSearch": "搜索：",
            "sUrl": "",
            "oPaginate": {
                "sFirst": "首页",
                "sPrevious": " 上一页 ",
                "sNext": " 下一页 ",
                "sLast": " 尾页 "
            }
        },

        "ajax": {
            url: "/plugin/readPluginInfo",
            type: "POST",
            dataType: "json",
            data: post_data
        },
        "columns": columns,
        "createdRow": function (row, data, index) {
            if (data['authority'] == 'no permission'){
                alert('NO PERMISSION')
                return;
            }

            var on_shelf_N = '<span style="width:60px" class="label label-sm label-warning">下架</span>';
            var on_shelf_Y = '<span style="width:60px" class="label label-sm label-success">上架</span>';
            var on_shelf_Unknown = '<span style="width:60px" class="label label-sm ">未知</span>';
            if (data['onShelf'] == 'Y') {
                $('td', row).eq(2).html(on_shelf_Y);

            } else if (data['onShelf'] == 'N'){
                $('td', row).eq(2).html(on_shelf_N);
            }else{
                $('td', row).eq(2).html(on_shelf_Unknown);
            }

            if (data['isBeta'] == 'Y') {
                $('td', row).eq(6).html('是');

            } else if (data['isBeta'] == 'N'){
                $('td', row).eq(6).html('否');
            }else{
                $('td', row).eq(6).html('未知');
            }

            var releaseDate_Long = data['releaseTime'];
            if (releaseDate_Long != null && releaseDate_Long != '-') {
                var releaseDate_Date = new Date(releaseDate_Long).format('yyyy-MM-dd  h:m:s')
                $('td', row).eq(5).html(releaseDate_Date);
            }

        },
    })
}

function add_button(){
    window.open(host+"/OAManager/pi_message_upload.html")
}

function show_value_detail(value){
    $('#universal-title').html('<strong>详情</strong>');
    $('#universal-message').html(value);
    $('#universal-modal').modal('show');
}

function add_service() {
    var device_list_a = $('#device_list_a').val().trim();
    var device_list = eval(device_list_a);

    if (device_list.length == 0) {
        $('#universal-title').html('<strong>添加失败</strong>');
        $('#universal-message').html('请输入生产数据<br/>');
        $('#add-modal').modal('hide');
        $('#universal-modal').modal('show');
        return
    }

    if (device_list.length > 50) {
        $('#universal-title').html('<strong>添加失败</strong>');
        $('#universal-message').html('一次最多添加50条生产数据<br/>');
        $('#add-modal').modal('hide');
        $('#universal-modal').modal('show')
        return
    }

    $.ajax({
        url: "/factorydata/addFactoryDataInfo",
        type: "POST",
        dataType: "json",
        data: {
            deviceList: device_list_a
        },
        success: function (data) {
            var data1 = eval(data);
            $('#universal-title').html('<strong>添加生产数据信息</strong>');
            if (data1.result == 'true') {
                $('#universal-message').html("添加设备生产数据信息成功");
            } else {
                $('#universal-message').html("添加设备生产数据信息失败");
            }
            $('#add-modal').modal('hide');
            $('#universal-modal').modal('show');
            var table_name1 = 'parent-table-info'.replace(/-/g, '_');
            window[table_name1].ajax.reload();

        },
        error: function (data) {
            console.log("请登录"),
            alert("请登录");
        }
    })
}


Date.prototype.format = function (format) {
    var date = {
        "M+": this.getMonth() + 1,
        "d+": this.getDate(),
        "h+": this.getHours(),
        "m+": this.getMinutes(),
        "s+": this.getSeconds(),
        "q+": Math.floor((this.getMonth() + 3) / 3),
        "S+": this.getMilliseconds()
    };
    if (/(y+)/i.test(format)) {
        format = format.replace(RegExp.$1, (this.getFullYear() + '').substr(4 - RegExp.$1.length));
    }
    for (var k in date) {
        if (new RegExp("(" + k + ")").test(format)) {
            format = format.replace(RegExp.$1, RegExp.$1.length == 2 ? date[k] : ("00" + date[k]).substr(("" + date[k]).length));
        }
    }
    return format;
};

