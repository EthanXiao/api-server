/**
 * Created by yuzhijiang on 2017/11/8.
 */


$(document).ready(function () {
    load_search_result();


    $('.need-hover').hover(function () {
            $(this).addClass('divOver');
        }, function () {
            $(this).removeClass('divOver');
        }
    );

    //点击事件
    $('#parent-table-info').on('click', "tr", function () {
        if ($(this).is('.even') || $(this).is('.odd')) {

            if (is_global == 'True'){
                var package_name = $(this).find('.packageName').text().trim();
                var app_version_code = $(this).find('.appVersionCode').text().trim();
                var platform = $(this).find('.platform').text().trim();

                if (package_name == 'null' || package_name.length == 0 ||app_version_code == 'null'
                    || app_version_code.length == 0||platform == 'null' || platform.length == 0) {
                    $('#universal-title').html('<strong>无法查看该APP详细信息</strong>');
                    $('#universal-message').html('无效APP列表信息。<br/>');
                    $('#universal-modal').modal('show');
                    return
                }
                var post_data = {
                        packageName: package_name,
                        appVersionCode: app_version_code,
                        platform: platform
                    }
            } else {
                var package_name = $(this).find('.packageName').text().trim();
                var app_version_code = $(this).find('.appVersionCode').text().trim();
                if (package_name == 'null' || package_name.length == 0 ||app_version_code == 'null'
                    || app_version_code.length == 0 ) {
                    $('#universal-title').html('<strong>无法查看该APP详细信息</strong>');
                    $('#universal-message').html('无效APP列表信息。<br/>');
                    $('#universal-modal').modal('show');
                    return
                }
                var post_data = {
                    packageName: package_name,
                    appVersionCode: app_version_code
                }
            }



            var $tr = $(this);
            var table_name1 = 'parent-table-info'.replace(/-/g, '_');
            var row = window[table_name1].row($tr);

            if (row.child.isShown()) {
                row.child.hide();
                $tr.removeClass('shown');
            } else {
                $.ajax({
                    url: "/app/getAppExtraInfo",
                    type: "POST",
                    dataType: "json",
                    data: post_data,
                    success: function (data) {
                        var data1 = eval(data);

                        row.child(data1.html).show();
                        $tr.addClass('shown');
                    },
                    error: function (data) {
                        alert("FAILED.");
                    }
                })
            }
        }
    });


    $('#start-time').datepicker({
        format: "yyyy-mm-dd",
        autoclose: true
    });

    $('#end-time').datepicker({
        format: "yyyy-mm-dd",
        autoclose: true
    });
});

function load_search_result() {
    var columns = columns_priority;

    $.fn.dataTable.ext.errMode = 'none';
    $('#parent-table-info').dataTable().fnClearTable(false);
    $('#parent-table-info').dataTable().fnDestroy();

    var package_name = document.getElementById("package-name-search").value;
    var on_shelf = document.getElementById("status-search").value;

    var app_name = document.getElementById("app-name-search").value;


    var table_name = 'parent-table-info'.replace(/-/g, '_');

    window[table_name] = $('#parent-table-info').on('error.dt', function (e, settings, techNote, message) {
        console.log('An error has been reported by DataTables: ', message);
        $('#universal-title').html('<strong>APP列表信息查询结果</strong>');
        $('#universal-message').html('APP列表信息查询失败。<br/>请稍后重试或请登录！');
        $('#universal-modal').modal('show')
    }).DataTable({
        "lengthChange": true,
        "autoWidth": false,
        "processing": false,
        "paging": true,
        "searching": false,
        "ordering": false,
        "Info": true,
        "serverSide": true,
        "stripeClasses": ['odd parent-tr', 'even  parent-tr'],

        "lengthMenu": [[8, 15, 50, 100], [8, 15, 50, 100]],
        "order": [[0, 'asc']],
        "oLanguage": {
            "oAria": {
                "sSortAscending": " - click/return to sort ascending",
                "sSortDescending": " - click/return to sort descending"
            },
            "sLengthMenu": "显示 _MENU_ 记录",
            "sZeroRecords": "对不起，查询结果中无相关数据",
            "sEmptyTable": "未有相关数据，请重新输入查询条件",
            "sLoadingRecords": "正在加载数据-请等待...",
            "sInfo": "当前显示 _START_ 到 _END_ 条，共 _TOTAL_ 条记录。",
            "sInfoEmpty": "当前显示0到0条，共0条记录",
            "sInfoFiltered": "（数据库中共为 _MAX_ 条记录）",
            "sProcessing": "正在加载数据...",
            "sSearch": "搜索：",
            "sUrl": "",
            "oPaginate": {
                "sFirst": "首页",
                "sPrevious": " 上一页 ",
                "sNext": " 下一页 ",
                "sLast": " 尾页 "
            }
        },

        "ajax": {
            url: "/app/readAppInfo",
            type: "POST",
            dataType: "json",
            data: {
                packageName: package_name,
                appName: app_name,
                onShelf: on_shelf
            }
        },
        "columns": columns,
        "createdRow": function (row, data, index) {
            if (data['authority'] == 'no permission'){
                alert('NO PERMISSION');
                return;
            }
            var appReleaseDate_Long = data['appReleaseDate'];
            if (appReleaseDate_Long != null && appReleaseDate_Long != 'null') {
                var appReleaseDate_Date = new Date(appReleaseDate_Long).format('yyyy-MM-dd h:m:s');
                if (is_global == 'True'){
                    $('td', row).eq(8).html(appReleaseDate_Date);
                }else{
                    $('td', row).eq(7).html(appReleaseDate_Date);
                }

            }

            var on_shelf_Y = '<span style="width:60px" class="label label-sm label-success">已上架</span>';
            var on_shelf_N = '<span style="width:60px" class="label label-sm label-warning">已下架</span>';
            var on_shelf_Unknown = '<span style="width:60px" class="label label-sm ">未知</span>';

            if (data['onShelf'] == 'Y') {
                $('td', row).eq(5).html(on_shelf_Y);
            } else if (data['onShelf'] == 'N'){
                $('td', row).eq(5).html(on_shelf_N);
            }else{
                $('td', row).eq(5).html(on_shelf_Unknown);
            }
        }
    })
}

function add_button(){
    if (is_global == 'True'){
        window.open(host+"/OAManager/upload_APP_message.html")
    } else {
        window.open(host+"/OAManager/upload_APP_message_mainland.html")
    }
}

function modify_button(){
    // var reg = new RegExp("(\.\d+\.[a-zA-Z])","g");
    // var value = field_value.replace(reg,"([.][\n]\d+[.][a-zA-Z])")
    $('#universal-title').html('<strong>修改APP列表信息操作</strong>');
    $('#universal-message').html('通过重复上传APP列表信息实现修改');
    $('#universal-modal').modal('show');
}

function show_value_detail(field_value){
    // var reg = new RegExp("(\.\d+\.[a-zA-Z])","g");
    // var value = field_value.replace(reg,"([.][\n]\d+[.][a-zA-Z])")
    $('#universal-title').html('<strong>详情</strong>');
    $('#universal-message').html(field_value);
    $('#universal-modal').modal('show');
}

function delete_service() {
    var device_id = $('#deviceId_d').val()
    $.ajax({
        url: "/factorydata/delFactoryDataInfo",
        type: "POST",
        dataType: "json",
        data: {
            deviceId: device_id
        },
        success: function (data) {
            $('#delete-modal').modal('hide')
            var data1 = eval(data);

            if (data1.result == 'true') {
                $('#universal-message').html("删除生产数据成功");
            } else {
                $('#universal-message').html("删除生产数据失败");
            }
            $('#universal-title').html('<strong>删除结果</strong>');
            $('#universal-modal').modal('show');
            if (data1.result == 'true') {
                var table_name = 'parent-table-info'.replace(/-/g, '_');
                window[table_name].row('.remove-tag').remove().draw(false)
            }
        },
        error: function (data) {
            alert("请登录");
        }
    })
}

Date.prototype.format = function (format) {
    var date = {
        "M+": this.getMonth() + 1,
        "d+": this.getDate(),
        "h+": this.getHours(),
        "m+": this.getMinutes(),
        "s+": this.getSeconds(),
        "q+": Math.floor((this.getMonth() + 3) / 3),
        "S+": this.getMilliseconds()
    };
    if (/(y+)/i.test(format)) {
        format = format.replace(RegExp.$1, (this.getFullYear() + '').substr(4 - RegExp.$1.length));
    }
    for (var k in date) {
        if (new RegExp("(" + k + ")").test(format)) {
            format = format.replace(RegExp.$1, RegExp.$1.length == 2 ? date[k] : ("00" + date[k]).substr(("" + date[k]).length));
        }
    }
    return format;
};

