/**
 * Created by yuzhijiang on 2017/11/8.
 */



$(document).ready(function () {
    load_search_result();



    $('.need-hover').hover(function () {
            $(this).addClass('divOver');
        }, function () {
            $(this).removeClass('divOver');
        }
    );

    //点击事件
    $('#parent-table-info').on('click', "tr", function () {
        if ($(this).is('.even') || $(this).is('.odd')) {
            var appKey = $(this).find('.appKey').text().trim();
            if (appKey == 'null' || appKey.length == 0) {
                $('#universal-title').html('<strong>无法查看该新设备APP连接的详细信息</strong>');
                $('#universal-message').html('请补充AppKey字段信息。<br/>');
                $('#universal-modal').modal('show')
                return
            }
            var accountId = $(this).find('.accountId').text().trim();
            if (accountId == 'null' || accountId.length == 0) {
                $('#universal-title').html('<strong>无法查看该新设备APP连接的详细信息</strong>');
                $('#universal-message').html('请补充账户ID字段信息。<br/>');
                $('#universal-modal').modal('show')
                return
            }
            var $tr = $(this);
            var table_name1 = 'parent-table-info'.replace(/-/g, '_');
            var row = window[table_name1].row($tr);

            if (row.child.isShown()) {
                row.child.hide();
                $tr.removeClass('shown');
            } else {
                $.ajax({
                    url: "/app/getAppNewLinkExtraInfo",
                    type: "POST",
                    dataType: "json",
                    data: {
                        appKey: appKey
                    },
                    success: function (data) {
                        var data1 = eval(data);

                        row.child(data1.html).show();
                        $tr.addClass('shown');
                    },
                    error: function (data) {
                        alert("FAILED.");
                    }
                })
            }
        }
    });


    $('#start-time').datepicker({
        format: "yyyy-mm-dd",
        autoclose: true
    });

    $('#end-time').datepicker({
        format: "yyyy-mm-dd",
        autoclose: true
    });
});

function load_search_result() {
    var columns = columns_priority;

    $.fn.dataTable.ext.errMode = 'none';
    $('#parent-table-info').dataTable().fnClearTable(false);
    $('#parent-table-info').dataTable().fnDestroy();

    var account_id = document.getElementById("account-id-search").value;
    var app_key = document.getElementById("app-key-search").value;
    var package_name = document.getElementById("package-name-search").value;

    var table_name = 'parent-table-info'.replace(/-/g, '_');

    var post_data = {
            accountId: account_id,
            packageName: package_name,
            appKey: app_key,
        };



    window[table_name] = $('#parent-table-info').on('error.dt', function (e, settings, techNote, message) {
        console.log('An error has been reported by DataTables: ', message);
        $('#universal-title').html('<strong>新设备APP连接信息查询结果</strong>');
        $('#universal-message').html('新设备APP连接信息查询失败。<br/>请稍后重试或请登录！');
        $('#universal-modal').modal('show')
    }).DataTable({
        "lengthChange": true,
        "autoWidth": false,
        "processing": false,
        "paging": true,
        "searching": false,
        "ordering": false,
        "Info": true,
        "serverSide": false,
        "stripeClasses": ['odd parent-tr', 'even  parent-tr'],

        "lengthMenu": [[10, 15, 50, 100], [10, 15, 50, 100]],
        "order": [[0, 'asc']],
        "oLanguage": {
            "oAria": {
                "sSortAscending": " - click/return to sort ascending",
                "sSortDescending": " - click/return to sort descending"
            },
            "sLengthMenu": "显示 _MENU_ 记录",
            "sZeroRecords": "对不起，查询结果中无相关数据",
            "sEmptyTable": "未有相关数据，请重新输入查询条件",
            "sLoadingRecords": "正在加载数据-请等待...",
            "sInfo": "当前显示 _START_ 到 _END_ 条，共 _TOTAL_ 条记录。",
            "sInfoEmpty": "当前显示0到0条，共0条记录",
            "sInfoFiltered": "（数据库中共为 _MAX_ 条记录）",
            "sProcessing": "正在加载数据...",
            "sSearch": "搜索：",
            "sUrl": "",
            "oPaginate": {
                "sFirst": "首页",
                "sPrevious": " 上一页 ",
                "sNext": " 下一页 ",
                "sLast": " 尾页 "
            }
        },

        "ajax": {
            url: "/app/readAppNewLinkInfo",
            type: "POST",
            dataType: "json",
            data: post_data
        },
        "columns": columns,
        "createdRow": function (row, data, index) {
            if (data['authority'] == 'no permission'){
                alert('NO PERMISSION')
                return;
            }

            var online_N = '<span style="width:60px" class="label label-sm label-warning">离线</span>';
            var online_Y = '<span style="width:60px" class="label label-sm label-success">在线</span>';
            var online_Unknown = '<span style="width:60px" class="label label-sm ">未知</span>';
            if (data['online'] == 'Y') {
                $('td', row).eq(4).html(online_Y);

            } else if (data['online'] == 'N'){
                $('td', row).eq(4).html(online_N);
            } else {
                $('td', row).eq(4).html(online_Unknown);
            }

            var lastLoginDate_Long = data['lastLoginDate'];
            if (lastLoginDate_Long != null && lastLoginDate_Long != '-') {
                var lastLoginDate_Date = new Date(lastLoginDate_Long).format('yyyy-MM-dd  h:m:s')
                $('td', row).eq(7).html(lastLoginDate_Date);
            }

        },
    })
}

function add_button(){
    if (is_global == 'True'){
        window.open(host+"/OAManager/fw_file_upload.html")
    } else {
        window.open(host+"/OAManager/oaclient.html")
    }
}

function show_value_detail(value){
    $('#universal-title').html('<strong>详情</strong>');
    $('#universal-message').html(value);
    // $('#textarea-input').html(value);
    $('#universal-modal').modal('show');
}

Date.prototype.format = function (format) {
    var date = {
        "M+": this.getMonth() + 1,
        "d+": this.getDate(),
        "h+": this.getHours(),
        "m+": this.getMinutes(),
        "s+": this.getSeconds(),
        "q+": Math.floor((this.getMonth() + 3) / 3),
        "S+": this.getMilliseconds()
    };
    if (/(y+)/i.test(format)) {
        format = format.replace(RegExp.$1, (this.getFullYear() + '').substr(4 - RegExp.$1.length));
    }
    for (var k in date) {
        if (new RegExp("(" + k + ")").test(format)) {
            format = format.replace(RegExp.$1, RegExp.$1.length == 2 ? date[k] : ("00" + date[k]).substr(("" + date[k]).length));
        }
    }
    return format;
};

