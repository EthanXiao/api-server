/**
 * Created by yuzhijiang on 2017/11/8.
 */


$(document).ready(function () {
    load_search_result();

        //点击事件
    $('#parent-table-info').on('click', "tr", function () {
        return;
        if ($(this).is('.even') || $(this).is('.odd')) {

            var taskId = $(this).find('.taskId').text().trim();
            if (taskId == 'null' || taskId.length == 0) {
                $('#universal-title').html('<strong>无法查看该APP发布任务详细信息</strong>');
                $('#universal-message').html('请补充任务ID字段信息。<br/>');
                $('#universal-modal').modal('show')
                return
            }
            var $tr = $(this);
            var table_name1 = 'parent-table-info'.replace(/-/g, '_');
            var row = window[table_name1].row($tr);

            if (row.child.isShown()) {
                row.child.hide();
                $tr.removeClass('shown');
            } else {
                $.ajax({
                    url: "/firmware/getFirmwareReleaseTaskExtraInfo",
                    type: "POST",
                    dataType: "json",
                    data: {
                        taskId: taskId
                    },
                    success: function (data) {
                        var data1 = eval(data);

                        row.child(data1.html).show();
                        $tr.addClass('shown');
                    },
                    error: function (data) {
                        alert("FAILED.");
                    }
                })
            }
        }
    });

    $('.need-hover').hover(function () {
            $(this).addClass('divOver');
        }, function () {
            $(this).removeClass('divOver');
        }
    );

});

function load_search_result() {
    var columns = columns_priority;

    $.fn.dataTable.ext.errMode = 'none';
    $('#parent-table-info').dataTable().fnClearTable(false);
    $('#parent-table-info').dataTable().fnDestroy();

    var package_name = document.getElementById("package-name-search").value;



    var table_name = 'parent-table-info'.replace(/-/g, '_');

    window[table_name] = $('#parent-table-info').on('error.dt', function (e, settings, techNote, message) {
        console.log('An error has been reported by DataTables: ', message);
        $('#universal-title').html('<strong>固件发布任务信息查询结果</strong>');
        $('#universal-message').html('固件发布任务信息查询失败。<br/>请稍后重试或请登录！');
        $('#universal-modal').modal('show')
    }).DataTable({
        "lengthChange": true,
        "autoWidth": false,
        "processing": false,
        "paging": true,
        "searching": false,
        "ordering": false,
        "Info": true,
        "serverSide": true,
        "stripeClasses": ['odd parent-tr', 'even  parent-tr'],

        "lengthMenu": [[10,15, 50, 100], [10,15, 50, 100]],
        "order": [[0, 'asc']],
        "oLanguage": {
            "oAria": {
                "sSortAscending": " - click/return to sort ascending",
                "sSortDescending": " - click/return to sort descending"
            },
            "sLengthMenu": "显示 _MENU_ 记录",
            "sZeroRecords": "对不起，查询结果中无相关数据",
            "sEmptyTable": "未有相关数据，请重新输入查询条件",
            "sLoadingRecords": "正在加载数据-请等待...",
            "sInfo": "当前显示 _START_ 到 _END_ 条，共 _TOTAL_ 条记录。",
            "sInfoEmpty": "当前显示0到0条，共0条记录",
            "sInfoFiltered": "（数据库中共为 _MAX_ 条记录）",
            "sProcessing": "正在加载数据...",
            "sSearch": "搜索：",
            "sUrl": "",
            "oPaginate": {
                "sFirst": "首页",
                "sPrevious": " 上一页 ",
                "sNext": " 下一页 ",
                "sLast": " 尾页 "
            }
        },

        "ajax": {
            url: "/app/readAppReleaseTaskInfo",
            type: "POST",
            dataType: "json",
            data: {
                packageName: package_name
            }

        },
        "columns": columns,
        "createdRow": function (row, data, index) {
            if (data['authority'] == 'no permission') {
                alert('NO PERMISSION')
                return;
            }
            var status_finished = '<span style="width:60px" class="label label-sm label-success">推送结束</span>';
            var status_disabled = '<span style="width:60px" class="label label-sm">无法推送</span>';
            var status_pushing = '<span style="width:60px" class="label label-sm label-warning">正在推送</span>';
            var status_ready = '<span style="width:60px" class="label label-sm label-info">等待推送</span>';
            if (data['statusCode'] == 1 || data['statusCode'] == '1') {
                $('td', row).eq(3).html(status_finished);
            } else if (data['statusCode'] == -1 || data['statusCode'] == '-1') {
                $('td', row).eq(3).html(status_disabled);
            } else if (data['statusCode'] == 2 || data['statusCode'] == '2') {
                $('td', row).eq(3).html(status_pushing);
            } else {
                $('td', row).eq(3).html(status_ready);
            }
        }
    })
}

function add_button(){

    if (is_global == 'True'){
        window.open(host+"/OAManager/APP_pub_task_message.html");
    } else {
        window.open(host+"/OAManager/APP_pub_task_message_mainland.html");
    }


    // $('#add-modal').modal('show')
}

function revoke_button(){
    if (is_global == 'True'){
        window.open(host+"/OAManager/APP_undercarriage.html");
    } else {
        window.open(host+"/OAManager/APP_undercarriage_mainland.html");
    }
}
Date.prototype.format = function (format) {
    var date = {
        "M+": this.getMonth() + 1,
        "d+": this.getDate(),
        "h+": this.getHours(),
        "m+": this.getMinutes(),
        "s+": this.getSeconds(),
        "q+": Math.floor((this.getMonth() + 3) / 3),
        "S+": this.getMilliseconds()
    };
    if (/(y+)/i.test(format)) {
        format = format.replace(RegExp.$1, (this.getFullYear() + '').substr(4 - RegExp.$1.length));
    }
    for (var k in date) {
        if (new RegExp("(" + k + ")").test(format)) {
            format = format.replace(RegExp.$1, RegExp.$1.length == 2 ? date[k] : ("00" + date[k]).substr(("" + date[k]).length));
        }
    }
    return format;
};

