/**
 * Created by yuzhijiang on 2017/11/16.
 */



$(document).ready(function () {
    load_search_result();
    $("#table-account-info").on("click", ".edit-job-button", function (e) {
        e.stopPropagation();
        var table_name = 'table-account-info'.replace(/-/g, '_');
        window[table_name].$('tr.modify-tag').removeClass('modify-tag');
        $(this).parents('tr').addClass('modify-tag');
        var name = $(this).parents('tr').find('.name').text().trim();
        var code = $(this).parents('tr').find('.code').text().trim();
        var authorityId = $(this).parents('tr').find('.authorityId').text().trim();
        var note = $(this).parents('tr').find('.note').text().trim();
        var version = $(this).parents('tr').find('.version').text().trim();
        $("#name_m").val(name);
        $("#authorityId_m").val(authorityId);
        $("#authorityId_m").attr("disabled", "disabled");
        $("#note_m").val(note);
        $("#code_m").val(code);
        $("#version_m").val(version)

        $('#modify_account').modal('show')
    });

    $("#table-account-info").on("click", ".delete-job-button", function (e) {
        e.stopPropagation()
        var table_name = 'table-account-info'.replace(/-/g, '_');
        window[table_name].$('tr.remove-tag').removeClass('remove-tag');
        $(this).parents('tr').addClass('remove-tag');
        var authorityId = $(this).parents('tr').find('.authorityId').text().trim();
        var code = $(this).parents('tr').find('.code').text().trim();
        var name = $(this).parents('tr').find('.name').text().trim();
        var version = $(this).parents('tr').find('.version').text().trim();
        $('#authorityId_d').val(authorityId);
        $('#name_d').val(name);
        $('#code_d').val(code);
        $('#version_d').val(version);
        $('#delete_job').modal('show')
    });

    $('.need-hover').hover(function () {
            $(this).addClass('divOver');
        }, function () {
            $(this).removeClass('divOver');
        }
    );

});

function load_search_result() {

    columns = [
        {
            data: 'authorityId',
            className: 'authorityId',
            width: '10%'
        },

        {
            data: 'name',
            className: 'name',
            width: '17%'
        },
        {
            data: 'code',
            className: 'code',
            width: '14%'
        },
        {
            data: 'note',
            className: 'note',
            width: '18%'
        },
        {
            data: 'version',
            className: 'version',
            width: '10%'
        },

        // {#                         {% if admin == 1 %}#}
        {
            data: 'operation',
            className: 'operation',
            orderable: false,
            width: '8%',
            defaultContent: '<div class="visible-md visible-lg hidden-sm hidden-xs btn-group">' +

            '<button class="btn btn-xs btn-info edit-job-button">' +
            '<i class="icon-edit bigger-120"></i>' +
            '</button>' +
            '<button class="btn btn-xs btn-danger delete-job-button" >' +
            '<i class="icon-trash bigger-120"></i>' +
            '</button>' +
            '</div>'
        },
        // {#                         {% endif %}#}
    ];

    $.fn.dataTable.ext.errMode = 'none';
    $('#table-account-info').dataTable().fnClearTable();
    $('#table-account-info').dataTable().fnDestroy();

    var table_name = 'table-account-info'.replace(/-/g, '_');

    window[table_name] = $('#table-account-info').on('error.dt', function (e, settings, techNote, message) {
        console.log('An error has been reported by DataTables: ', message);
        $('#universal-title').html('<strong>权限信息查询结果</strong>');
        $('#universal-message').html('权限信息查询失败。<br/>请稍后重试或请登录！');
        $('#universal-modal').modal('show')
    }).DataTable({
        "lengthChange": true,
        "autoWidth": false,
        "processing": false,
        "paging": true,
        "searching": true,
        "ordering": true,
        "Info": true,
        "lengthMenu": [[10, 15, 30, 50], [10, 15, 30, 50]],
        "order": [[0, 'asc']],
        "oLanguage": {
            "oAria": {
                "sSortAscending": " - click/return to sort ascending",
                "sSortDescending": " - click/return to sort descending"
            },
            "sLengthMenu": "显示 _MENU_ 记录",
            "sZeroRecords": "对不起，查询结果中无相关数据",
            "sEmptyTable": "未有相关数据",
            "sLoadingRecords": "正在加载数据-请等待...",
            "sInfo": "当前显示 _START_ 到 _END_ 条，共 _TOTAL_ 条记录。",
            "sInfoEmpty": "当前显示0到0条，共0条记录",
            "sInfoFiltered": "（数据库中共为 _MAX_ 条记录）",
            "sProcessing": "正在加载数据...",
            "sSearch": "搜索：",
            "sUrl": "",
            "oPaginate": {
                "sFirst": "首页",
                "sPrevious": " 上一页 ",
                "sNext": " 下一页 ",
                "sLast": " 尾页 "
            }
        },

        "ajax": {
            url: "/webManager/readAuthorityInfo",
            type: "POST",
            dataType: "json",
            data: {},

        },
        "columns": columns,
        "createdRow": function (row, data, index) {
            var status_normal = '<span style="width:56px" class="label label-sm label-success">NORMAL</span>';
            var status_abnormal = '<span style="width:56px" class="label label-sm label-unknow">INACTIVE</span>';
            if (data['status'] == 'NORMAL') {
                $('td', row).eq(2).html(status_normal);
            } else if (data['status'] == 'INACTIVE') {
                $('td', row).eq(2).html(status_abnormal);
            }
        }

    })
}

function open_scan_task_modal() {
    $('#scan_set').modal('show')
}

function scan_set() {
    $("#scan_time_form").submit();
}

function create_account() {
    $('#add_account').modal('show');
}

function add_service() {
    var authorityId = $('#authorityId_a').val()
    if (authorityId == "" || authorityId == null) {
        $("#build_error_authorityId_e").css("display", "block")
        setTimeout(function () {
            $("#build_error_authorityId_e").css("display", "none");
        }, 2000);
        return;
    }

    var code = $('#code_a').val()
    if (code == "" || code == null) {
        $("#build_error_code_e").css("display", "block")
        setTimeout(function () {
            $("#build_error_code_e").css("display", "none");
        }, 2000);
        return;
    }

    var note = $('#note_a').val()
    if (note == "" || note == null) {
        $("#build_error_note_e").css("display", "block")
        setTimeout(function () {
            $("#build_error_note_e").css("display", "none");
        }, 2000);
        return;
    }
    var name = ($("#name_a").val().trim())
    var version = $("#version_a").val().trim()
    $.ajax({
        url: "/webManager/addAuthorityInfo",
        type: "POST",
        dataType: "json",
        data: {
            authorityId: authorityId,
            name: name,
            code: code,
            note: note,
            version: version,
        },
        success: function (data) {
            var data1 = eval(data)
            $('#universal-title').html('<strong>添加权限信息</strong>')

            if (data1.result == 'true') {
                load_search_result();
                $('#universal-message').html("添加权限信息成功");
            } else {
                $('#universal-message').html("添加权限信息失败");
            }
            $('#add_account').modal('hide');
            $('#universal-modal').modal('show');


        },
        error: function (data) {
            console.log("请登录")
            alert("请登录");
        }
    })
}

function modify_service() {
    var name = $("#name_m").val().trim();
    var code = $("#code_m").val().trim();
    var note = $("#note_m").val().trim();
    var authorityId = $('#authorityId_m').val().trim();
    var version = $("#version_m").val().trim();
    $.ajax({
        url: "/webManager/modifyAuthorityInfo",
        type: "POST",
        dataType: "json",
        data: {
            name: name,
            code: code,
            note: note,
            authorityId: authorityId,
            version: parseInt(version) + 1,
        },
        success: function (data) {
            var data1 = eval(data)
            $('#universal-title').html('<strong>修改权限信息</strong>')

            if (data1.result == 'true') {
                $('#universal-message').html("修改权限信息成功");
            } else {
                $('#universal-message').html("修改权限信息失败");
            }
            $('#modify_account').modal('hide');
            $('#universal-modal').modal('show');
            if (data1.result == 'true') {
                //job_name = 'scan-' + service_region + '-cloud-' + service_name
                $('#table-account-info').find('.modify-tag').find('.name').html(name)
                $('#table-account-info').find('.modify-tag').find('.code').html(code)
                $('#table-account-info').find('.modify-tag').find('.note').html(note)
                $('#table-account-info').find('.modify-tag').find('.authorityId').html(authorityId)
                $('#table-account-info').find('.modify-tag').find('.version').html(parseInt(version) + 1)
            }
        },
        error: function (data) {
            alert("请登录");
        }
    })
}


function delete_service() {
    var authorityId = $('#authorityId_d').val()
    var version = $('#version_d').val()
    $.ajax({
        url: "/webManager/delAuthorityInfo",
        type: "POST",
        dataType: "json",
        data: {
            authorityId: authorityId,
            version: version
        },
        success: function (data) {
            $('#delete_job').modal('hide')
            var data1 = eval(data)

            if (data1.result == 'true') {
                $('#universal-message').html("删除权限成功");
            } else {
                $('#universal-message').html("删除权限失败");
            }
            $('#universal-title').html('<strong>删除结果</strong>');
            $('#universal-modal').modal('show');
            if (data1.result == 'true') {
                var table_name = 'table-account-info'.replace(/-/g, '_');
                window[table_name].row('.remove-tag').remove().draw(false)
            }
        },
        error: function (data) {
            alert("请登录");
        }
    })
}
