/**
 * Created by yuzhijiang on 2017/11/16.
 */


$(document).ready(function() {
     load_search_result();
     $("#table-account-info").on("click", ".edit-job-button", function(e){
          e.stopPropagation();
          var table_name = 'table-account-info'.replace(/-/g, '_');
          window[table_name].$('tr.modify-tag').removeClass('modify-tag');
          $(this).parents('tr').addClass('modify-tag');
          email = $(this).parents('tr').find('.email').text().trim();
          userId= $(this).parents('tr').find('.userId').text().trim();
          name= $(this).parents('tr').find('.name').text().trim();
          roleId = $(this).parents('tr').find('.roleId').text().trim();
          $("#email_m").val(email)
          $("#userId_m").val(userId)
          $("#name_m").val(name)
          $("#roleId_m").val(roleId)

          $('#modify_account').modal('show')
      });

    $("#table-account-info").on("click", ".delete-job-button", function(e){
          e.stopPropagation()
          var table_name = 'table-account-info'.replace(/-/g, '_');
          window[table_name].$('tr.remove-tag').removeClass('remove-tag');
          $(this).parents('tr').addClass('remove-tag');
          var userId = $(this).parents('tr').find('.userId').text().trim();
          var email = $(this).parents('tr').find('.email').text().trim();
          var roleId = $(this).parents('tr').find('.roleId').text().trim();
          var name = $(this).parents('tr').find('.name').text().trim();
          $('#userId_d').val(userId);
          $('#name_d').val(name);
          $('#email_d').val(email);
          $('#roleId_d').val(roleId);
          $('#delete_job').modal('show')
    });



    $('.need-hover').hover(function(){
          $(this).addClass('divOver');
        },function(){
            $(this).removeClass('divOver');
        }
     );

    //点击事件
    $('#table-account-info').on('click', "tr", function () {
                    if ($(this).is('.even') || $(this).is('.odd')) {
                        var roleId = $(this).find('.roleId').text().trim();
                        if (roleId == 'null' || roleId.length == 0) {
                            return
                        }
                        var $tr = $(this);
                        var table_name1 = 'table-account-info'.replace(/-/g, '_');
                        var row = window[table_name1].row($tr);
                        if (row.child.isShown()) {
                            row.child.hide();
                            $tr.removeClass('shown');
                        } else {
                            $.ajax({
                                url: "/webManager/getUserExtraInfo",
                                type: "POST",
                                dataType: "json",
                                data: {
                                    roleId: roleId
                                },
                                success: function (data) {
                                    var data1 = eval(data);
                                    row.child(data1.html).show();
                                    $tr.addClass('shown');
                                },
                                error: function(data){
                                    alert("FAILED.");
                                }
                            })
                        }
                    }
                });
});

function load_search_result(){
        columns = [
                     {
                         data : 'userId',
                         className: 'userId',
                         width: '10%'
                     },

                     {
                         data : 'email',
                         className: 'email',
                         width: '17%'
                     },
                    {
                         data : 'name',
                         className: 'name',
                         width: '12%'
                     },

                    {
                         data : 'roleId',
                         className: 'roleId',
                         width: '10%'
                     },

// {#                         {% if admin == 1 %}#}
                    {
                        data : 'operation',
                        className: 'operation',
                        orderable:false,
                         width: '8%',
                        defaultContent: '<div class="visible-md visible-lg hidden-sm hidden-xs btn-group">'+

                                            '<button class="btn btn-xs btn-info edit-job-button">'+
                                                '<i class="icon-edit bigger-120"></i>'+
                                            '</button>'+
                                            '<button class="btn btn-xs btn-danger delete-job-button" >'+
                                                '<i class="icon-trash bigger-120"></i>'+
                                            '</button>'+

                                        '</div>'
                    },
// {#                         {% endif %}#}
                ];

    $.fn.dataTable.ext.errMode = 'none';
    $('#table-account-info').dataTable().fnClearTable(false);
    $('#table-account-info').dataTable().fnDestroy();

    var email = document.getElementById("email_search").value;

    var table_name = 'table-account-info'.replace(/-/g, '_');

    if (is_global == 'True'){
        window[table_name] = $('#table-account-info').on('error.dt', function (e, settings, techNote, message) {
                    console.log( 'An error has been reported by DataTables: ', message );
                    $('#universal-title').html('<strong>用户信息查询结果</strong>');
                    $('#universal-message').html('用户信息查询失败。<br/>请稍后重试！');
                    $('#universal-modal').modal('show')
                }).DataTable({

                "lengthChange": true,
                "autoWidth": false,
                "processing": false,
                "paging": true,
                "searching": false,
                "ordering": false,
                "Info": true,
                "serverSide":true,
                "lengthMenu": [[10,15, 50, 100], [10,15, 50, 100]],
                "order": [[0, 'asc']],
                "oLanguage": {
                    "oAria": {
                        "sSortAscending": " - click/return to sort ascending",
                        "sSortDescending": " - click/return to sort descending"
                    },
                    "sLengthMenu": "显示 _MENU_ 记录",
                    "sZeroRecords": "对不起，查询结果中无相关数据",
                    "sEmptyTable": "未有相关数据，请输入查询条件",
                    "sLoadingRecords": "正在加载数据-请等待...",
                    "sInfo": "当前显示 _START_ 到 _END_ 条，共 _TOTAL_ 条记录。",
                    "sInfoEmpty": "当前显示0到0条，共0条记录",
                    "sInfoFiltered": "（数据库中共为 _MAX_ 条记录）",
                    "sProcessing": "正在加载数据...",
                    "sSearch": "搜索：",
                    "sUrl": "",
                    "oPaginate": {
                        "sFirst": "首页",
                        "sPrevious": " 上一页 ",
                        "sNext": " 下一页 ",
                        "sLast": " 尾页 "
                    }
                },

                "ajax": {
                    url: "/webManager/readUserRoleInfo",
                    type: "POST",
                    dataType: "json",
                    data: {
                        email: email
                    },

                },
               "columns":columns

            })
    }else {
        window[table_name] = $('#table-account-info').on('error.dt', function (e, settings, techNote, message) {
                    console.log( 'An error has been reported by DataTables: ', message );
                    $('#universal-title').html('<strong>用户信息查询结果</strong>');
                    $('#universal-message').html('用户信息查询失败。<br/>请稍后重试！');
                    $('#universal-modal').modal('show')
                }).DataTable({

                "lengthChange": true,
                "autoWidth": false,
                "processing": false,
                "paging": true,
                "searching": false,
                "ordering": false,
                "Info": true,
                "serverSide":false,
                "lengthMenu": [[10,15, 50, 100], [10,15, 50, 100]],
                "order": [[0, 'asc']],
                "oLanguage": {
                    "oAria": {
                        "sSortAscending": " - click/return to sort ascending",
                        "sSortDescending": " - click/return to sort descending"
                    },
                    "sLengthMenu": "显示 _MENU_ 记录",
                    "sZeroRecords": "对不起，查询结果中无相关数据",
                    "sEmptyTable": "未有相关数据",
                    "sLoadingRecords": "正在加载数据-请等待...",
                    "sInfo": "当前显示 _START_ 到 _END_ 条，共 _TOTAL_ 条记录。",
                    "sInfoEmpty": "当前显示0到0条，共0条记录",
                    "sProcessing": "正在加载数据...",
                    "sSearch": "搜索：",
                    "sUrl": "",
                    "oPaginate": {
                        "sFirst": "首页",
                        "sPrevious": " 上一页 ",
                        "sNext": " 下一页 ",
                        "sLast": " 尾页 "
                    }
                },

                "ajax": {
                    url: "/webManager/readUserRoleInfo",
                    type: "POST",
                    dataType: "json",
                    data: {
                        email: email
                    },

                },
               "columns":columns

            })
    }


}

function create_account(){
   //ini_modal_data()
   $('#add_account').modal('show');

}

function add_service_account(){

var email = $('#email_a').val()
if (email == "" || email == null) {
    $("#build_error_email_e").css("display", "block")
    setTimeout(function(){ $("#build_error_email_e").css("display", "none");},2000);
    return;
}

var password = $('#password_a').val()
if (password == "" || password == null) {
    $("#build_error_password_e").css("display", "block")
    setTimeout(function(){ $("#build_error_password_e").css("display", "none");},2000);
    return;
}

var password_again = $('#password_again_a').val()
if (password_again== "" || password_again == null) {
    $("#build_error_password_again_e").css("display", "block")
    setTimeout(function () {
        $("#build_error_password_again_e").css("display", "none");
    }, 2000);
    return;
}
if (password_again != password) {
    $("#build_error_password_wrong_e").css("display", "block")
    setTimeout(function(){ $("#build_error_password_wrong_e").css("display", "none");},2000);
    return;
}

 var name= $('#username_a').val().trim();
 var roleId= $('#roleId_a').val().trim();
$.ajax({
    url:"/webManager/addUserRoleInfo",
    type:"POST",
    dataType:"json",
    data:{
        email: email,
        password:password,
        passwordAgain:password_again,
        name: name,
        roleId:roleId
    },
    success:function(data){
        var data1 = eval(data)
        $('#universal-title').html('<strong>添加新用户</strong>')

        if (data1.result == 'true'){
            $('#universal-message').html("添加新用户成功");
        } else {
            $('#universal-message').html("添加新用户失败");
        }

        $('#add_account').modal('hide');
        $('#universal-modal').modal('show');
        load_search_result();
    },
    error:function(data){
        console.log("请登录");
        alert("请登录");
    }
})
}

function modify_service_account() {
 var email = $("#email_m").val().trim();
 var name= $('#name_m').val().trim();

 var roleId= $('#roleId_m').val().trim();
 var userId = $('#userId_m').val().trim();
$.ajax({
    url:"/webManager/modifyUserRoleInfo",
    type:"POST",
    dataType:"json",
    data:{
        email: email,
        name: name,
        userId: userId,
        roleId: roleId,
    },
    success:function(data){
        var data1 = eval(data)
        $('#universal-title').html('<strong>修改用户信息</strong>');

        if (data1.result == 'true'){
            $('#universal-message').html("修改用户信息成功");
        }else{
            $('#universal-message').html("修改用户信息失败");
        }
        $('#modify_account').modal('hide');
        $('#universal-modal').modal('show');
        if(data1.result == 'true'){
            //job_name = 'scan-' + service_region + '-cloud-' + service_name
            $('#table-account-info').find('.modify-tag').find('.email').html(email)
            $('#table-account-info').find('.modify-tag').find('.name').html(name)
            $('#table-account-info').find('.modify-tag').find('.userId').html(userId)
            $('#table-account-info').find('.modify-tag').find('.roleId').html(roleId)
        }
    },
    error:function(data){
        alert("请登录");
    }
})
}

function delete_service_job() {
var name = $('#name_d').val()
 var email = $('#email_d').val()
 var roleId = $('#roleId_d').val()
 var userId = $('#userId_d').val()
$.ajax({
    url:"/webManager/delUserRoleInfo",
    type:"POST",
    dataType:"json",
    data:{
        name: name,
        roleId:roleId,
        email:email,
        userId:userId
    },
    success:function(data){
        $('#delete_job').modal('hide')
        var data1 = eval(data)

        if (data1.result == 'true'){
            $('#universal-message').html("删除用户成功");
        }else{
            $('#universal-message').html("删除用户失败");
        }
        $('#universal-title').html('<strong>删除结果</strong>')
        $('#universal-modal').modal('show')
        if(data1.result == 'true'){
            var table_name = 'table-account-info'.replace(/-/g, '_');
            window[table_name].row('.remove-tag').remove().draw(false)
        }
    },
    error:function(data){
        alert("请登录");
    }
})
}

