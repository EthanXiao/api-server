/**
 * Created by yuzhijiang on 2017/12/26.
 */

var host = 'http://54.223.66.28:10880';