/**
 * Created by yuzhijiang on 2017/12/26.
 */

var host = 'http://172.29.88.117:10880';