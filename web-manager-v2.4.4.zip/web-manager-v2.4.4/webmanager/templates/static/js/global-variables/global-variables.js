/**
 * Created by yuzhijiang on 2017/12/26.
 */

var host = 'http://172.31.1.153:10880';