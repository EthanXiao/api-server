/**
 * Created by yuzhijiang on 2017/12/26.
 */

var host = 'http://cmgt-oa-beta.tplinkcloud.com:10880';