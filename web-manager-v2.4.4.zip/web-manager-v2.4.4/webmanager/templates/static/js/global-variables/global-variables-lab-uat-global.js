/**
 * Created by yuzhijiang on 2017/12/26.
 */

var host = 'http://222.9.9.83:10880';