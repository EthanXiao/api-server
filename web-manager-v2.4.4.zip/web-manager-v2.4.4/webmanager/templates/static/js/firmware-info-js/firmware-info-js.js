/**
 * Created by yuzhijiang on 2017/11/8.
 */



$(document).ready(function () {
    load_search_result();
    $("#parent-table-info").on("click", ".edit-job-button", function (e) {
        e.stopPropagation();
        var table_name = 'parent-table-info'.replace(/-/g, '_');
        window[table_name].$('tr.modify-tag').removeClass('modify-tag');
        $(this).parents('tr').addClass('modify-tag');
        var firmware_id = $(this).parents('tr').find('.firmwareId').text().trim();

        if (firmware_id == 'null' || firmware_id.length == 0) {
            $('#universal-title').html('<strong>无法编辑</strong>');
            $('#universal-message').html('请补充固件ID字段信息。<br/>');
            $('#universal-modal').modal('show')
            return
        }

        $.ajax({
            url: "/firmware/readTargetEditingFirmwareInfo",
            type: "POST",
            dataType: "json",
            data: {
                firmwareId: firmware_id
            },
            success: function (data) {
                $('#modify-modal-body').html(data.html);
                $('#modify-modal').modal('show')
            },
            error: function (data) {
                alert("FAILED.");
            }
        })
    });

    $("#parent-table-info").on("click", ".delete-job-button", function (e) {
        e.stopPropagation()
        var table_name = 'parent-table-info'.replace(/-/g, '_');
        window[table_name].$('tr.remove-tag').removeClass('remove-tag');
        $(this).parents('tr').addClass('remove-tag');
        var device_id = $(this).parents('tr').find('.deviceId').text().trim();
        var mac = $(this).parents('tr').find('.mac').text().trim();
        var sn = $(this).parents('tr').find('.sn').text().trim();
        $('#deviceId_d').val(device_id);
        $('#mac_d').val(mac);
        $('#sn_d').val(sn);
        $('#delete-modal').modal('show')
    });


    $('.need-hover').hover(function () {
            $(this).addClass('divOver');
        }, function () {
            $(this).removeClass('divOver');
        }
    );

    //点击事件
    $('#parent-table-info').on('click', "tr", function () {
        if ($(this).is('.even') || $(this).is('.odd')) {

            var firmwareId = $(this).find('.firmwareId').text().trim();
            if (firmwareId == 'null' || firmwareId.length == 0) {
                $('#universal-title').html('<strong>无法查看该固件详细信息</strong>');
                $('#universal-message').html('请补充固件ID字段信息。<br/>');
                $('#universal-modal').modal('show')
                return
            }
            var $tr = $(this);
            var table_name1 = 'parent-table-info'.replace(/-/g, '_');
            var row = window[table_name1].row($tr);

            if (row.child.isShown()) {
                row.child.hide();
                $tr.removeClass('shown');
            } else {
                $.ajax({
                    url: "/firmware/getFirmwareExtraInfo",
                    type: "POST",
                    dataType: "json",
                    data: {
                        firmwareId: firmwareId
                    },
                    success: function (data) {
                        var data1 = eval(data);

                        row.child(data1.html).show();
                        $tr.addClass('shown');
                    },
                    error: function (data) {
                        alert("FAILED.");
                    }
                })
            }
        }
    });


    $('#start-time').datepicker({
        format: "yyyy-mm-dd",
        autoclose: true
    });

    $('#end-time').datepicker({
        format: "yyyy-mm-dd",
        autoclose: true
    });
});

function load_search_result() {
    var columns = columns_priority;

    $.fn.dataTable.ext.errMode = 'none';
    $('#parent-table-info').dataTable().fnClearTable(false);
    $('#parent-table-info').dataTable().fnDestroy();

    var firmware_id = document.getElementById("firmware-id-search").value;
    var firmware_version = document.getElementById("firmware-version-search").value;

    var file_name = document.getElementById("file-name-search").value;
    var protocol = document.getElementById("protocol-search").value;


    var table_name = 'parent-table-info'.replace(/-/g, '_');
    if (is_global == 'True'){
        var hw_id = document.getElementById("hw-id-search").value;
        var post_data = {
                firmwareId: firmware_id,
                firmwareVersion: firmware_version,
                fileName: file_name,
                protocol: protocol,
                hwId: hw_id
            }
    }else {
        var post_data = {
                firmwareId: firmware_id,
                firmwareVersion: firmware_version,
                fileName: file_name,
                protocol: protocol
            }
    }


    window[table_name] = $('#parent-table-info').on('error.dt', function (e, settings, techNote, message) {
        console.log('An error has been reported by DataTables: ', message);
        $('#universal-title').html('<strong>固件信息查询结果</strong>');
        $('#universal-message').html('固件信息查询失败。<br/>请稍后重试或请登录！');
        $('#universal-modal').modal('show')
    }).DataTable({
        "lengthChange": true,
        "autoWidth": false,
        "processing": false,
        "paging": true,
        "searching": false,
        "ordering": false,
        "Info": true,
        "serverSide": true,
        "stripeClasses": ['odd parent-tr', 'even  parent-tr'],

        "lengthMenu": [[10, 15, 50, 100], [10, 15, 50, 100]],
        "order": [[0, 'asc']],
        "oLanguage": {
            "oAria": {
                "sSortAscending": " - click/return to sort ascending",
                "sSortDescending": " - click/return to sort descending"
            },
            "sLengthMenu": "显示 _MENU_ 记录",
            "sZeroRecords": "对不起，查询结果中无相关数据",
            "sEmptyTable": "未有相关数据，请重新输入查询条件",
            "sLoadingRecords": "正在加载数据-请等待...",
            "sInfo": "当前显示 _START_ 到 _END_ 条，共 _TOTAL_ 条记录。",
            "sInfoEmpty": "当前显示0到0条，共0条记录",
            "sInfoFiltered": "（数据库中共为 _MAX_ 条记录）",
            "sProcessing": "正在加载数据...",
            "sSearch": "搜索：",
            "sUrl": "",
            "oPaginate": {
                "sFirst": "首页",
                "sPrevious": " 上一页 ",
                "sNext": " 下一页 ",
                "sLast": " 尾页 "
            }
        },

        "ajax": {
            url: "/firmware/readFirmwareInfo",
            type: "POST",
            dataType: "json",
            data: post_data
        },
        "columns": columns,
        "createdRow": function (row, data, index) {
            if (data['authority'] == 'no permission'){
                alert('NO PERMISSION')
                return;
            }
            if (is_global == 'True'){
                var on_shelf_Y = '<span style="width:60px" class="label label-sm label-warning">已召回</span>';
                var on_shelf_N = '<span style="width:60px" class="label label-sm label-success">未召回</span>';
                var on_shelf_Unknown = '<span style="width:60px" class="label label-sm ">未知</span>';
                if (data['revoked'] == 'Y') {
                    $('td', row).eq(7).html(on_shelf_Y);

                } else if (data['revoked'] == 'N'){
                    $('td', row).eq(7).html(on_shelf_N);
                }else{
                    $('td', row).eq(7).html(on_shelf_Unknown);
                }
            } else {
                var releaseDate_Long = data['releaseDate'];
                if (releaseDate_Long != null && releaseDate_Long != '-') {
                    var releaseDate_Date = new Date(releaseDate_Long).format('yyyy-MM-dd  h:m:s')
                    $('td', row).eq(4).html(releaseDate_Date);
                }
            }
        },
    })
}

function add_button(){
    if (is_global == 'True'){
        window.open(host+"/OAManager/fw_file_upload.html")
    } else {
        window.open(host+"/OAManager/oaclient.html")
    }
}

function show_value_detail(value){
    $('#universal-title').html('<strong>详情</strong>');
    $('#universal-message').html(value);
    // $('#textarea-input').html(value);
    $('#universal-modal').modal('show');
}

function add_service() {
    var device_list_a = $('#device_list_a').val().trim();
    var device_list = eval(device_list_a);

    if (device_list.length == 0) {
        $('#universal-title').html('<strong>添加失败</strong>');
        $('#universal-message').html('请输入生产数据<br/>');
        $('#add-modal').modal('hide');
        $('#universal-modal').modal('show');
        return
    }

    if (device_list.length > 50) {
        $('#universal-title').html('<strong>添加失败</strong>');
        $('#universal-message').html('一次最多添加50条生产数据<br/>');
        $('#add-modal').modal('hide');
        $('#universal-modal').modal('show')
        return
    }

    $.ajax({
        url: "/factorydata/addFactoryDataInfo",
        type: "POST",
        dataType: "json",
        data: {
            deviceList: device_list_a
        },
        success: function (data) {
            var data1 = eval(data);
            $('#universal-title').html('<strong>添加生产数据信息</strong>');
            if (data1.result == 'true') {
                $('#universal-message').html("添加设备生产数据信息成功");
            } else {
                $('#universal-message').html("添加设备生产数据信息失败");
            }
            $('#add-modal').modal('hide');
            $('#universal-modal').modal('show');
            var table_name1 = 'parent-table-info'.replace(/-/g, '_');
            window[table_name1].ajax.reload();

        },
        error: function (data) {
            console.log("请登录"),
            alert("请登录");
        }
    })
}

function modify_service() {
    var release_log = $("#releaseLog_m").val().trim();
    var firmware_id = $("#firmwareId_m").val().trim();

    $.ajax({
        url: "/firmware/modifyFirmwareInfo",
        type: "POST",
        dataType: "json",
        data: {
            releaseLog: release_log,
            firmwareId: firmware_id,
        },
        success: function (data) {
            var data1 = eval(data);
            $('#universal-title').html('<strong>修改固件发布日志</strong>');

            if (data1.result == 'true') {
                $('#universal-message').html("修改固件发布日志信息成功");
            } else {
                $('#universal-message').html("修改固件发布日志信息失败");
            }
            $('#modify-modal').modal('hide');
            $('#universal-modal').modal('show');
            if (data1.result == 'true') {
                var table_name1 = 'parent-table-info'.replace(/-/g, '_');
                window[table_name1].ajax.reload();
            }
        },
        error: function (data) {
            alert("请登录");
        }
    })
}

Date.prototype.format = function (format) {
    var date = {
        "M+": this.getMonth() + 1,
        "d+": this.getDate(),
        "h+": this.getHours(),
        "m+": this.getMinutes(),
        "s+": this.getSeconds(),
        "q+": Math.floor((this.getMonth() + 3) / 3),
        "S+": this.getMilliseconds()
    };
    if (/(y+)/i.test(format)) {
        format = format.replace(RegExp.$1, (this.getFullYear() + '').substr(4 - RegExp.$1.length));
    }
    for (var k in date) {
        if (new RegExp("(" + k + ")").test(format)) {
            format = format.replace(RegExp.$1, RegExp.$1.length == 2 ? date[k] : ("00" + date[k]).substr(("" + date[k]).length));
        }
    }
    return format;
};

