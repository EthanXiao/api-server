/**
 * Created by admin on 2017/11/16.
 */


// {#              $("#job_status_m").attr("disabled","disabled");#}

// {#     $('#search').on('click', function () {#}
// {#                $('#last_tag').html('false');#}
// {##}
// {#                    var table_name1 = 'table-account-info'.replace(/-/g, '_');#}
// {#                    accountId =$('#accountId_search').val().trim();#}
// {#                    load_search_result();#}
// {#                    window[table_name1].ajax.reload();#}
// {##}
// {#                var start_time = $('#start_time').val().trim();#}
// {#                var time1 = $('#detail_time').val().trim();#}
// {#                $('#update_time').html(date1 + ' ' + time1);#}
// {#                $('#update_region').html($("#region").val().trim());#}
// {#            });#}
//
// {#         $('#start_time').datepicker({#}
// {#                format: "yyyy-mm-dd",#}
// {#                autoclose: true#}
// {#            }).on('changeDate', function (e) {#}
// {#                $.ajax({#}
// {#                    url: "/woodpecker/check/getData/getTime",#}
// {#                    type: "GET",#}
// {#                    dataType: "json",#}
// {#                    data: {#}
// {#                        region: $('#region').val().trim(),#}
// {#                        time: e.date.format('yyyy-MM-dd  h:m:s')#}
// {#                    },#}
// {#                    success: function (data) {#}
// {#                        var data1 = eval(data);#}
// {#                        if (data1.status == 'success') {#}
// {#                            if (data1.info.length == 0) {#}
// {#                                $('#search').attr('disabled', 'disabled');#}
// {#                                modal_set('获取时间情况', '当日没有查询记录。');#}
// {#                                $('#detail_time').html('<option value="-">-</option>').trigger('change');#}
// {#                            } else {#}
// {#                                $('#search').removeAttr('disabled');#}
// {#                                var insert_html = '';#}
// {#                                for (var i = 0; i < data1.info.length; i++) {#}
// {#                                    insert_html = insert_html + '<option value="' + data1.info[i] + '">' + data1.info[i] + '</option>'#}
// {#                                }#}
// {#                                $('#detail_time').html(insert_html).trigger('change');#}
// {#                            }#}
// {##}
// {#                        } else {#}
// {#                            modal_set('获取时间列表错误', data1.info)#}
// {#                        }#}
// {#                    }#}
// {#                })#}
// {#            })#}
