import os

from . settings import Config


# def initTask():
#     BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
#
#     port = '443'
#     if not Config['isPRD']:
#         port = '11443'
#
#     parsedDataTask = "*/5 * * * * curl -k -s  'https://127.0.0.1:" + port + "/OAManager/factorydata/readDataFile'"
#     uploadToS3Task = "0 0 * * * curl -k -s 'https://127.0.0.1:" + port + "/OAManager/factorydata/uploadSrcDataFileToS3'"
#     scheduleReport = "0 9 * * * curl -k -s 'https://127.0.0.1:" + port + "/OAManager/factorydata/scheduleReport'"
#
#     taskList = [parsedDataTask, uploadToS3Task, scheduleReport]
#
#     decPath = os.path.join(BASE_DIR, 'tempcrontab')
#     copyDirection = 'crontab -l > ' + decPath
#     writeDirection = 'crontab ' + decPath
#
#     os.system(copyDirection)
#     if os.path.exists(decPath):
#         foo = open(decPath, 'rb+')
#         for line in foo:
#             if not line.startswith('#'):
#                 for task in taskList:
#                     if len(line) > 5 and line.find(task) != -1:
#                         taskList.remove(task)
#         foo.close()
#
#         with open(decPath, 'ab+') as fi:
#             for src in taskList:
#                 fi.write(src)
#                 fi.write('\n')
#
#         os.system(writeDirection)
#         os.remove(decPath)
#
#     print 'complete init'
