# -*- coding:utf-8 -*-
#
#Copyright (c) 2017, TP-Link Co.,Ltd.
#Author:  yuzhijiang <yuzhijiang@tp-link.com.cn>
#Created: 2017-9-26
#
#
import logging
import traceback

from common.common_base_model import CommonBase
from common.common_exception import DalResponseError, DalServerError
from common.http_client import DALClient
from webmanager.settings import Config

logger = logging.getLogger(__name__)
isGlobal = Config['isGlobal']
dalVersionPath = Config['dalVersionPath']


class User(CommonBase):
    getURL = 'getWebmanagerUserInfoList?'
    getUserRoleURL = 'getWebmanagerUserInfoListFuzzilyByPage?'
    getUserRoleCountURL = 'getWebmanagerUserInfoCountFuzzily?'
    gerUserRoleListRUL = 'getWebmanagerUserInfoList?'
    getURLMainland = 'getUserInfo?'
    addUserRoleURL = 'setWebmanagerUserInfo?'
    updateUserRoleURL = 'updateWebmanagerUserInfo?'
    delUserRoleURL = 'delWebmanagerUserInfo?'

    userId = ''
    email = ''
    password = ''
    salt = ''
    roleId = ''
    name = ''

    def __init__(self, **kwargs):
        for k, v in kwargs.iteritems():
            setattr(self, k, v)

    @classmethod
    def get_data_mysql_by_page(cls, request_body):
        try:
            dal_client = DALClient()
            start_page = long(request_body['start'])
            page_length = long(request_body['length'])

            params_url_tempt = {}
            params_url_tempt['start'] = start_page
            params_url_tempt['length'] = page_length
            params_url = dal_client.group_params(params_url_tempt)

            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()

            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getUserRoleURL + query_id + '&'+ params_url

            response = dal_client.send_post_request(url, params)
        except (DalResponseError, DalServerError):
            raise
        finally:
            dal_client.close()
        # return self.convertDictToObj(response)
        return response

    @classmethod
    def get_data_mysql_count(cls, request_body):
        try:
            dal_client = DALClient()

            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()

            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getUserRoleCountURL + query_id

            response = dal_client.send_post_request(url, params)

        except (DalResponseError, DalServerError):
            raise
        finally:
            dal_client.close()
        return response

    @classmethod
    def get_data_mysql(cls, request_body):
        try:
            dal_client = DALClient()
            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getUserRoleURL + query_id

            response = dal_client.send_post_request(url, params)
        except (DalResponseError, DalServerError):
            raise
        finally:
            dal_client.close()
        return response

    @classmethod
    def find(cls, email):
        response = None
        try:
            dal_client = DALClient()
            if isGlobal:
                params = {"email": email}
                query_id = dal_client.get_query_id()
                url = dalVersionPath + cls.getURL + query_id

                response_all = dal_client.send_post_request(url, params)
                response_list = response_all['responseBody']
                if not response_list:
                    response = 'null'
                else:
                    response = response_list[0]
            else:
                params = {"email": email}
                query_id = dal_client.get_query_id()
                url = dalVersionPath + cls.getURLMainland + query_id
                response = dal_client.send_post_request(url, params)
        except:
            logger.error('find user error. %s', traceback.format_exc())
            raise
        finally:
            dal_client.close()
        return cls.convert_dict_to_obj(response)


    @classmethod
    def add_data_mysql(cls,request_body):
        try:
            dal_client = DALClient()
            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()

            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.addUserRoleURL + query_id

            response = dal_client.send_post_request(url, params)

        except (DalResponseError, DalServerError):
            logger.error('add user info failed.', traceback.format_exc())
            raise
        finally:
            dal_client.close()
        return response

    @classmethod
    def update_data_mysql(cls, request_body):
        try:
            dal_client = DALClient()
            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.updateUserRoleURL + query_id

            response = dal_client.send_post_request(url, params)

        except (DalResponseError, DalServerError):
            logger.error('update user-role info failed.')
            raise
        finally:
            dal_client.close()
        return response

    @classmethod
    def del_data_mysql(cls, request_body):
        try:
            dal_client = DALClient()
            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()

            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.delUserRoleURL + query_id

            response = dal_client.send_post_request(url, params)

        except (DalResponseError, DalServerError):
            raise
        finally:
            dal_client.close()
        # return self.convertDictToObj(response)
        return response


class OAUser(CommonBase):

    getOAUserRoleURL = 'getUser?'
    addOAUserRoleURL = 'setUserInfo?'
    updateOAUserRoleURL = 'updateUserInfo?'
    delOAUserRoleURL = 'delUserInfo?'

    userId = ''
    email = ''
    password = ''
    salt = ''
    roleId = ''
    name = ''
    ttl = ''

    def __init__(self, **kwargs):
        for k, v in kwargs.iteritems():
            setattr(self, k, v)



    @classmethod
    def get_data_mysql(cls, request_body):
        try:
            dal_client = DALClient()
            params_tempt = cls.convert_dict_to_obj(request_body)
            params_dict = params_tempt.convert_to_dict()
            params = dal_client.group_params(params_dict)
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getOAUserRoleURL + query_id

            response = dal_client.send_get_request(url, params)
        except (DalResponseError, DalServerError):
            raise
        finally:
            dal_client.close()
        return response


    @classmethod
    def add_data_mysql(cls,request_body):
        try:
            dal_client = DALClient()
            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()

            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.addOAUserRoleURL + query_id

            response = dal_client.send_post_request(url, params)

        except (DalResponseError, DalServerError):
            logger.error('add user info failed.', traceback.format_exc())
            raise
        finally:
            dal_client.close()
        return response

    @classmethod
    def update_data_mysql(cls, request_body):
        try:
            dal_client = DALClient()
            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.updateOAUserRoleURL + query_id

            response = dal_client.send_post_request(url, params)

        except (DalResponseError, DalServerError):
            logger.error('update user-role info failed.')
            raise
        finally:
            dal_client.close()
        return response

    @classmethod
    def del_data_mysql(cls, request_body):
        try:
            dal_client = DALClient()
            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()

            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.delOAUserRoleURL + query_id

            response = dal_client.send_post_request(url, params)

        except (DalResponseError, DalServerError):
            raise
        finally:
            dal_client.close()
        return response


class Role(CommonBase):
    getRoleListURL = 'getRoleInfoList?'
    getURL = 'getRoleInfo?'
    addURL = 'setRoleInfo?'
    delURL = 'delRoleInfo?'
    updateURL = 'updateRoleInfo?'

    roleId = ''
    name = ''
    note = ''
    authorityIdList = []

    def __init__(self, **kwargs):
        for k, v in kwargs.iteritems():
            setattr(self, k, v)

    @classmethod
    def find(cls, roleId):
        response_data = None
        try:
            dal_client = DALClient()
            params = dal_client.group_params({"roleId": roleId})
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getURL + query_id
            response_data = dal_client.send_get_request(url, params)
            # response_data = response['responseBody']
        except (DalResponseError, DalServerError):
            logger.error('find FwLocale failed. %s', traceback.format_exc())
            raise
        finally:
            dal_client.close()

        return cls.convert_dict_to_obj(response_data)

    @classmethod
    def get_data_mysql(cls, request_body):
        try:
            dal_client = DALClient()
            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()

            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getRoleListURL + query_id

            response = dal_client.send_post_request(url, params)

        except (DalResponseError, DalServerError):
            raise
        finally:
            dal_client.close()

        return response

    @classmethod
    def add_data_mysql(cls, request_body):
        try:
            dal_client = DALClient()
            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()

            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.addURL + query_id

            response = dal_client.send_post_request(url, params)

        except (DalResponseError, DalServerError):
            logger.error('add role info failed.', traceback.format_exc())
            raise
        finally:
            dal_client.close()
        return response

    @classmethod
    def update_data_mysql(cls, request_body):
        try:
            dal_client = DALClient()
            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.updateURL + query_id

            response = dal_client.send_post_request(url, params)
            # response = {'Alice': '2341', 'Beth': '9102', 'Cecil': '3258'}
        except (DalResponseError, DalServerError):
            logger.error('update user-role info failed.')
            raise
        finally:
            dal_client.close()
        return response

    @classmethod
    def del_data_mysql(cls, request_body):
        try:
            dal_client = DALClient()
            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()

            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.delURL + query_id
            response = dal_client.send_post_request(url, params)

        except (DalResponseError, DalServerError):
            raise
        finally:
            dal_client.close()
        # return self.convertDictToObj(response)
        return response


class Authority(CommonBase):
    getURL = 'getAuthorityInfo?'
    getAuthorityListURL = 'getAuthorityInfoList?'
    addURL = 'setAuthorityInfo?'
    updateURL = 'updateAuthorityInfo?'
    delURL = 'delAuthorityInfo?'

    authorityId = ''
    name = ''
    code = ''
    note = ''

    def __init__(self, **kwargs):
        for k, v in kwargs.iteritems():
            setattr(self, k, v)

    @classmethod
    def find(cls, authorityId):
        response = None
        try:
            dal_client = DALClient()
            params = dal_client.group_params({"authorityId": authorityId})
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getURL + query_id
            response = dal_client.send_get_request(url, params)
        except (DalResponseError, DalServerError):
            logger.error('find FwLocale failed. %s', traceback.format_exc())
            raise
        finally:
            dal_client.close()
        return cls.convert_dict_to_obj(response)

    @classmethod
    def get_data_mysql(cls, request_body):
        try:
            dal_client = DALClient()
            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getAuthorityListURL + query_id

            response = dal_client.send_post_request(url, params)
            # response = {'Alice': '2341', 'Beth': '9102', 'Cecil': '3258'}
        except (DalResponseError, DalServerError):
            raise
        finally:
            dal_client.close()
        # return self.convertDictToObj(response)
        return response


    @classmethod
    def add_data_mysql(cls, request_body):
        try:
            dal_client = DALClient()
            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()

            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.addURL + query_id

            response = dal_client.send_post_request(url, params)
            # response = {'Alice': '2341', 'Beth': '9102', 'Cecil': '3258'}
        except (DalResponseError, DalServerError):
            logger.error('add authority info failed.', traceback.format_exc())
            raise
        finally:
            dal_client.close()
        return response

    @classmethod
    def update_data_mysql(cls, request_body):
        try:
            dal_client = DALClient()
            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.updateURL + query_id

            response = dal_client.send_post_request(url, params)
            # response = {'Alice': '2341', 'Beth': '9102', 'Cecil': '3258'}
        except (DalResponseError, DalServerError):
            logger.error('update user-role info failed.')
            raise
        finally:
            dal_client.close()
        return response

    @classmethod
    def del_data_mysql(cls, request_body):
        try:
            dal_client = DALClient()
            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()
            # registerDateToInt = params['registerDate']
            # params['registerDate'] = long(registerDateToInt)
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.delURL + query_id
            response = dal_client.send_post_request(url, params)
            # response = {'Alice': '2341', 'Beth': '9102', 'Cecil': '3258'}
        except (DalResponseError, DalServerError):
            raise
        finally:
            dal_client.close()
        # return self.convertDictToObj(response)
        return response
