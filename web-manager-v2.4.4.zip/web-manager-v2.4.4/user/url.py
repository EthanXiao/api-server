# -*- coding:utf-8 -*-
#
#Copyright (c) 2017, TP-Link Co.,Ltd.
#Author:  yuzhijiang <yuzhijiang@tp-link.com.cn>
#Created: 2017-9-26
#
#


from django.conf.urls import url
from . import views


urlpatterns = [
    url(r'^$', views.login, name='login'),
    url(r'^login$', views.login, name='login'),
    url(r'^logout$', views.logout, name='logout'),
    url(r'^userIndex$', views.user_index, name='user_index'),
    url(r'^modifyPassword$', views.modify_password, name='modify_password'),

    url(r'^getUserRoleInfo$', views.get_user_role_info, name='get_user_role_info'),
    url(r'^readUserRoleInfo$', views.read_user_role_info, name='read_user_role_info'),
    url(r'^addUserRoleInfo$', views.add_user_role_info, name='add_user_role_info'),
    url(r'^modifyUserRoleInfo$', views.modify_user_role_info, name='modify_user_role_info'),
    url(r'^delUserRoleInfo$', views.del_user_role_info, name='del_user_role_info'),
    url(r'^getUserExtraInfo$', views.get_user_extra_info, name='get_user_extra_info'),


    url(r'^getRoleAuthorityInfo$', views.get_role_authority_info, name='get_role_authority_info'),
    url(r'^readRoleAuthorityInfo$', views.read_role_authority_info, name='read_role_authority_info'),
    url(r'^addRoleAuthorityInfo$', views.add_role_authority_info, name='add_role_authority_info'),
    url(r'^modifyRoleAuthorityInfo$', views.modify_role_authority_info, name='modify_role_authority_info'),
    url(r'^delRoleAuthorityInfo$', views.del_role_authority_info, name='del_role_authority_info'),
    url(r'^getRoleExtraInfo$', views.get_role_extra_info, name='get_role_extra_info'),

    url(r'^getAuthorityInfo$', views.get_authority_info, name='get_authority_info'),
    url(r'^readAuthorityInfo$', views.read_authority_info, name='read_authority_info'),
    url(r'^addAuthorityInfo$', views.add_authority_info, name='add_authority_info'),
    url(r'^modifyAuthorityInfo$', views.modify_authority_info, name='modify_authority_info'),
    url(r'^delAuthorityInfo$', views.del_authority_info, name='del_authority_info'),
]