# -*- coding:utf-8 -*-
#
# Copyright (c) 2017, TP-Link Co.,Ltd.
# Author:  yuzhijiang <yuzhijiang@tp-link.com.cn>
# Created: 2017-9-26
#
#
import json
import logging
import traceback
import uuid

from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader

from common.digest_utils import get_sha1, get_string_md5
from common.mysql_dao import MysqlOp
from interceptor import auth_interceptor
from interceptor.auth_interceptor import check_authority, check_super_admin_authority
from user.models import User, Role, Authority
from webmanager.conf import conf
from webmanager.settings import MySQLConfig, Config

logger = logging.getLogger(__name__)
isGlobal = Config['isGlobal']


def login(request):
    session = request.COOKIES.get('session_id', 'null')
    index_url = '/webManager/userIndex'
    if session is not 'null':

        mysql_op = MysqlOp(MySQLConfig['host'],
                           MySQLConfig['port'],
                           MySQLConfig['user'],
                           MySQLConfig['passwd'],
                           MySQLConfig['db'])
        session_info = mysql_op.check_session(session)
        if session_info is not None:
            logger.info("login request by session. url: login. the user is %s", session_info.get('email'))
            return HttpResponseRedirect(index_url)
    return render(request, 'login/login.html')


def user_index(request):
    str_index = 'index/index.html'
    str_login = 'login/login.html'

    if request.method == 'GET':

        session = request.COOKIES.get('session_id', 'null')
        if session is not 'null':
            mysql_op = MysqlOp(MySQLConfig['host'],
                               MySQLConfig['port'],
                               MySQLConfig['user'],
                               MySQLConfig['passwd'],
                               MySQLConfig['db'])
            session_info = mysql_op.check_session(session)
            if session_info is not None:
                email = session_info['email']
                response_data = {'user': email.split("@")[0], 'web_user_role': session_info['role_id'],
                                 'isGlobal': isGlobal}
                logger.info("login-request by session passed. url: userIndex. request method: GET. user: %s, session:%s",
                            email, session)

                return render(request, str_index, response_data)
        return render(request, str_login)

    elif request.method == 'POST':
        request_body = request.POST.copy()
        content_type = request.META['CONTENT_TYPE']

        if 'application/json' in content_type:
            request_body.update(json.loads(request.body))

        try:
            email = request_body["email"]
            password = request_body["password"]
            logger.info("login request by email and password started. email: %s", email)
            is_user = auth_interceptor.find_user(email, password)

            if is_user:
                if isGlobal:
                    user = User.find(email)
                    web_user_role = user.roleId
                else:
                    mysql_op = MysqlOp(MySQLConfig['host'],
                                       MySQLConfig['port'],
                                       MySQLConfig['user'],
                                       MySQLConfig['passwd'],
                                       MySQLConfig['db'])
                    user = mysql_op.get_user_info(email)
                    web_user_role = user.get('role_id')

                session = uuid.uuid1()

                response_data = {'user': email.split("@")[0], 'web_user_role': web_user_role, 'isGlobal': isGlobal}
                response = render(request, str_index, response_data)

                response.set_cookie("session_id", session, conf.session_ttl)
                cloud_mgn_pass = get_sha1(password)

                mysql_op = MysqlOp(MySQLConfig['host'],
                                   MySQLConfig['port'],
                                   MySQLConfig['user'],
                                   MySQLConfig['passwd'],
                                   MySQLConfig['db'])
                session_saved = mysql_op.save_user_login_info(email, session, web_user_role, cloud_mgn_pass)

                if session_saved:
                    logger.info(
                        "login-request by email-and-password passed. url: userIndex. request method: GET. "
                        "user: %s, session: %s", email, session)
                    return response
                else:
                    logger.error(
                        "login request by email and password failed. saving session into mysql failed. "
                        "session_info: %s, %s, %s, %s", email, session, user.roleId, cloud_mgn_pass)
                    return render(request, str_login, {'login_error': True})
            else:
                logger.info(
                    "login request by email and password failed. email and password don't matched. the user is: %s",
                    request_body.get('email'))
                return render(request, str_login, {'user_pass_error': True})
        except:
            logger.error("login request by email and password failed. request_body: %s. %s", request_body['email'],
                         traceback.format_exc())
            return render(request, str_login, {'login_error': True})
    else:
        logger.error("unexpected request method. request method: %s", request.method)
        return render(request, str_login, {'login_error': True})


def get_user_role_info(request):
    str = 'user/user-role/user-role-info.html'
    str_login = '/webManager/login'
    try:
        session = request.COOKIES["session_id"]
    except:
        logger.error("failed in getting session. %s", traceback.format_exc())
        return HttpResponseRedirect(str_login)

    mysql_op = MysqlOp(MySQLConfig['host'],
                       MySQLConfig['port'],
                       MySQLConfig['user'],
                       MySQLConfig['passwd'],
                       MySQLConfig['db'])
    session_info = mysql_op.check_session(session)

    if session_info is not None:
        email = session_info['email']
        response = render(request, str, {'user': email.split("@")[0], 'web_user_role': session_info.get('role_id'),
                                         'isGlobal': isGlobal})
        response.set_cookie("session_id", session, conf.session_ttl)
        return response
    else:
        logger.warn("get_user_role_info. checking-session failed. the session is ------>%s" % session)
        return HttpResponseRedirect(str_login)


@check_super_admin_authority
def read_user_role_info(request):
    request_body = request.POST

    logger.info("read_user_role_info started. the request is ------>%s" % request_body)

    if isGlobal:
        try:
            response = User.get_data_mysql_by_page(request_body)
            response_count = User.get_data_mysql_count(request_body)
            response_data = response['responseBody']
            records_filtered = response_count['responseBody']
            records_total_count = User.get_data_mysql_count({"email": ""})
            records_total = records_total_count["responseBody"]
        except:
            logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
            raise

        if type(response_data) is type(list()):
            data = {'data': response_data, 'recordsFiltered': records_filtered, 'recordsTotal': records_total}
        elif type(response_data) is type(dict()):
            response_temp = [response_data]
            data = {'data': response_temp, 'recordsFiltered': 1, 'recordsTotal': records_total}
        else:
            response_temp = []
            data = {'data': response_temp, 'recordsFiltered': 0, 'recordsTotal': records_total}
            logger.info("the type of the data from DAL is -----> %s" % type(response_data))
        return HttpResponse(json.dumps(data))

    else:
        mysql_op = MysqlOp(MySQLConfig['host'],
                           MySQLConfig['port'],
                           MySQLConfig['user'],
                           MySQLConfig['passwd'],
                           MySQLConfig['db'])
        response_data = mysql_op.get_all_user_info(request_body.get('email'))

        if type(response_data) is type(list()):
            for each in response_data:
                each['userId'] = each.get('user_id')
                each['roleId'] = each.get('role_id')
            data = {'data': response_data}
        elif type(response_data) is type(dict()):
            response_data['userId'] = response_data.get('user_id')
            response_data['roleId'] = response_data.get('role_id')
            response_temp = [response_data]
            data = {'data': response_temp}
        else:
            response_temp = []
            data = {'data': response_temp}
            logger.info("the type of the data from DAL is -----> %s" % type(response_data))
        return HttpResponse(json.dumps(data))


def get_user_extra_info(request):
    request_body = request.POST

    logger.info("get_user_extra_info started. the request is ------>%s" % request_body)

    template = loader.get_template('user/user-role/user-role-extra-info.html')
    response_temp = []
    role_id = request_body['roleId']

    if role_id == 'null' or role_id == '' or role_id is None:
        data = {'data': response_temp, 'name': "未分配角色"}
        return HttpResponse(json.dumps({'html': template.render(data)}))

    try:
        role_info = Role.find(role_id)
        authority_list = role_info.authorityIdList
        name = role_info.name
        for k in authority_list:
            if k is not ',':
                response_data = Authority.find(k)
                response_temp.append(response_data)
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        raise
    data = {'data': response_temp, 'name': name}

    return HttpResponse(json.dumps({'html': template.render(data)}))


@check_super_admin_authority
def add_user_role_info(request):
    request_body = request.POST.copy()

    logger.info("add_user_role_info started. the request is ------>%s" % request_body)

    password = request_body['password']
    password_sha = get_sha1(password)
    ## apply get_sha1 twice. This is for the convenience of calling the interface port of OpDataReceiver.
    password_sha_sha = get_sha1(password_sha)
    password_salt = get_string_md5(password)
    password_salt_sha = get_sha1(password_sha_sha + password_salt)
    request_body['password'] = password_salt_sha
    request_body['salt'] = password_salt

    response_data = "false"

    try:
        email = request_body['email']
        if isGlobal:
            existed = User.find(email)
            is_existed = existed
            if not is_existed:
                response = User.add_data_mysql(request_body)
            else:
                request_body['userId'] = is_existed.userId
                response = User.update_data_mysql(request_body)
            response_data = response['success']
        else:
            mysql_op = MysqlOp(MySQLConfig['host'],
                               MySQLConfig['port'],
                               MySQLConfig['user'],
                               MySQLConfig['passwd'],
                               MySQLConfig['db'])
            response_data = mysql_op.save_user_info(request_body)
            if response_data:
                response_data = 'true'
            else:
                response_data = 'false'
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())

    data = {'result': response_data}
    return HttpResponse(json.dumps(data))


@check_super_admin_authority
def modify_user_role_info(request):
    request_body = request.POST

    logger.info("modify_user_role_info started. the request is ------>%s" % request_body)

    response_data = ""
    try:
        if isGlobal:
            response = User.update_data_mysql(request_body)
            response_data = response['responseBody']
        else:
            mysql_op = MysqlOp(MySQLConfig['host'],
                               MySQLConfig['port'],
                               MySQLConfig['user'],
                               MySQLConfig['passwd'],
                               MySQLConfig['db'])
            response_data = mysql_op.save_user_info(request_body)
            if response_data:
                response_data = 'true'
            else:
                response_data = 'false'
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())

    data = {'result': response_data}

    return HttpResponse(json.dumps(data))


@check_super_admin_authority
def del_user_role_info(request):
    request_body = request.POST

    logger.info("del_user_role_info started. the request is ------>%s" % request_body)

    response_data = "true"
    try:
        if isGlobal:
            response = User.del_data_mysql(request_body)
            response_data = response['success']
        else:
            mysql_op = MysqlOp(MySQLConfig['host'],
                               MySQLConfig['port'],
                               MySQLConfig['user'],
                               MySQLConfig['passwd'],
                               MySQLConfig['db'])
            response_data = mysql_op.delete_user_info(request_body)
            if response_data:
                response_data = 'true'
            else:
                response_data = 'false'
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        response_data = "false"

    data = {'result': response_data}
    return HttpResponse(json.dumps(data))


def get_role_authority_info(request):
    str = 'user/role-authority/role-authority-info.html'
    str_login = '/webManager/login'
    try:
        session = request.COOKIES["session_id"]
    except:
        logger.error("failed in getting session. %s", traceback.format_exc())
        return HttpResponseRedirect(str_login)

    mysql_op = MysqlOp(MySQLConfig['host'],
                       MySQLConfig['port'],
                       MySQLConfig['user'],
                       MySQLConfig['passwd'],
                       MySQLConfig['db'])
    session_info = mysql_op.check_session(session)

    if session_info is not None:
        email = session_info['email']
        response = render(request, str, {'user': email.split("@")[0], 'web_user_role': session_info.get('role_id')})
        response.set_cookie("session_id", session, conf.session_ttl)
        return response
    else:
        logger.warn("get_role_authority_info. checking-session failed. the session is ------>%s" % session)
        return HttpResponseRedirect(str_login)


@check_super_admin_authority
def read_role_authority_info(request):
    request_body = request.POST

    logger.info("read_role_authority_info started. the request is ------>%s" % request_body)

    response_data = list()

    try:
        response = Role.get_data_mysql(request_body)
        response_data = response['responseBody']
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())

    if type(response_data) is type(list()):
        data = {'data': response_data}
    elif type(response_data) is type(dict()):
        response_temp = []
        response_temp.append(response_data)
        data = {'data': response_temp}
    else:
        response_temp = []
        data = {'data': response_temp}
        logger.info("the type of the data from DAL is null.%s" % type(response_data))
    return HttpResponse(json.dumps(data))


@check_super_admin_authority
def add_role_authority_info(request):
    request_body = request.POST.copy()

    logger.info("add_role_authority_info started. the request is ------>%s" % request_body)

    authorityList = json.loads(request_body['authorityIdList'])
    str = ','
    authorityIdList = str.join(authorityList)
    request_body['authorityIdList'] = authorityIdList
    response_data = "false"
    try:
        response = Role.add_data_mysql(request_body)
        response_data = response['success']
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())

    data = {'result': response_data}
    return HttpResponse(json.dumps(data))


@check_super_admin_authority
def modify_role_authority_info(request):
    request_body = request.POST.copy()

    logger.info("modify_role_authority_info started. the request is ------>%s" % request_body)

    authorityList = json.loads(request_body['authorityIdList'])
    str = ','
    authorityIdList = str.join(authorityList)
    request_body['authorityIdList'] = authorityIdList
    response_data = "false"
    try:
        response = Role.update_data_mysql(request_body)
        response_data = response['responseBody']
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())

    data = {'result': response_data}

    return HttpResponse(json.dumps(data))


@check_super_admin_authority
def del_role_authority_info(request):
    request_body = request.POST

    logger.info("del_role_authority_info started. the request is ------>%s" % request_body)

    response_data = "false"
    try:
        response = Role.del_data_mysql(request_body)
        response_data = response['success']
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        response_data = "false"

    data = {'result': response_data}
    return HttpResponse(json.dumps(data))


def get_authority_info(request):
    str = 'user/authority/authority-info.html'
    str_login = '/webManager/login'
    try:
        session = request.COOKIES["session_id"]
    except:
        logger.error("failed in getting session. %s", traceback.format_exc())
        return HttpResponseRedirect(str_login)

    mysql_op = MysqlOp(MySQLConfig['host'],
                       MySQLConfig['port'],
                       MySQLConfig['user'],
                       MySQLConfig['passwd'],
                       MySQLConfig['db'])
    session_info = mysql_op.check_session(session)

    if session_info is not None:
        email = session_info['email']
        response = render(request, str, {'user': email.split("@")[0], 'web_user_role': session_info.get('role_id')})
        response.set_cookie("session_id", session, conf.session_ttl)
        return response
    else:
        logger.warn("get_authority_info. checking-session failed. the session is ------>%s" % session)
        return HttpResponseRedirect(str_login)


@check_super_admin_authority
def read_authority_info(request):
    request_body = request.POST

    logger.info("read_authority_info started. the request is ------>%s" % request_body)

    response_data = list()

    try:
        response = Authority.get_data_mysql(request_body)
        response_data = response['responseBody']
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())

    if type(response_data) is type(list()):
        data = {'data': response_data}
    elif type(response_data) is type(dict()):
        response_temp = []
        response_temp.append(response_data)
        data = {'data': response_temp}
    else:
        response_temp = []
        data = {'data': response_temp}
        logger.info("the type of the data from DAL is null.%s" % type(response_data))
    return HttpResponse(json.dumps(data))


@check_super_admin_authority
def get_role_extra_info(request):
    request_body = request.POST

    logger.info("get_role_extra_info started. the request is ------>%s" % request_body)

    template = loader.get_template('user/role-authority/role-authority-extra-info.html')
    response_temp = []
    roleId = request_body['roleId']

    if roleId == 'null' or roleId == '' or roleId is None:
        data = {'data': response_temp}
        return HttpResponse(json.dumps({'html': template.render(data)}))

    try:
        role_info = Role.find(roleId)
        authorityList = role_info.authorityIdList
        if authorityList == 'null' or authorityList == '' or authorityList is None:
            data = {'data': response_temp}
            return HttpResponse(json.dumps({'html': template.render(data)}))

        for k in authorityList:

            if k is not ',':
                # request_authority_info = dict(zip(['authorityId'],list(k)))
                # print request_authority_info
                response_data = Authority.find(k)
                response_temp.append(response_data)
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        raise
    data = {'data': response_temp}

    return HttpResponse(json.dumps({'html': template.render(data)}))


@check_super_admin_authority
def add_authority_info(request):
    request_body = request.POST.copy()

    logger.info("add_authority_info started. the request is ------>%s" % request_body)

    response_data = "false"
    try:
        response = Authority.add_data_mysql(request_body)
        response_data = response['success']
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())

    data = {'result': response_data}
    return HttpResponse(json.dumps(data))


@check_super_admin_authority
def modify_authority_info(request):
    request_body = request.POST

    logger.info("modify_authority_info started. the request is ------>%s" % request_body)

    response_data = ""
    try:
        response = Authority.update_data_mysql(request_body)
        response_data = response['responseBody']
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())

    data = {'result': response_data}

    return HttpResponse(json.dumps(data))


@check_super_admin_authority
def del_authority_info(request):
    request_body = request.POST

    logger.info("del_authority_info started. the request is ------>%s" % request_body)

    response_data = "false"
    try:
        response = Authority.del_data_mysql(request_body)
        response_data = response['success']
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        response_data = "false"

    data = {'result': response_data}

    return HttpResponse(json.dumps(data))


def logout(request):
    str = '/webManager/login'
    response = HttpResponseRedirect(str)
    response.delete_cookie('session_id')
    try:
        session = request.COOKIES['session_id']

        mysql_op = MysqlOp(MySQLConfig['host'],
                           MySQLConfig['port'],
                           MySQLConfig['user'],
                           MySQLConfig['passwd'],
                           MySQLConfig['db'])
        session_deleted = mysql_op.delete_session(session)
        logger.info("the user logout. session-%s is deleted.", session)
        return response
    except:
        logger.error("failed in deleting session from mysql. %s", traceback.format_exc())
        return response

@check_authority
def modify_password(request):
    request_body = request.POST.copy()

    logger.info("modify_password started.")

    str = '/webManager/login'
    try:
        session = request.COOKIES['session_id']
    except:
        logger.error("failed in getting session. %s", traceback.format_exc())
        return HttpResponseRedirect(str)

    mysql_op = MysqlOp(MySQLConfig['host'],
                       MySQLConfig['port'],
                       MySQLConfig['user'],
                       MySQLConfig['passwd'],
                       MySQLConfig['db'])
    session_info = mysql_op.check_session(session)

    if session_info is None:
        return HttpResponseRedirect(str)

    email = session_info['email']

    logger.info("modify_password. session checked. the user is: %s" % session_info.get('email'))

    old_password = request_body['old_password']
    password = request_body['password']
    password_verify = request_body['password_verify']
    if password == password_verify:
        is_user = auth_interceptor.find_user(email, old_password)
        if not is_user:
            return HttpResponseRedirect(str)

        if isGlobal:
            user_info = User.get_data_mysql({"email": email})

            user_id = user_info['responseBody'][0]['userId']
        else:
            mysql_op = MysqlOp(MySQLConfig['host'],
                               MySQLConfig['port'],
                               MySQLConfig['user'],
                               MySQLConfig['passwd'],
                               MySQLConfig['db'])
            user_info = mysql_op.get_user_info(email)
            user_id = user_info['user_id']
    else:
        raise

    password_sha = get_sha1(password)
    password_sha_sha = get_sha1(password_sha)
    password_salt = get_string_md5(password)
    password_salt_sha = get_sha1(password_sha_sha + password_salt)

    password_body = {}
    password_body['userId'] = user_id
    password_body['password'] = password_salt_sha
    password_body['salt'] = password_salt

    try:
        mysql_op = MysqlOp(MySQLConfig['host'],
                           MySQLConfig['port'],
                           MySQLConfig['user'],
                           MySQLConfig['passwd'],
                           MySQLConfig['db'])
        cloud_mgn_pass_saved = mysql_op.save_cloud_mgn_pass(session, password_sha)

        if not cloud_mgn_pass_saved:
            logger.info("failed in saving cloud_mgn_pass into mySQL.")
            raise
    except:
        logger.error("failed in saving cloud_mgn_pass into mySQL. %s", traceback.format_exc())
        raise

    try:
        if isGlobal:
            response = User.update_data_mysql(password_body)
            response_data = response['responseBody']
        else:
            mysql_op = MysqlOp(MySQLConfig['host'],
                               MySQLConfig['port'],
                               MySQLConfig['user'],
                               MySQLConfig['passwd'],
                               MySQLConfig['db'])
            password_body['email'] = email
            response_data = mysql_op.save_user_info(password_body)
            if response_data is True:
                response_data = 'true'
            else:
                response_data = 'false'
    except:
        logger.error("failed in updating data into models-layer. %s", traceback.format_exc())
        raise

    data = {'result': response_data}
    return HttpResponse(json.dumps(data))
