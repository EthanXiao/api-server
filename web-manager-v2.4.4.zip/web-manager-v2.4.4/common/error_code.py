# -*- coding:utf-8 -*-
#
# Copyright (c) 2014, TP-Link Co.,Ltd.
# Author:  zhaofeng <zhaofeng@tp-link.net>
# Created: 2016-3-22
#
#
import json


def BuiltErrorCode(errCode, errMessage):
    '''this method is used as the error code built'''
    return json.dumps({'errCode': errCode, 'errMessage': errMessage})


class ErrorCode:
    '''this class return error code of the oa manager system'''
    ERROR_SUCCESS = BuiltErrorCode(0, 'Success')
    ERROR_USERNAME_PASSWORD = BuiltErrorCode(-26001, "Password incorrect")
    ERROR_GENERIC_FAIL = BuiltErrorCode(-26002, "Sever internal error")
    ERROR_FILE_HAS_BEEN_UPLOADED = BuiltErrorCode(-26003, "File has been uploaded")
    ERROR_FACTORYDATA_VERIFY_FAIL = BuiltErrorCode(-26004, "Factory Data verify failed")
    ERROR_FIRMWARE_NOT_UPLOADED = BuiltErrorCode(-26005, "Firmware has not been uploaded")
    ERROR_PLUGIN_NOT_UPLOADED = BuiltErrorCode(-26006, "Plugin has not been uploaded")
    ERROR_APP_NOT_UPLOADED = BuiltErrorCode(-26007, "App has not been uploaded")
    ERROR_MD5_WRONG = BuiltErrorCode(-26008, "File md5 is not matching")
    ERROR_DATA_FORMAT_WRONG = BuiltErrorCode(-26009, "DATA FORMAT FROM OA IS WRONG")
    ERROR_UNZIP_FAIL = BuiltErrorCode(-26010, "Unzip File Failed")
    ERROR_FW_HAS_BEEN_ROLLBACKED = BuiltErrorCode(-26011, "Firmware has been rollbacked")
    ERROR_FILE_NAME_FORMAT_WRONG = BuiltErrorCode(-26012, "File has a wrong name format")
    ERROR_APP_RELEASE_TASK_HAS_EXIST = BuiltErrorCode(-26013, 'App release task has alreadly exist')
    ERROR_USER_PERMISSION_DENIED = BuiltErrorCode(-26014, 'User permission denied')
    ERROR_SIGNATURE_NOT_UPLOADED = BuiltErrorCode(-26015, 'Signature does not exist')
    ERROR_DATA_TOO_MUCH = BuiltErrorCode(-26016, 'The list is too long')
    ERROR_EAIL_CONFLICT = BuiltErrorCode(-26017, "The email has been registered")
    ERROR_USER_OFFLINE= BuiltErrorCode(-26018, "The User is not on line")
    ERROR_USER_LOGOUT = BuiltErrorCode(-26019, "The User has logged out")

errorCode = ErrorCode()
