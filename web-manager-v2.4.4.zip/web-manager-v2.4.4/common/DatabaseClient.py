# -*- coding:utf-8 -*-
#
# Copyright (c) 2014, TP-Link Co.,Ltd.
# Author:  zhaofeng <zhaofeng@tp-link.net>
# Created: 2016-4-5
#
#
import logging

from webmanager.settings import Config
# from .DALClient import DALClient

logger = logging.getLogger(__name__)
# global dal version path
dalVersionPath = Config['dalVersionPath']





def getFirmwareInfoKey(firmwareId):
    return 'firmware:%s:info' % firmwareId


def getFirmwareUpgradeCacheKey(hwId, fwId):
    return 'firmware_upgrade_cache:%s:%s:info' % (hwId, fwId)


def getDeviceInfoKey(deviceId):
    return 'device_factory_info:%s:info' % deviceId


def getDeviceInfoGlobalKey(deviceId):
    return 'device_factory:%s:info' % deviceId


def getPluginSuitModelKey(hwId, fwId, pluginId, pluginVersion):
    return 'plugin_suitable_model:%s:%s:%s:%s:info' % (hwId, fwId, pluginId, pluginVersion)


def getPluginUpgCacheKey(hwId, fwId):
    return 'plugin_upgrade_cache:%s:%s:info' % (hwId, fwId)


def getPluginInfoKey(pluginId, pluginVer):
    return 'plugin:%s:%s:info' % (pluginId, pluginVer)


def getFwLocaleInfoKey(fwId, locale):
    return 'fw_locale:%s:%s:info' % (fwId, locale)


def getFwInfoListGlobalKey(hwId, oemId):
    return 'firmware:%s:%s:list' % (hwId, oemId)


def getFwInfoGlobalKey(fwId):
    return 'firmware:%s:info' % fwId


def getFwFullInfoGlobalKey(hwId, oemId, fwVer):
    return 'firmware:%s:%s:%s:info' % (hwId, oemId, fwVer)


def getFwUpgradeCacheGlobalKey(hwId, oemId, fwVer):
    return 'firmware_upgrade_cache_export:%s:%s:%s:info' % (hwId, oemId, fwVer)


def getFwUpgradeCacheGlobalDefualtKey(hwId, oemId):
    return 'firmware_upgrade_cache_export:%s:%s:info' % (hwId, oemId)


def getBetaDeviceGlobalKey(deviceId):
    return 'device_factory_beta:%s:info' % (deviceId)

def getBetaDeviceMainlandKey(deviceId):
    return 'device_factory_beta:%s:info' % (deviceId)