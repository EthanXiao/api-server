# -*- coding:utf-8 -*-
#
# Copyright (c) 2017, TP-Link Co.,Ltd.
# Author:  yuzhijiang <yuzhijiang@tp-link.com.cn>
# Created: 2017-10-20
#
#
import logging
import traceback

import MySQLdb

from webmanager.conf import conf

logger = logging.getLogger(__name__)

__VERSION__ = '1.0.0'

TABLE_SESSION = conf.MysqlTableSession
WEBMANAGER_USER = conf.MysqlWebmanagerUser


class MysqlOp(object):
    db = None
    cursor = None

    def __init__(self, mysql_host, mysql_port, mysql_user, mysql_password, mysql_database):
        self.db = MySQLdb.connect(host=mysql_host,
                                  port=int(mysql_port),
                                  user=mysql_user,
                                  passwd=mysql_password,
                                  db=mysql_database,
                                  charset='utf8',
                                  )
        self.cursor = self.db.cursor()

    def save_session(self, email, session, roleId):

        cursor = self.cursor
        result = True
        try:
            session_query = "SELECT session FROM" + TABLE_SESSION + "WHERE email = '%s'" % email
            cursor.execute(session_query)
            results = cursor.fetchone()
            if results:
                sql_session = "UPDATE" + TABLE_SESSION + " SET session = '%s'WHERE email = '%s'" % (session, email)
                cursor.execute(sql_session)
                self.db.commit()
            else:
                sql_session = "INSERT INTO " + TABLE_SESSION + " (email, session, role_id) VALUES (%s,%s,%s)"
                values = [email, session, roleId]
                cursor.execute(sql_session, values)
                self.db.commit()
        except:
            self.db.rollback()
            result = False
        finally:
            cursor.close()
            self.db.close()
        return result

    def check_session(self, session_value):
        cursor = self.cursor
        try:
            sql_query = "SELECT email, session, role_id FROM " + TABLE_SESSION + " WHERE session = '%s'" % session_value
            cursor.execute(sql_query)
            results = cursor.fetchone()
        except:
            results = None
        finally:
            cursor.close()
            self.db.close()

        if results is None:
            return None
        else:
            keys = ['email', 'session', 'role_id']
            values = list(results)
            session_info = dict(zip(keys, values))
            return session_info

    def delete_session(self, session):
        cursor = self.cursor
        result = True
        try:
            sql_session = "DELETE FROM " + TABLE_SESSION + " WHERE session = '%s'" % session
            cursor.execute(sql_session)
            self.db.commit()
        except:
            self.db.rollback()
            result = False
        finally:
            cursor.close()
            self.db.close()
        return result

    def save_cloud_mgn_pass(self, session, password_hash):

        cursor = self.cursor
        result = True
        try:
            user_info_query = "SELECT cloud_mgn_pass FROM " + TABLE_SESSION + " WHERE session = '%s'" % session

            cursor.execute(user_info_query)
            results = cursor.fetchone()

            if results:
                sql_user_info = "UPDATE " + TABLE_SESSION + " SET cloud_mgn_pass = '%s'WHERE session = '%s'" % (
                    password_hash, session)
                cursor.execute(sql_user_info)
                self.db.commit()
            else:
                sql_user_info = "INSERT INTO " + TABLE_SESSION + " (session, cloud_mgn_pass) VALUES (%s,%s)"
                values = [session, password_hash]
                cursor.execute(sql_user_info, values)
                self.db.commit()
        except:
            self.db.rollback()
            result = False
        finally:
            cursor.close()
            self.db.close()
        return result

    def save_user_login_info(self, email, session, roleId, cloud_mgn_pass):
        cursor = self.cursor
        result = True
        try:
            session_query = "SELECT session FROM " + TABLE_SESSION + " WHERE email = '%s'" % email

            cursor.execute(session_query)
            results = cursor.fetchone()

            if results:
                sql_session = "UPDATE " + TABLE_SESSION + " SET session = '%s', cloud_mgn_pass = '%s' WHERE email = '%s'" % (
                    session, cloud_mgn_pass, email)
                cursor.execute(sql_session)
                self.db.commit()
            else:
                sql_session = "INSERT INTO " + TABLE_SESSION + "(email, session, role_id, cloud_mgn_pass) VALUES (%s,%s,%s,%s)"
                values = [email, session, roleId, cloud_mgn_pass]
                cursor.execute(sql_session, values)
                self.db.commit()
        except:
            self.db.rollback()
            result = False
        finally:
            cursor.close()
            self.db.close()
        return result

    def get_cloud_mgn_pass(self, session_value):
        cursor = self.cursor
        try:
            sql_query = "SELECT email, cloud_mgn_pass FROM " + TABLE_SESSION + " WHERE session = '%s'" % session_value
            cursor.execute(sql_query)
            results = cursor.fetchone()
        except:
            results = None
        finally:
            cursor.close()
            self.db.close()

        if results is None:
            return None
        else:
            keys = ['email', 'cloud_mgn_pass']
            values = list(results)
            cloud_mgn_pass_info = dict(zip(keys, values))
            return cloud_mgn_pass_info

    def save_user_info(self, user_body):

        user_id = user_body.get('userId') #when modifying is performing, the field is used.
        email = user_body.get('email')
        name = user_body.get('name')
        salt = user_body.get('salt')
        password = user_body.get('password')
        role_id = user_body.get('roleId')

        cursor = self.cursor
        result = True

        update_str = "SET"

        if email is not None:
            update_str += " email = '%s'," % email
        if name is not None:
            update_str += " name = '%s'," % name
        if salt is not None:
            update_str += " salt = '%s'," % salt
        if password is not None:
            update_str += " password = '%s'," % password
        if role_id is not None:
            update_str += " role_id = '%s'," % role_id

        try:

            if user_id is None:
                session_query = "SELECT user_id FROM " + WEBMANAGER_USER + " WHERE email = '%s'" % email
                cursor.execute(session_query)
                results = cursor.fetchone()
                if results:
                    update_str = update_str[:-1]
                    sql_session = "UPDATE " + WEBMANAGER_USER + ' ' + update_str + " WHERE user_id = %d" % results[0]
                    cursor.execute(sql_session)
                    self.db.commit()
                else:
                    sql_session = "INSERT INTO " + WEBMANAGER_USER + \
                                  " (email, name, salt, password, role_id) VALUES (%s,%s,%s,%s,%s)"
                    values = [email, name, salt, password, role_id]
                    cursor.execute(sql_session, values)
                    self.db.commit()
            else:
                update_str = update_str[:-1]
                sql_session = "UPDATE " + WEBMANAGER_USER + ' ' + update_str + " WHERE user_id = %d" % int(user_id)
                cursor.execute(sql_session)
                self.db.commit()
        except:
            logger.error('ERROR in insert user_info into table. %s', traceback.format_exc())
            self.db.rollback()
            result = False
        finally:
            cursor.close()
            self.db.close()
        return result

    def get_user_info(self, email):
        cursor = self.cursor
        try:
            sql_query = "SELECT user_id, email, name, salt, password, role_id FROM " + WEBMANAGER_USER +\
                        " WHERE email = '%s'" % email
            cursor.execute(sql_query)
            results = cursor.fetchone()
        except:
            results = None
        finally:
            cursor.close()
            self.db.close()

        if results is None:
            return None
        else:
            keys = ['user_id', 'email', 'name', 'salt', 'password', 'role_id']
            values = list(results)
            user_info = dict(zip(keys, values))
            return user_info

    def get_all_user_info(self, email):
        cursor = self.cursor
        try:
            if email is None or email == '' or email == 'null':
                sql_query = "SELECT user_id, email, name, salt, password, role_id FROM " + WEBMANAGER_USER
            else:
                sql_query = "SELECT user_id, email, name, salt, password, role_id FROM " + WEBMANAGER_USER +\
                            " WHERE email like " + "'%%%s%%'" % email
            cursor.execute(sql_query)
            results = cursor.fetchall()
        except:
            results = None
        finally:
            cursor.close()
            self.db.close()

        if results is None:
            return None
        else:
            user_info = []
            for each in results:
                keys = ['user_id', 'email', 'name', 'salt', 'password', 'role_id']
                values = list(each)
                user_info.append(dict(zip(keys, values)))
            return user_info

    def delete_user_info(self, user_body):

        user_id = user_body.get('userId')
        cursor = self.cursor
        result = True
        if user_id is not None:
            try:
                sql_session = "DELETE FROM " + WEBMANAGER_USER + " WHERE user_id = '%s'" % user_id
                cursor.execute(sql_session)
                self.db.commit()
            except:
                self.db.rollback()
                result = False
            finally:
                cursor.close()
                self.db.close()
        else:
            result = False
        return result

    # def update_user_info(self, user_body):
    #     cursor = self.cursor
    #     result = True
    #
    #     user_id = user_body.get('user')
    #     email = user_body.get('email')
    #     name = user_body.get('name')
    #     salt = user_body.get('salt')
    #     password = user_body.get('password')
    #     role_id = user_body.get('role_id')
    #
    #     try:
    #         sql_session = "DELETE FROM " + WEBMANAGER_USER + " WHERE user_id = '%s'" % user_id
    #         cursor.execute(sql_session)
    #         self.db.commit()
    #     except:
    #         self.db.rollback()
    #         result = False
    #     finally:
    #         cursor.close()
    #         self.db.close()
    #     return result
