# -*- coding:utf-8 -*-
#
# Copyright (c) 2017, TP-Link Co.,Ltd.
# Author:  caishupeng <caishupeng@tp-link.net>
# Created: 2017-3-3
#
#

# import xlwt
import logging
import traceback
# import xlutils.copy
# import xlsxwriter
import time
import thread
from os.path import join

from common.ExcelBase import ExcelBase

logger = logging.getLogger(__name__)

UPLOAD_RECORD_SHEET_NUM = 0
FACTORY_DATA_SHEET_NUM = 1
NOT_NORMAL_FACTORY_DATA_SHEET_NUM = 2

INVALID_DATA_COL = 4
VALID_DATA_COL = 3


class FactoryDailyReport(ExcelBase):

    workbookName = 'Cloud_Factory_Data_Record.xls'

    factoryDataFileRecordTitle = ['DataFileName', 'ParseTime', 'TotalCount', 'ValidCount', 'InvalidCount']
    factoryDataFileRecordSheetName = 'FactoryDataFileUpload'

    duplicateFactoryDataTitle = ['FileName', 'DeviceId', 'ConflictType', 'OriginalValue', 'DuplicateValue', 'ParseTime']
    duplicateFactoryDataSheetName = 'DuplicateDataRecord'

    notNormalFactoryDataTitle = ['deviceId', 'mac', 'sn', 'fwId', 'hwId', 'recordTime',
                                 'categoryName', 'hwType', 'hwVer']
    notNormalFactoryDataSheetName = 'NotNormalDataRecord'

    duplicateDeviceList = []
    deviceList = []
    reportMutex = thread.allocate_lock()


    @classmethod
    def addDuplicateFactoryDataRecord(cls, fileName, deviceId, conflictType, originalValue, duplicateValue):
        cls.reportMutex.acquire()
        try:
            cls.duplicateDeviceList.append({
                'fileName': fileName,
                'deviceId': deviceId,
                'conflictType': conflictType,
                'originalValue': originalValue,
                'duplicateValue': duplicateValue,
                'recordTime': time.strftime(cls.timeFormat, time.localtime())
            })
        except:
            logger.error('Add factory data record to excel error, reason is %s', traceback.format_exc())
        finally:
            cls.reportMutex.release()

    @classmethod
    def addFactoryData(cls, device):
        cls.reportMutex.acquire()
        try:
            cls.deviceList.append({
                'deviceId': device['deviceId'],
                'mac': device['mac'],
                'sn': device['sn'],
                'fwId': device['fwId'],
                'hwId': device['hwId'],
                'recordTime': device['recordTime'],
                'categoryName': device['categoryName'],
                'hwType': device['hwType'],
                'hwVersion': device['hwVersion']
            })
        except:
            logger.error('Add factory data record error, reason is %s', traceback.format_exc())
        finally:
            cls.reportMutex.release()

    # @classmethod
    # def saveNotNormalFactoryData2File(cls):
    #     cls.reportMutex.acquire()
    #     try:
    #         logger.info("Saving device record from memory into file")
    #         readbook = cls.openWorkbook()
    #         writebook = xlutils.copy.copy(readbook)
    #         nrows = readbook.sheets()[NOT_NORMAL_FACTORY_DATA_SHEET_NUM].nrows
    #         sheet = writebook.get_sheet(NOT_NORMAL_FACTORY_DATA_SHEET_NUM)
    #
    #         for device in cls.deviceList:
    #             content = [device['deviceId'], device['mac'], device['sn'],
    #                        device['fwId'], device['hwId'], device['recordTime'],
    #                        device['categoryName'], device['hwType'], device['hwVersion']]
    #             cls.writeRows(sheet, nrows, content)
    #             nrows += 1
    #
    #         cls.save(writebook)
    #         cls.deviceList = []
    #     except:
    #         logger.error('Add factory data record to excel error, reason is %s', traceback.format_exc())
    #     finally:
    #         cls.reportMutex.release()
    #
    # @classmethod
    # def geneareReport(cls):
    #     cls.reportMutex.acquire()
    #     try:
    #         readbook = cls.openWorkbook()
    #         uploadRecordsheet = readbook.sheets()[UPLOAD_RECORD_SHEET_NUM]
    #         factoryDatasheet = readbook.sheets()[FACTORY_DATA_SHEET_NUM]
    #         notAbnoramlDatasheet = readbook.sheets()[NOT_NORMAL_FACTORY_DATA_SHEET_NUM]
    #
    #         dailyReport = xlsxwriter.Workbook(cls.getFactoryReportPath())
    #
    #         factoryBasicInfo = cls.addFactoryDataFileSheet(dailyReport, uploadRecordsheet)
    #         cls.addAbnormalDeviceSheet(dailyReport, factoryDatasheet)
    #         cls.addNotNormalDeviceSheet(dailyReport, notAbnoramlDatasheet)
    #
    #         dailyReport.close()
    #         cls.removeExcel()
    #     except:
    #         logger.error('Generate factory weekly report error, reason is %s', traceback.format_exc())
    #     finally:
    #         cls.reportMutex.release()
    #
    #     return factoryBasicInfo

    @classmethod
    def addFactoryDataFileSheet(cls, workbook, dataSheet):

        partTitleFormat = workbook.add_format(cls.partTitleStyle)
        titleFormat = workbook.add_format(cls.titleStyle)
        contentFormat = workbook.add_format(cls.contentStyle)
        contentHighlightFormat = workbook.add_format(cls.contentHighligtStyle)

        worksheet = workbook.add_worksheet(u'生产数据文件上传情况')

        # the width of column
        worksheet.set_column('A:A', 40)
        worksheet.set_column('B:B', 25)
        worksheet.set_column('C:E', 15)

        factoryDataHandlerTotal = [u'生产数据文件总数', u'生产数据总数', u'合法数据总数', u'非法数据总数']
        factoryDataHandlerDetail = [u'生产数据文件名', u'处理时间', u'生产数据总条目', u'合法数据条目', u'非法数据条目']

        # date of report
        worksheet.write('A2', u'统计日期', titleFormat)
        worksheet.write('B2', time.strftime("%Y/%m/%d %Z", time.localtime()), contentFormat)

        # record of the upload of factory data file
        worksheet.merge_range(7, 0, 7, 4, u'生产数据处理详情', partTitleFormat)
        worksheet.write_row('A9', factoryDataHandlerDetail, titleFormat)

        # info of factory data file
        # factory file which contains invalid data
        rowtotal = dataSheet.nrows
        originRow = 1
        targetRow = 9
        validTotal = 0
        inValidTotal = 0
        while originRow < rowtotal:
            inValidCount = int(dataSheet.cell(originRow, INVALID_DATA_COL).value)
            validCount = int(dataSheet.cell(originRow, VALID_DATA_COL).value)
            validTotal += validCount
            inValidTotal += inValidCount
            if inValidCount is 0:
                originRow += 1
                continue

            worksheet.write_row(targetRow, 0, [
                dataSheet.cell(originRow, 0).value,
                dataSheet.cell(originRow, 1).value,
                dataSheet.cell(originRow, 2).value,
                dataSheet.cell(originRow, 3).value,
                dataSheet.cell(originRow, 4).value
            ], contentHighlightFormat)

            originRow += 1
            targetRow += 1

        # factory file which does not contain invalid data
        originRow = 1
        rowtotal = dataSheet.nrows
        while originRow < rowtotal:
            inValidCount = int(dataSheet.cell(originRow, INVALID_DATA_COL).value)
            if inValidCount is not 0:
                originRow += 1
                continue

            worksheet.write_row(targetRow, 0, [
                dataSheet.cell(originRow, 0).value,
                dataSheet.cell(originRow, 1).value,
                dataSheet.cell(originRow, 2).value,
                dataSheet.cell(originRow, 3).value,
                dataSheet.cell(originRow, 4).value
            ], contentFormat)

            originRow += 1
            targetRow += 1

        # overall of the upload of factory data file
        worksheet.merge_range(3, 0, 3, 3, u'生产数据处理概况', partTitleFormat)
        worksheet.write_row('A5', factoryDataHandlerTotal, titleFormat)
        worksheet.write('A6', targetRow - 9, contentFormat)
        worksheet.write('B6', '=SUM(C10:C' + str(targetRow) + ')', contentFormat)
        worksheet.write('C6', '=SUM(D10:D' + str(targetRow) + ')', contentFormat)
        worksheet.write('D6', '=SUM(E10:E' + str(targetRow) + ')', contentFormat)

        factoryBasicInfo = {
            'fileTotal': targetRow - 9,
            'dataTotal': validTotal + inValidTotal,
            'validTotal': validTotal,
            'inValidTotal': inValidTotal
        }
        return factoryBasicInfo

    @classmethod
    def addAbnormalDeviceSheet(cls, workbook, dataSheet):

        partTitleFormat = workbook.add_format(cls.partTitleStyle)
        titleFormat = workbook.add_format(cls.titleStyle)
        contentFormat = workbook.add_format(cls.contentStyle)

        worksheet = workbook.add_worksheet(u'异常设备记录')

        factoryDataExceptionDetail = [u'生产数据文件名', u'DeviceId', u'异常类型', u'原始数值', u'覆盖数值', u'处理时间']
        factoryException = {
            'MAC CONFLICT': u'MAC地址不一致',
            'HW CONFLICT': u'硬件不一致',
            'HW_ID CONFLICT': u'硬件ID不一致',
            'SN CONFLICT': u'SN号不一致',
            'FW CONFLICT': u'固件ID不一致',
            'DATA FORMAT ERROR': u'数据格式错误',
            'CATEGORY INVALID': u'数据品牌大类不合法'
        }

        # the width of column
        worksheet.set_column('A:A', 40)
        worksheet.set_column('B:B', 45)
        worksheet.set_column('C:C', 20)
        worksheet.set_column('D:D', 40)
        worksheet.set_column('E:E', 40)
        worksheet.set_column('F:F', 20)

        # the format of factory data
        worksheet.merge_range(1, 0, 1, 1, u'生产数据格式说明', partTitleFormat)
        worksheet.merge_range(2, 0, 2, 1, 'DeviceID, MacID, SSNo, FwID, HardwareID, RecordTime, CategoryName, '
                                          'HardwareType, HardwareVersion', contentFormat)

        # record of abnormal device
        worksheet.merge_range(4, 0, 4, 5, u'异常记录', partTitleFormat)
        worksheet.write_row('A6', factoryDataExceptionDetail, titleFormat)

        # abnormal device data
        # info of factory data file
        originRow = 1
        rowtotal = dataSheet.nrows
        targetRow = 6
        while originRow < rowtotal:
            worksheet.write_row(targetRow, 0, [
                                dataSheet.cell(originRow, 0).value,
                                dataSheet.cell(originRow, 1).value,
                                factoryException[dataSheet.cell(originRow, 2).value],
                                dataSheet.cell(originRow, 3).value,
                                dataSheet.cell(originRow, 4).value,
                                dataSheet.cell(originRow, 5).value
                                ], contentFormat)

            originRow += 1
            targetRow += 1

        # add filter for table
        worksheet.autofilter('A6:F' + str(targetRow))

    @classmethod
    def addNotNormalDeviceSheet(cls, workbook, dataSheet):

        partTitleFormat = workbook.add_format(cls.partTitleStyle)
        titleFormat = workbook.add_format(cls.titleStyle)
        contentFormat = workbook.add_format(cls.contentStyle)

        worksheet = workbook.add_worksheet(u'通过接口上传记录')

        factoryDataDetail = [u'deviceId', u'mac', u'sn', u'fwId', u'hwId',
                             u'recordTime', u'categoryName', u'hwType', u'hwVer']

        # the width of column
        worksheet.set_column('A:A', 45)
        worksheet.set_column('B:B', 30)
        worksheet.set_column('C:C', 20)
        worksheet.set_column('D:D', 40)
        worksheet.set_column('E:E', 40)
        worksheet.set_column('F:F', 20)
        worksheet.set_column('G:G', 40)
        worksheet.set_column('H:H', 30)
        worksheet.set_column('I:I', 10)

        # record of not normal device
        worksheet.write_row('A1', factoryDataDetail, titleFormat)

        # abnormal device data
        # info of factory data file
        originRow = 1
        rowtotal = dataSheet.nrows
        targetRow = 1
        while originRow < rowtotal:
            worksheet.write_row(targetRow, 0, [
                dataSheet.cell(originRow, 0).value,
                dataSheet.cell(originRow, 1).value,
                dataSheet.cell(originRow, 2).value,
                dataSheet.cell(originRow, 3).value,
                dataSheet.cell(originRow, 4).value,
                dataSheet.cell(originRow, 5).value,
                dataSheet.cell(originRow, 6).value,
                dataSheet.cell(originRow, 7).value,
                dataSheet.cell(originRow, 8).value
            ], contentFormat)

            originRow += 1
            targetRow += 1

        # add filter for table
        worksheet.autofilter('A1:F' + str(targetRow))
