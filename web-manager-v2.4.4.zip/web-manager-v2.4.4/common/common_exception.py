# -*- coding:utf-8 -*-
#
# Copyright (c) 2014, TP-Link Co.,Ltd.
# Author:  zhaofeng <zhaofeng@tp-link.net>
# Created: 2016-5-6
#
#


class DalRequestError(Exception):
    
    def __init__(self, errMsg = 'request to DAL failed'):
        Exception.__init__(self, errMsg)


class DalServerError(Exception):
    
    def __init__(self, errMsg = 'DAL server internal error'):
        Exception.__init__(self, errMsg)


class ObjectNotFind(Exception):

    def __init__(self, errMsg = 'Object dose not find!'):
        Exception.__init__(self, errMsg)


class DalResponseError(Exception):
    
    def __inif__(self, errMsg = 'DAL response error'):
            Exception.__init__(self, errMsg)
