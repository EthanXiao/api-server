# -*- coding: utf-8 -*- 
#
# Copyright (c) 2014, TP-Link Co.,Ltd.
# Author:  zhaofeng <zhaofeng@tp-link.net>
# Created: 2016-8-20
#
#

import logging
import traceback

from webmanager.settings import Config
from common.http_client import DALClient
from common.common_exception import DalServerError, ObjectNotFind, DalResponseError

logger = logging.getLogger(__name__)
dalVersionPath = Config['dalVersionPath']


class CommonBase:
    getURL = ''
    setURL = ''
    updateURL = ''
    delURL = ''
    getListURL = ''

    version = ''
    id = ''

    @classmethod
    def filter(cls, **kwargs):
        response = list()
        try:
            dal_client = DALClient()
            params = dal_client.group_params(kwargs)
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getListURL + query_id
            response = dal_client.send_get_request(url, params)
        except ObjectNotFind:
            logger.info('NOT FIND , query params is is %s' % kwargs)
        finally:
            dal_client.close()

        li = list()
        for app in response:
            li.append(cls.convert_dict_to_obj(app))
        return li

    def convert_to_dict(self):
        dicts = {}
        dicts.update(self.__dict__)
        # for key in list(dicts.keys()):
        #     if dicts[key] == '' or dicts[key] is None:
        #         del(dicts[key])
        return dicts

    @classmethod
    def convert_dict_to_obj(cls, resultDict):
        try:
            if resultDict == 'null' or resultDict is None or resultDict == '':
                return None
            self = cls()
            for k, v in resultDict.iteritems():
                if hasattr(self, k):
                    if v == 'null' or v == '':
                        v = None
                    setattr(self, k, v)
                else:
                    logger.debug('WARNING : class [ %s ] has no attribute [ %s ]', cls.__name__, k)
            return self
        except:
            logger.error('ERROR : class [ %s ] convertDictToObj failed. dict is [ %s ]', cls.__name__, resultDict)
            logger.error(traceback.format_exc())
            raise Exception


class CommonBaseMainland(CommonBase):
    def __init__(self, **kwargs):
        for k, v in kwargs.iteritems():
            setattr(self, k, v)

    def save(self):
        try:
            dal_client = DALClient()
            params = self.convert_to_dict()
            query_id = dal_client.get_query_id()
            url = dalVersionPath + self.setURL + query_id
            dal_client.send_post_request(url, params)
        except (DalResponseError, DalServerError):
            logger.error('save entity failed')
            raise
        finally:
            dal_client.close()
        return

    def update(self):
        try:
            dal_client = DALClient()
            params = self.convert_to_dict()
            query_id = dal_client.get_query_id()
            url = dalVersionPath + self.updateURL + query_id
            dal_client.send_post_request(url, params)
        except (DalResponseError, DalServerError):
            logger.error('save entity failed')
            raise
        finally:
            dal_client.close()
        return

    @classmethod
    def filter(cls, **kwargs):
        response = list()
        try:
            dal_client = DALClient()
            params = kwargs
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getListURL + query_id
            response = dal_client.send_post_request(url, params)
        except ObjectNotFind:
            logger.info('NOT FIND , query params is %s' % kwargs)
        finally:
            dal_client.close()

        li = list()
        for app in response:
            li.append(cls.convert_dict_to_obj(app))
        return li

    def delete(self):
        try:
            dal_client = DALClient()
            params = self.convert_to_dict()
            query_id = dal_client.get_query_id()
            url = dalVersionPath + self.delURL + query_id
            dal_client.send_post_request(url, params)
        except:
            logger.error('delete entity failed')
            raise
        finally:
            dal_client.close()


class CommonBaseGlobal(CommonBase):
    def __init__(self, **kwargs):
        for k, v in kwargs.iteritems():
            setattr(self, k, v)

    def save(self):
        try:
            dal_client = DALClient()
            params = self.convert_to_dict()
            query_id = dal_client.get_query_id()
            url = dalVersionPath + self.setURL + query_id
            dal_client.send_post_request(url, params)
        except (DalResponseError, DalServerError):
            logger.error('save entity failed')
            raise
        finally:
            dal_client.close()
        return

    def update(self):
        try:
            dal_client = DALClient()
            params = self.convert_to_dict()
            query_id = dal_client.get_query_id()
            url = dalVersionPath + self.updateURL + query_id
            dal_client.send_post_request(url, params)
        except (DalResponseError, DalServerError):
            logger.error('save entity failed')
            raise
        finally:
            dal_client.close()
        return

    @classmethod
    def find_unique(cls, **kwargs):
        response = None
        try:
            dal_client = DALClient()
            params = kwargs
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getURL + query_id
            response = dal_client.send_post_request(url, params)
        except (DalResponseError, DalServerError):
            logger.error('find entity failed. %s', traceback.format_exc())
            raise
        finally:
            dal_client.close()
        return cls.convert_dict_to_obj(response)

    @classmethod
    def filter(cls, **kwargs):
        response = list()
        try:
            dal_client = DALClient()
            params = kwargs
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getListURL + query_id
            response = dal_client.send_post_request(url, params)
        except ObjectNotFind:
            logger.info('NOT FIND , query params is %s' % kwargs)
        finally:
            dal_client.close()

        li = list()
        for app in response:
            li.append(cls.convert_dict_to_obj(app))
        return li

    def delete(self):
        try:
            dal_client = DALClient()
            params = self.convert_to_dict()
            query_id = dal_client.get_query_id()
            url = dalVersionPath + self.delURL + query_id
            dal_client.send_post_request(url, params)
        except:
            logger.error('delete entity failed')
            raise
        finally:
            dal_client.close()
