# -*- coding:utf-8 -*-
#
# Copyright (c) 2017, TP-Link Co.,Ltd.
# Author:  yuzhijiang <caishupeng@tp-link.net>
# Created: 2017-12-3
#
#

# import xlwt
# import xlrd
import os
from os.path import join

from webmanager.settings import Config


class ExcelBase:

    workbookPath = Config['reportExcelPath']
    workbookName = 'Cloud_Factory_Data_Record.xls'
    factoryReportName = 'Cloud_Factory_Data_Report.xlsx'

    timeFormat = "%Y-%m-%d %H:%M:%S"

    columnWidth = 256 * 45

    partTitleStyle = {
        'bold': True,
        'bg_color': '#c6efce',
        'font_name': '微软雅黑',
        'font_size': 10,
        'border': True
    }

    titleStyle = {
        'bold': True,
        'bg_color': '#c6efce',
        'align': 'center',
        'font_name': '微软雅黑',
        'font_size': 10,
        'border': True
    }

    contentStyle = {
        'valign': 'vcenter',
        'font_name': '微软雅黑',
        'font_size': 10,
        'border': True,
        'text_wrap': True
    }

    contentHighligtStyle = {
        'valign': 'vcenter',
        'font_name': '微软雅黑',
        'font_size': 10,
        'font_color': 'red',
        'border': True,
        'text_wrap': True
    }

    @classmethod
    def writeRows(cls, sheet, rowNum, contentList):
        for i in range(len(contentList)):
            sheet.write(rowNum, i, contentList[i])
            sheet.col(i).width = cls.columnWidth

    @classmethod
    def addSheet(cls, workbook, sheetName, titleList):
        sheet = workbook.add_sheet(sheetName)
        cls.addTitle(sheet, titleList)
        return sheet

    @classmethod
    def addTitle(cls, sheet, titleList):
        for i in range(len(titleList)):
            sheet.write(0, i, titleList[i])
        return sheet

    # @classmethod
    # def newExcelFile(cls):
    #     if cls.isExcelFileExist():
    #         return
    #     workbook = xlwt.Workbook(encoding='utf-8')
    #     workbook.save(join(cls.workbookPath, cls.workbookName))

    @classmethod
    def isExcelFileExist(cls):
        return os.path.exists(join(cls.workbookPath, cls.workbookName))

    @classmethod
    def removeExcel(cls):
        if os.path.exists(join(cls.workbookPath, cls.workbookName)):
            os.remove(join(cls.workbookPath, cls.workbookName))

    @classmethod
    def getExcelPath(cls):
        return join(cls.workbookPath, cls.workbookName)

    @classmethod
    def getFactoryReportPath(cls):
        return join(cls.workbookPath, cls.factoryReportName)

    @classmethod
    def removeFactoryReport(cls):
        if os.path.exists(join(cls.workbookPath, cls.factoryReportName)):
            os.remove(join(cls.workbookPath, cls.factoryReportName))
    #
    # @classmethod
    # def openWorkbook(cls):
    #     if not cls.isExcelFileExist():
    #         cls.newExcelFile()
    #     readbook = xlrd.open_workbook(join(cls.workbookPath, cls.workbookName))
    #     return readbook

    @classmethod
    def save(cls, workbook):
        workbook.save(join(cls.workbookPath, cls.workbookName))
