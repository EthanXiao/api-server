# -*- coding: utf-8 -*- 

import httplib
import urllib
import logging
import json
import time
import ast

from webmanager.settings import Config
from common.common_exception import DalServerError, DalResponseError

logger = logging.getLogger(__name__)


class DALClient:
    DALHost = Config['dalDefaultHost']
    httpClient = None

    def __init__(self, host=None):
        if host is not None:
            self.DALHost = host
        self.httpClient = httplib.HTTPConnection(self.DALHost)

    def send_get_request(self, uri, params):
        url = uri + '&' + params
        logger.debug('send GET request to DAL. URL IS [ %s ]', url)

        self.httpClient.request('GET', url)
        result = self.httpClient.getresponse()

        if result.status != 200:
            logger.error('send GET request failed! the url is [ %s ], params is [ %s ], '
                         'response is [ %s ]' % (url, params, result.read()))
            raise DalServerError('request DAL failed, the HTTP Code is [ %s ]' % result.status)

        response = ast.literal_eval(
            result.read().replace('null', "'null'").replace('true', "'true'").replace('false', "'false'"))
        if response['errorCode'] != 0 and response['success'] != 'true':
            logger.error('send GET request failed! the url is [ %s ], params is [ %s ],errorCode is [ %s ],'
                         'errorMsg is [ %s ]' % (url, params, response['errorCode'], response['errorMsg']))
            raise DalResponseError()

        logger.debug('response is [ %s ]', response['responseBody'])
        return response['responseBody']

    def send_post_request(self, url, params):
        logger.debug('send POST request to DAL. URL is [ %s ], params [ %s ]', url, params)

        header = {'Content-type': 'application/json'}
        self.httpClient.request('POST', url, json.dumps(params), header)
        result = self.httpClient.getresponse()
        if result.status != 200:
            logger.error('send POST request failed! URL is [ %s ], params is [ %s ], '
                         'response is [ %s ]' % (url, params, result.read()))
            raise DalServerError('request DAL failed, the HTTP Code is [ %s ]' % result.status)

        response = ast.literal_eval(
            result.read().replace('null', "'null'").replace('true', "'true'").replace('false', "'false'"))

        return response

    def close(self):
        self.httpClient.close()

    def group_params(self, stringParams):
        return urllib.urlencode(stringParams)

    def convert_to_dict(self, obj):
        dicts = {}
        dicts.update(obj.__dict__)
        return dicts

    def convert_dict_to_obj(self, obj, resultDict):
        for k, v in resultDict.iteritems():
            if len(getattr(obj, k)) != 0:
                continue
            setattr(obj, k, v)
        return obj

    def get_query_id(self):
        return self.group_params({'id': int(time.time() * 1000)})


class OpDataReceiverClient:
    OpHost = Config['opDataReceiverHost']
    httpClient = None

    def __init__(self, host=None):
        if host is not None:
            self.OpHost = host
        self.httpClient = httplib.HTTPConnection(self.OpHost)

    def send_get_request(self, uri, params):
        url = uri + '&' + params
        logger.debug('send GET request to opDataReceiver. URL IS [ %s ]', url)

        self.httpClient.request('GET', url)
        result = self.httpClient.getresponse()
        if result.status != 200:
            logger.error('send GET request to opDataReceiver failed! the url is [ %s ], params is [ %s ], '
                         'response is [ %s ]' % (url, params, result.read()))
            raise DalServerError('request opDataReceiver failed, the HTTP Code is [ %s ]' % result.status)

        response = ast.literal_eval(
            result.read().replace('null', "'null'").replace('true', "'true'").replace('false', "'false'"))
        if response['errorCode'] != 0 and response['success'] != 'true':
            logger.error(
                'send GET request to opDataReceiver failed! the url is [ %s ], params is [ %s ],errorCode is [ %s ],'
                'errorMsg is [ %s ]' % (url, params, response['errorCode'], response['errorMsg']))
            raise DalResponseError()

        logger.debug('response is [ %s ]', response['responseBody'])
        return response['responseBody']

    def send_post_request(self, url, params):
        logger.debug('send POST request to opDataReceiver. URL is [ %s ], params [ %s ]', url, params)

        header = {'Content-type': 'application/json'}

        self.httpClient.request('POST', url, json.dumps(params), header)

        result = self.httpClient.getresponse()

        if result.status != 200:
            logger.error('send POST request to opDataReceiver failed! URL is [ %s ], params is [ %s ], '
                         'response is [ %s ]' % (url, params, result.read()))
            raise DalServerError('request opDataReceiver failed, the HTTP Code is [ %s ]' % result.status)

        response = ast.literal_eval(
            result.read().replace('null', "'null'").replace('true', "'true'").replace('false', "'false'"))
        return response

    def close(self):
        self.httpClient.close()

    def group_params(self, stringParams):
        return urllib.urlencode(stringParams)

    def convert_to_dict(self, obj):
        dicts = {}
        dicts.update(obj.__dict__)
        return dicts

    def convert_dict_to_obj(self, obj, resultDict):
        for k, v in resultDict.iteritems():
            if len(getattr(obj, k)) != 0:
                continue
            setattr(obj, k, v)
        return obj

    def get_query_id(self):
        return self.group_params({'id': int(time.time() * 1000)})
