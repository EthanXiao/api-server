# -*- coding:utf-8 -*-
#
# Copyright (c) 2014, TP-Link Co.,Ltd.
# Author:  zhaofeng <zhaofeng@tp-link.net>
# Created: 2016-3-22
#
#

import hashlib


# use the sha1 algorithm to get the sha1 string
def get_sha1(src):
    return hashlib.sha1(src).hexdigest()


# get upload file MD5
def get_md5(file):
    m = hashlib.md5()
    while True:
        data = file.read(1024)
        if not data:
            break
        m.update(data)
    return m.hexdigest()


def get_string_md5(src):
    m = hashlib.md5()
    m.update(src)
    return m.hexdigest().upper()


def fuzzy_finder(user_input, collection):
    matched = collection.find(user_input, 0, len(collection))  # Converts 'djm' to 'd.*j.*m'
    if matched == -1:
        return False
    else:
        return True
