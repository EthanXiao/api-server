# -*- coding:utf-8 -*-
#
# Copyright (c) 2017, TP-Link Co.,Ltd.
# Author:  Zhijiang Yu<yuzhijiang@tp-link.com.cn>
# Created: 2017-11-1
#
#
import logging
import traceback
import time

from common.http_client import DALClient, OpDataReceiverClient
from common.common_base_model import CommonBase, CommonBaseMainland, CommonBaseGlobal
from common.common_exception import DalResponseError, DalServerError
from webmanager.settings import Config

dalVersionPath = Config['dalVersionPath']
opDataReceiverPath = Config['opDataReceiverPath']
logger = logging.getLogger(__name__)
isGlobal = Config['isGlobal']


class AppVersionInfo(CommonBase):
    getExactlyURL = 'getAppVersionInfo?'
    addListURL = 'firmware/saveDeviceFactoryInfo?'
    updateURL = 'updateMysqlFirmwareInfo?'
    delURL = 'delFirmwareInfo?'

    getURL = 'getAppVersionInfoListFuzzilyByPage?'
    getCountURL = 'getAppVersionInfoCountFuzzily?'

    packageName = ''
    onShelf = ''
    appName = ''
    appVersionId = ''
    appVersionCode = ''
    platform = ''

    def __init__(self, **kwargs):
        for k, v in kwargs.iteritems():
            setattr(self, k, v)

    @classmethod
    def get_data_mysql_by_page(cls, request_body):
        try:
            dal_client = DALClient()
            start_page = long(request_body['start'])
            page_length = long(request_body['length'])

            params_url_tempt = {}
            params_url_tempt['start'] = start_page
            params_url_tempt['length'] = page_length
            params_url = dal_client.group_params(params_url_tempt)

            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()

            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getURL + query_id + '&' + params_url

            response = dal_client.send_post_request(url, params)

        except (DalResponseError, DalServerError):
            logger.error('paging query failed. %s', traceback.format_exc())
            raise
        finally:
            dal_client.close()
        return response

    @classmethod
    def get_data_mysql_count(cls, request_body):
        ''' obtain the count of the records that satisfy the query conditions.
            if the query conditions are all null, the output is the total number of records in the queried table.
        '''
        try:
            dal_client = DALClient()
            params_url_tempt = {}

            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()

            params_url = dal_client.group_params(params_url_tempt)
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getCountURL + query_id + '&' + params_url

            response = dal_client.send_post_request(url, params)
        except (DalResponseError, DalServerError):
            raise
        finally:
            dal_client.close()
        return response


    # the response data of the function is of type-dict
    @classmethod
    def get_data_mysql_exactly(cls, request_body):  # queried by device_id
        try:
            dal_client = DALClient()
            params_tempt = cls.convert_dict_to_obj(request_body)
            params_dict = params_tempt.convert_to_dict()
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getExactlyURL + query_id
            if isGlobal:
                params = dal_client.group_params(params_dict)
                response = dal_client.send_get_request(url, params)
            else:
                response_all = dal_client.send_post_request(url, params_dict)
                response = response_all['responseBody']
        except (DalResponseError, DalServerError):
            raise

        finally:
            dal_client.close()

        return response

    @classmethod
    def update_data_mysql(cls, request_body):
        try:
            dal_client = DALClient()
            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.updateURL + query_id

            response = dal_client.send_post_request(url, params)

        except (DalResponseError, DalServerError):
            logger.error('update account info failed.')
            raise
        finally:
            dal_client.close()
        return response

    @classmethod
    def del_data_mysql(cls, request_body):
        try:
            dal_client = DALClient()
            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()

            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.delURL + query_id
            response = dal_client.send_post_request(url, params)

        except (DalResponseError, DalServerError):
            raise
        finally:
            dal_client.close()

        return response

    @classmethod
    def delete_redis_KEY(cls, redisKey):
        # delGlobalURL = 'deleteFromRedisCluster?'  # old
        delGlobalURL = 'delKeyCrossRegion?'  # new
        delMainlandURL = 'cacheDel?'

        logger.info('remove redis for key %s', redisKey)
        try:
            dal_client = DALClient()
            query_id = dal_client.get_query_id()
            if Config['isGlobal']:
                url = dalVersionPath + delGlobalURL + query_id
                dal_client.send_post_request(url, {'cacheKey': redisKey})
            else:
                url = dalVersionPath + delMainlandURL + query_id
                dal_client.send_post_request(url, {'key': [redisKey]})
        except:
            logger.error('delete redis cache failed.')
            raise
        finally:
            dal_client.close()

    @classmethod
    def findById(cls, deviceId):
        response = None
        try:
            dal_client = DALClient()
            paramsDict = {'deviceId': deviceId}
            params = dal_client.group_params(paramsDict)
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getExactlyURL + query_id
            response = dal_client.send_get_request(url, params)
        except (DalResponseError, DalServerError):
            logger.error('find device factory info failed. %s', traceback.format_exc())
            raise
        finally:
            dal_client.close()
        return cls.convert_dict_to_obj(response)


class AppReleaseTaskInfo(CommonBase):
    getExactlyURL = ''
    getListURL = 'getFwReleaseTaskInfoList?'
    setURL = ''
    getURL = 'getAppReleaseTaskInfoListFuzzilyByPage?'
    getCountURL = 'getAppReleaseTaskInfoCountFuzzily?'

    packageName = ''
    taskId = ''

    def __init__(self, **kwargs):
        for k, v in kwargs.iteritems():
            setattr(self, k, v)

    @classmethod
    def get_data_mysql_exactly(cls, request_body):  # queried by hwType and hwVersion
        try:
            dal_client = DALClient()
            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getExactlyURL + query_id
            response = dal_client.send_post_request(url, params)
        except (DalResponseError, DalServerError):
            raise

        finally:
            dal_client.close()
        return response

    @classmethod
    def get_data_mysql_list(cls, request_body):
        try:
            dal_client = DALClient()
            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()

            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getListURL + query_id
            response = dal_client.send_post_request(url, params)
        except (DalResponseError, DalServerError):
            raise
        finally:
            dal_client.close()
        return response

    @classmethod
    def get_data_mysql_by_page(cls, request_body):
        try:
            dal_client = DALClient()
            start_page = long(request_body['start'])
            page_length = long(request_body['length'])

            params_url_tempt = {}
            params_url_tempt['start'] = start_page
            params_url_tempt['length'] = page_length
            params_url = dal_client.group_params(params_url_tempt)

            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()

            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getURL + query_id + '&' + params_url

            response = dal_client.send_post_request(url, params)
        except (DalResponseError, DalServerError):
            raise
        finally:
            dal_client.close()
        return response

    @classmethod
    def get_data_mysql_count(cls, request_body):
        try:
            dal_client = DALClient()

            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()

            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getCountURL + query_id

            response = dal_client.send_post_request(url, params)

        except (DalResponseError, DalServerError):
            raise
        finally:
            dal_client.close()
        return response

    def save(self):
        response = None
        try:
            dalClient = DALClient()
            params = self.convert_to_dict()
            queryId = dalClient.get_query_id()
            url = dalVersionPath + self.setURL + queryId
            dalClient.send_post_request(url, params)
        except (DalResponseError, DalServerError):
            logger.error('save new model failed.')
            raise
        finally:
            dalClient.close()
        return response


class AppLinkInfo(CommonBase):
    getExactlyURL = 'getAppInfo?'

    getListURL = 'getAppInfoList?'

    packageName = ''
    accountId = ''

    def __init__(self, **kwargs):
        for k, v in kwargs.iteritems():
            setattr(self, k, v)

    # the response data of the function is of type-dict
    @classmethod
    def get_data_mysql_exactly(cls, request_body):  # queried by device_id
        try:
            dal_client = DALClient()
            params_tempt = cls.convert_dict_to_obj(request_body)
            params_dict = params_tempt.convert_to_dict()
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getExactlyURL + query_id
            response = dal_client.send_post_request(url, params_dict)
        except (DalResponseError, DalServerError):
            raise
        finally:
            dal_client.close()
        return response

    @classmethod
    def get_data_mysql_list(cls, request_body):
        try:
            dal_client = DALClient()
            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()

            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getListURL + query_id
            response = dal_client.send_post_request(url, params)
        except (DalResponseError, DalServerError):
            raise
        finally:
            dal_client.close()
        return response


class AppNewLinkInfo(CommonBase):
    getExactlyURL = 'getAppNewInfo?'

    getListURL = 'getAppNewInfoList?'

    packageName = ''
    accountId = ''
    appKey = ''

    def __init__(self, **kwargs):
        for k, v in kwargs.iteritems():
            setattr(self, k, v)

    # the response data of the function is of type-dict
    @classmethod
    def get_data_mysql_exactly(cls, request_body):  # queried by device_id
        try:
            dal_client = DALClient()
            params_tempt = cls.convert_dict_to_obj(request_body)
            params_dict = params_tempt.convert_to_dict()
            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getExactlyURL + query_id
            response = dal_client.send_post_request(url, params_dict)
        except (DalResponseError, DalServerError):
            raise
        finally:
            dal_client.close()
        return response

    @classmethod
    def get_data_mysql_list(cls, request_body):
        try:
            dal_client = DALClient()
            params_tempt = cls.convert_dict_to_obj(request_body)
            params = params_tempt.convert_to_dict()

            query_id = dal_client.get_query_id()
            url = dalVersionPath + cls.getListURL + query_id
            response = dal_client.send_post_request(url, params)
        except (DalResponseError, DalServerError):
            raise
        finally:
            dal_client.close()
        return response

