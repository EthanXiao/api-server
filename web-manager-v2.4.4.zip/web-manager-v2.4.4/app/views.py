# -*- coding:utf-8 -*-
#
# Copyright (c) 2017, TP-Link Co.,Ltd.
# Author:  yuzhijiang <yuzhijiang@tp-link.com.cn>
# Created: 2017-10-10
#
#
import datetime
import json
import logging
import traceback

from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader

from app.models import AppVersionInfo, AppReleaseTaskInfo, AppLinkInfo, AppNewLinkInfo
from common.mysql_dao import MysqlOp
from firmware.models import FirmwareReleaseTaskInfo
from interceptor.auth_interceptor import check_authority
from webmanager.conf import conf
from webmanager.settings import MySQLConfig, Config

logger = logging.getLogger(__name__)
isGlobal = Config['isGlobal']


def get_app_info(request):
    str = 'app/app-info/app-info.html'
    str_login = '/webManager/login'
    try:
        session = request.COOKIES["session_id"]

        mysql_op = MysqlOp(MySQLConfig['host'],
                           MySQLConfig['port'],
                           MySQLConfig['user'],
                           MySQLConfig['passwd'],
                           MySQLConfig['db'])
        session_info = mysql_op.check_session(session)

        if session_info is not None:
            if isGlobal:
                response_data = {'priority_fields': conf.all_fields_app_version_filter.get('priority')}
            else:
                response_data = {'priority_fields': conf.all_fields_app_version_mainland_filter.get('priority')}

            email = session_info['email']
            response_data.update({'user': email.split("@")[0], 'web_user_role': session_info.get('role_id'),
                                  'isGlobal': isGlobal})

            response = render(request, str, response_data)
            response.set_cookie("session_id", session, conf.session_ttl)
            return response
        else:
            logger.warn("get_app_info. checking-session failed. the session is ------>%s" % session)
            return HttpResponseRedirect(str_login)
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        return HttpResponseRedirect(str_login)


@check_authority
def read_app_info(request):
    request_body = request.POST.copy()

    logger.info("read_app_info started. the request is ------>%s", request_body)

    content_type = request.META['CONTENT_TYPE']
    if 'application/json' in content_type:
        request_body.update(json.loads(request.body))

    try:
        response = AppVersionInfo.get_data_mysql_by_page(request_body)
        response_count = AppVersionInfo.get_data_mysql_count(request_body)
        response_data = response['responseBody']
        records_filtered = response_count['responseBody']

        records_total_count = AppVersionInfo.get_data_mysql_count({"firmwareId": ""})
        records_total = records_total_count["responseBody"]
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        raise

    if type(response_data) is type(list()):
        data = {'data': response_data, 'recordsFiltered': records_filtered, 'recordsTotal': records_total}
    elif type(response_data) is type(dict()):
        response_temp = [response_data]
        data = {'data': response_temp, 'recordsFiltered': 1, 'recordsTotal': records_total}
    else:
        response_temp = []
        data = {'data': response_temp, 'recordsFiltered': 0, 'recordsTotal': records_total}
        logger.info("the type of the data from DAL is -----> %s" % type(response_data))
    return HttpResponse(json.dumps(data))


@check_authority
def get_app_extra_info(request):
    str_device_detail = 'app/app-info/app-extra-info.html'
    request_body = request.POST.copy()
    package_name = request_body.get('packageName', '')
    app_version_code = request_body.get('appVersionCode', '')
    platform = request_body.get('platform', '')
    template = loader.get_template(str_device_detail)

    logger.info("get_app_extra_info started. the request is ------>%s", request_body)


    try:
        if isGlobal:
            response = AppVersionInfo.get_data_mysql_exactly(
                {"packageName": package_name, "appVersionCode": app_version_code,
                 "platform": platform})
        else:
            response = AppVersionInfo.get_data_mysql_exactly(
                {"packageName": package_name, "appVersionCode": app_version_code})
        response_app_info_list = response

        if response_app_info_list is None or response_app_info_list == '' \
                or response_app_info_list == "null":
            response_app_info_filter = 'null'
        else:
            response_app_info = response_app_info_list
            if isGlobal:
                response_app_info_filter = conf.all_fields_app_version_filter.get('other')
            else:
                response_app_info_filter = conf.all_fields_app_version_mainland_filter.get('other')

            for each in response_app_info_filter:
                field_name_en = each['field_name_en']
                each['field_value'] = response_app_info.get(field_name_en, 'null')  # filter operation
                if each.get('value_type', '') == 'date':
                    date_value = each['field_value']
                    if date_value is not None and date_value != '' and date_value != 'null':
                        each['field_value'] = datetime.datetime.fromtimestamp(date_value / 1000)
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        response_app_info_filter = 'fail'

    data = {'appInfo': response_app_info_filter}
    return HttpResponse(json.dumps({'html': template.render(data)}))


def get_app_release_task_info(request):
    str = 'app/app-release-task/app-release-task-info.html'
    str_login = '/webManager/login'
    try:
        session = request.COOKIES["session_id"]

        mysql_op = MysqlOp(MySQLConfig['host'],
                           MySQLConfig['port'],
                           MySQLConfig['user'],
                           MySQLConfig['passwd'],
                           MySQLConfig['db'])
        session_info = mysql_op.check_session(session)

        if session_info is not None:
            response_data = {'priority_fields': conf.all_fields_app_release_task_filter.get('priority')}
            email = session_info['email']
            response_data.update({'user': email.split("@")[0], 'web_user_role': session_info.get('role_id'),
                                  'isGlobal': isGlobal})

            response = render(request, str, response_data)
            response.set_cookie("session_id", session, conf.session_ttl)
            return response
        else:
            logger.warn("get_app_release_task_info. checking-session failed. the session is ------>%s" % session)
            return HttpResponseRedirect(str_login)
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        return HttpResponseRedirect(str_login)


@check_authority
def read_app_release_task_info(request):
    request_body = request.POST

    logger.info("read_app_release_task_info started. the request is ------>%s", request_body)

    try:
        response = AppReleaseTaskInfo.get_data_mysql_by_page(request_body)
        response_count = AppReleaseTaskInfo.get_data_mysql_count(request_body)
        response_data = response['responseBody']
        records_filtered = response_count['responseBody']
        records_total_count = AppReleaseTaskInfo.get_data_mysql_count(
            {"modelId": "", "hardwareType": "", "hardwareVersion": ""})
        records_total = records_total_count["responseBody"]
    except:
        logger.error("reading model info by page failed in getting data in models-layer. %s", traceback.format_exc())
        raise

    if type(response_data) is type(list()):
        data = {'data': response_data, 'recordsFiltered': records_filtered, 'recordsTotal': records_total}
    elif type(response_data) is type(dict()):
        response_temp = [response_data]
        data = {'data': response_temp, 'recordsFiltered': 1, 'recordsTotal': records_total}
    else:
        response_temp = []
        data = {'data': response_temp, 'recordsFiltered': 0, 'recordsTotal': records_total}
        logger.info("the type of the data from DAL is -----> %s" % type(response_data))
    return HttpResponse(json.dumps(data))

@check_authority
def get_app_release_task_extra_info(request):
    str_device_detail = 'firmware/firmware-release-task/firmware-release-task-extra-info.html'

    request_body = request.POST.copy()

    logger.info("get_app_release_task_extra_info started. the request is ------>%s", request_body)

    task_id = request_body.get('taskId', '')
    template = loader.get_template(str_device_detail)

    try:
        response = FirmwareReleaseTaskInfo.get_data_mysql_list({"taskId": task_id})  # queried by modelId
        response_device_model_list = response['responseBody']

        if len(response_device_model_list) == 0:
            response_model_info_filter = 'null'
        else:
            response_device_model = response_device_model_list[0]
            response_model_info_filter = conf.all_fields_fw_release_task_filter.get('other')
            for each in response_model_info_filter:
                field_name_en = each['field_name_en']
                each['field_value'] = response_device_model.get(field_name_en, 'null')  # filter operation
                if each.get('value_type', '') == 'date':
                    date_value = each['field_value']
                    if date_value is not None and date_value != '' and date_value != 'null':
                        each['field_value'] = datetime.datetime.fromtimestamp(date_value / 1000)
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        response_model_info_filter = 'fail'

    data = {'firmware_release_task': response_model_info_filter}
    return HttpResponse(json.dumps({'html': template.render(data)}))


def get_app_link_info(request):
    str = 'app/app-link-info/app-link-info.html'
    str_login = '/webManager/login'
    try:
        session = request.COOKIES["session_id"]

        mysql_op = MysqlOp(MySQLConfig['host'],
                           MySQLConfig['port'],
                           MySQLConfig['user'],
                           MySQLConfig['passwd'],
                           MySQLConfig['db'])
        session_info = mysql_op.check_session(session)

        if session_info is not None:
            response_data = {'priority_fields': conf.all_fields_app_link_info_filter.get('priority')}

            email = session_info['email']
            response_data.update({'user': email.split("@")[0], 'web_user_role': session_info.get('role_id'),
                                  'isGlobal': isGlobal})

            response = render(request, str, response_data)
            response.set_cookie("session_id", session, conf.session_ttl)
            logger.info("get_app_link_info. checking-session passed.")
            return response
        else:
            logger.warn("get_app_link_info. checking-session failed. the session is ------>%s" % session)
            return HttpResponseRedirect(str_login)
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        return HttpResponseRedirect(str_login)


@check_authority
def read_app_link_info(request):
    request_body = request.POST.copy()

    logger.info("read_app_link_info started. the request is ------>%s", request_body)

    content_type = request.META['CONTENT_TYPE']
    if 'application/json' in content_type:
        request_body.update(json.loads(request.body))

    try:
        response = AppLinkInfo.get_data_mysql_list(request_body)
        response_data = response['responseBody']

    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        raise

    if type(response_data) is type(list()):
        data = {'data': response_data}
    elif type(response_data) is type(dict()):
        response_temp = [response_data]
        data = {'data': response_temp}
    else:
        response_temp = []
        data = {'data': response_temp}
        logger.info("the type of the data from DAL is -----> %s" % type(response_data))
    return HttpResponse(json.dumps(data))


@check_authority
def get_app_link_extra_info(request):
    str_device_detail = 'app/app-link-info/app-link-extra-info.html'
    request_body = request.POST.copy()
    template = loader.get_template(str_device_detail)

    logger.info("get_app_link_extra_info started. the request is ------>%s", request_body)


    try:
        response = AppLinkInfo.get_data_mysql_exactly(request_body)
        response_app_link_info = response['responseBody']

        if response_app_link_info is None or response_app_link_info == '' \
                or response_app_link_info == "null":
            response_app_info_filter = 'null'
        else:
            response_app_info = response_app_link_info

            response_app_info_filter = conf.all_fields_app_link_info_filter.get('other')

            for each in response_app_info_filter:
                field_name_en = each['field_name_en']
                each['field_value'] = response_app_info.get(field_name_en, '-')  # filter operation
                date_value = each['field_value']

                if date_value is None or date_value == '' or date_value == 'null':
                    each['field_value'] = '-'
                if each.get('value_type', '') == 'date':
                    if date_value != '-':
                        each['field_value'] = datetime.datetime.fromtimestamp(date_value / 1000)

    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        response_app_info_filter = 'fail'

    data = {'app_link_info': response_app_info_filter}
    return HttpResponse(json.dumps({'html': template.render(data)}))


def get_app_new_link_info(request):
    str = 'app/app-new-link-info/app-new-link-info.html'
    str_login = '/webManager/login'
    try:
        session = request.COOKIES["session_id"]

        mysql_op = MysqlOp(MySQLConfig['host'],
                           MySQLConfig['port'],
                           MySQLConfig['user'],
                           MySQLConfig['passwd'],
                           MySQLConfig['db'])
        session_info = mysql_op.check_session(session)

        if session_info is not None:
            response_data = {'priority_fields': conf.all_fields_app_new_link_info_filter.get('priority')}

            email = session_info['email']
            response_data.update({'user': email.split("@")[0], 'web_user_role': session_info.get('role_id'),
                                  'isGlobal': isGlobal})

            response = render(request, str, response_data)
            response.set_cookie("session_id", session, conf.session_ttl)
            logger.info("get_app_new_link_info. checking-session passed.")
            return response
        else:
            logger.warn("get_app_link_info. checking-session failed. the session is ------>%s" % session)
            return HttpResponseRedirect(str_login)
    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        return HttpResponseRedirect(str_login)


@check_authority
def read_app_new_link_info(request):
    request_body = request.POST.copy()

    logger.info("read_app_new_link_info started. the request is ------>%s", request_body)

    content_type = request.META['CONTENT_TYPE']
    if 'application/json' in content_type:
        request_body.update(json.loads(request.body))

    try:
        response = AppNewLinkInfo.get_data_mysql_list(request_body)
        response_data = response['responseBody']

    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        raise

    if type(response_data) is type(list()):
        data = {'data': response_data}
    elif type(response_data) is type(dict()):
        response_temp = [response_data]
        data = {'data': response_temp}
    else:
        response_temp = []
        data = {'data': response_temp}
        logger.info("the type of the data from DAL is -----> %s" % type(response_data))
    return HttpResponse(json.dumps(data))


@check_authority
def get_app_new_link_extra_info(request):
    str_device_detail = 'app/app-new-link-info/app-new-link-extra-info.html'
    request_body = request.POST.copy()
    template = loader.get_template(str_device_detail)

    logger.info("get_app_new_link_extra_info started. the request is ------>%s", request_body)


    try:
        response = AppNewLinkInfo.get_data_mysql_exactly(request_body)
        response_app_link_info = response['responseBody']

        if response_app_link_info is None or response_app_link_info == '' \
                or response_app_link_info == "null":
            response_app_info_filter = 'null'
        else:
            response_app_info = response_app_link_info

            response_app_info_filter = conf.all_fields_app_new_link_info_filter.get('other')

            for each in response_app_info_filter:
                field_name_en = each['field_name_en']
                each['field_value'] = response_app_info.get(field_name_en, '-')  # filter operation
                date_value = each['field_value']

                if date_value is None or date_value == '' or date_value == 'null':
                    each['field_value'] = '-'
                if each.get('value_type', '') == 'date':
                    if date_value != '-':
                        each['field_value'] = datetime.datetime.fromtimestamp(date_value / 1000)

    except:
        logger.error("failed in getting data from models-layer. %s", traceback.format_exc())
        response_app_info_filter = 'fail'

    data = {'app_new_link_info': response_app_info_filter}
    return HttpResponse(json.dumps({'html': template.render(data)}))
