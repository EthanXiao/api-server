# -*- coding:utf-8 -*-
#
# Copyright (c) 2017, TP-Link Co.,Ltd.
# Author:  yuzhijiang <yuzhijiang@tp-link.com.cn>
# Created: 2017-10-10
#
#
from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^getAppInfo$', views.get_app_info, name='get_app_info'),
    url(r'^readAppInfo$', views.read_app_info, name='read_app_info'),
    url(r'^getAppExtraInfo$', views.get_app_extra_info, name='get_app_extra_info'),


    url(r'^getAppReleaseTaskInfo$', views.get_app_release_task_info, name='get_app_release_task_info'),
    url(r'^readAppReleaseTaskInfo$', views.read_app_release_task_info,
        name='read_app_release_task_info'),
    url(r'^getAppReleaseTaskExtraInfo$', views.get_app_release_task_extra_info,
        name='get_app_release_task_extra_info'),

    url(r'^getAppLinkInfo$', views.get_app_link_info, name='get_app_link_info'),
    url(r'^readAppLinkInfo$', views.read_app_link_info, name='read_app_link_info'),
    url(r'^getAppLinkExtraInfo$', views.get_app_link_extra_info, name='get_app_link_extra_info'),

    url(r'^getAppNewLinkInfo$', views.get_app_new_link_info, name='get_app_new_link_info'),
    url(r'^readAppNewLinkInfo$', views.read_app_new_link_info, name='read_app_new_link_info'),
    url(r'^getAppNewLinkExtraInfo$', views.get_app_new_link_extra_info, name='get_app_new_link_extra_info'),
]
